({action,args}) => {
  const visible=el=>!!el&&el.getClientRects().length>0;
  const boxOf=el=>{const r=el.getBoundingClientRect();return{x:r.x,y:r.y,width:r.width,height:r.height};};
  // Shopee renders search-result anchors with `display: contents`; such elements never
  // generate a box, so getClientRects() is empty forever even on a fully rendered page.
  // Resolve visibility and geometry through the first ancestor that does generate a box.
  const anchorBox=a=>{const r=a.getBoundingClientRect();if(r.width>0&&r.height>0)return{x:r.x,y:r.y,width:r.width,height:r.height};let p=a.parentElement;while(p&&p!==document.body){const pr=p.getBoundingClientRect();if(pr.width>0&&pr.height>0)return{x:pr.x,y:pr.y,width:pr.width,height:pr.height};p=p.parentElement;}return{x:r.x,y:r.y,width:r.width,height:r.height};};
  const anchorVisible=a=>{if(!a)return false;if(a.getClientRects().length>0)return true;if(getComputedStyle(a).display!=='contents')return false;let p=a.parentElement;while(p&&p!==document.body){if(p.getClientRects().length>0){const pr=p.getBoundingClientRect();if(pr.width>0&&pr.height>0)return true;}const pcs=getComputedStyle(p);if(pcs.display==='none'||pcs.visibility==='hidden')return false;p=p.parentElement;}return false;};
  const norm=s=>String(s||'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/[^a-z0-9]+/g,' ').trim();
  const barRoot=()=>{
    const nodes=[...document.querySelectorAll("form.shopee-searchbar,[class*='searchbar'],[role='search'],header form,header nav")].filter(visible);
    return nodes.find(node=>node.querySelector("input"))||null;
  };
  const inputSelectors=["input[aria-label='Search for products, brands and shops']","input.shopee-searchbar-input__input","input[aria-label*='Search']","input[aria-label*='Tìm kiếm']","input[placeholder*='Search for products']","input[placeholder*='Tìm kiếm']","input[role='combobox']","input[type='search']","input[type='text']"];
  const findInput=()=>{
    const root=barRoot();
    if(root){
      for(const s of inputSelectors){const el=root.querySelector(s);if(el&&visible(el))return el;}
      const any=root.querySelector("input");if(any&&visible(any))return any;
    }
    for(const s of inputSelectors){const el=document.querySelector(s);if(el&&visible(el)&&el.closest("[class*='searchbar'],[role='search'],header,form"))return el;}
    return null;
  };
  const submitButton=el=>{
    const scopes=[el.closest("form"),el.closest("[class*='searchbar']"),barRoot(),document].filter(Boolean);
    const selectors=["button.shopee-searchbar__search-button","button[class*='search-button']","button[type='submit']","button.btn-solid-primary","button[aria-label*='Search']","button[aria-label*='Tìm kiếm']","button:has(svg)"];
    for(const scope of scopes){
      for(const s of selectors){const c=scope.querySelector(s);if(c&&visible(c))return c;}
    }
    return null;
  };
  if(action==='input'){
    const el=findInput();
    if(!el)return{found:false,reason:'INPUT_NOT_FOUND'};
    const btn=submitButton(el);
    return{
      found:true,
      inSearchbar:!!el.closest("[class*='searchbar'],[role='search'],header"),
      box:boxOf(el),
      buttonFound:!!btn,
      buttonBox:btn?boxOf(btn):null,
      ariaLabel:el.getAttribute('aria-label')||'',
      placeholder:el.getAttribute('placeholder')||'',
      value:String(el.value||'')
    };
  }
  if(action==='focusCheck'){
    const el=findInput();
    if(!el)return{found:false,focused:false,value:''};
    const active=document.activeElement;
    return{
      found:true,
      focused:active===el||!!(active&&el.contains(active)),
      value:String(el.value||''),
      activeTag:active?(active.tagName||'')+'#'+(active.id||active.getAttribute('name')||''):''
    };
  }
  if(action==='targetBox'){
    // Resolve the card live at click time. The scan reports the anchor's absolute href,
    // but Shopee writes a relative href in the DOM, so selecting by href never matched and
    // every open silently fell through to a cold page.goto.
    const wantId=String(args?.itemId||'').trim();
    const wishMatch=String(args?.href||'').match(/(?:-i\.|\/product\/)(\d+)(?:[./](\d+))?/i);
    const wishId=wishMatch?(wishMatch[2]||wishMatch[1]):'';
    const links=[...document.querySelectorAll("a[href*='-i.'],a[href*='/product/']")].filter(anchorVisible);
    let hit=null;
    for(const a of links){
      // Match on the parsed item id, never on the raw href: the attribute is relative in
      // Shopee's DOM while the scan reports a resolved absolute URL.
      const href=a.href||a.getAttribute('href')||'';
      const m=href.match(/(?:-i\.|\/product\/)(\d+)(?:[./](\d+))?/i);
      const id=m?(m[2]||m[1]):'';
      if(id&&(id===wantId||(wishId&&id===wishId))){hit=a;break;}
    }
    if(!hit)return{found:false};
    const card=hit.closest("[class*='item-card'],[class*='search-item']")||hit;
    const r=anchorBox(card);
    return{found:true,href:hit.href||'',box:{x:r.x,y:r.y,width:r.width,height:r.height},cardBox:anchorBox(hit)};
  }
  if(action==='next'){
    // Shopee exposes the page counter itself, and disables the arrow with aria-disabled
    // plus a --disabled class - not an attribute an <a> would ever honour - while pointing
    // the dead arrow at "/". Reading that is how we know whether a next page exists at all.
    const currentEl=document.querySelector(".shopee-mini-page-controller__current");
    const totalEl=document.querySelector(".shopee-mini-page-controller__total");
    const current=currentEl?(parseInt(String(currentEl.textContent||'').trim(),10)||0):0;
    const total=totalEl?(parseInt(String(totalEl.textContent||'').trim(),10)||0):0;
    const selectors=['a.shopee-mini-page-controller__next-btn','button.shopee-mini-page-controller__next-btn','a.shopee-icon-button.shopee-icon-button--right','button.shopee-icon-button.shopee-icon-button--right','nav.shopee-page-controller a.shopee-icon-button--right','nav.shopee-page-controller button.shopee-icon-button--right','a.shopee-button-outline.shopee-mini-page-controller__next-btn'];
    const el=selectors.map(s=>document.querySelector(s)).find(x=>visible(x));
    if(!el)return{found:false,hasNext:false,current,total,href:''};
    const disabled=el.getAttribute('aria-disabled')==='true'||/disabled/i.test(String(el.className||''));
    const href=el.getAttribute('href')||'';
    const exhausted=total>0&&current>0&&current>=total;
    const hasNext=!disabled&&!exhausted&&!!href&&href!=='/';
    return{found:true,hasNext,current,total,href:hasNext?href:''};
  }
  if(action==='productAnchorsReady'){
    // True as soon as at least one product anchor is genuinely visible, using the
    // same ancestor-aware visibility rule the scan uses (display:contents anchors).
    const any=[...document.querySelectorAll("a[href*='-i.'],a[href*='/product/']")].some(anchorVisible);
    return{any};
  }

  // ---- product lookup -------------------------------------------------
  // The caller may hold the identity in any of these shapes:
  //   "i.222.1234567" (what KeywordTrackingStore.ExtractProductIdFromLink emits)
  //   "222.1234567", "1234567", or a full product URL.
  // Anything else - notably an empty id because the saved link was a short
  // redirector - falls back to matching the product name the operator saved.
  const rawId=String(args?.productId||'').trim().replace(/^i\.+/i,'');
  const rawName=String(args?.productName||'').trim();
  const idMatch=rawId.match(/(?:^|i\.|\/product\/)(\d+)(?:[./](\d+))?/i);
  let targetShop='',targetItem='';
  if(idMatch){
    const a=idMatch[1]||'',b=idMatch[2]||'';
    targetShop=b?a:'';
    targetItem=b?b:a;
  }
  const nameTokens=norm(rawName).split(' ').filter(t=>t.length>=3);
  const hasItemKey=targetItem.length>=6;
  const hasNameKey=nameTokens.length>=2;

  // Collect document-wide. Picking a single "[class*='search-item-result']" container by
  // index is what made this scan report "0 sản phẩm" on a page the Playwright anchor wait
  // had just confirmed was full of product links: the first visible match was an empty
  // wrapper and every anchor lived outside it.
  const anchors=[...document.querySelectorAll("a[href*='-i.'],a[href*='/product/']")].filter(anchorVisible).sort((a,b)=>{const x=anchorBox(a),y=anchorBox(b);return Math.abs(x.y-y.y)>8?x.y-y.y:x.x-y.x});
  const seen=new Set(),items=[];
  for(const a of anchors){
    const href=a.href||a.getAttribute('href')||'';
    const m2=href.match(/(?:-i\.|\/product\/)(\d+)[./](\d+)/i);
    const m1=href.match(/(?:-i\.|\/product\/)(\d+)/i);
    const shopId=m2?m2[1]:'';
    const id=m2?m2[2]:(m1?m1[1]:'');
    if(!id||seen.has(id))continue;
    let card=null,node=a.parentElement;
    while(node&&node!==document.body){
      if(node.querySelectorAll("a[href*='-i.'],a[href*='/product/']").length<=1){card=node;break;}
      node=node.parentElement;
    }
    const text=((card||a).innerText)||'';
    const title=(text.split('\n').map(s=>s.trim()).filter(Boolean)[0])||'';
    const isAd=/quảng cáo|tài trợ|sponsored/i.test(text)||href.includes('sp_atk=');

    let isTarget=false,matchBy='';
    if(hasItemKey&&id===targetItem&&(!targetShop||!shopId||shopId===targetShop)){
      isTarget=true;matchBy='itemId';
    }else if(rawId.length>=5&&href.includes(rawId)){
      isTarget=true;matchBy='href';
    }else if(!hasItemKey&&hasNameKey){
      const titleNorm=norm(title||text);
      const hits=nameTokens.filter(t=>titleNorm.includes(t)).length;
      if(hits&&hits/nameTokens.length>=0.7){isTarget=true;matchBy='productName';}
    }
    if(isAd&&!isTarget)continue;
    seen.add(id);
    const rect=anchorBox(a);
    items.push({id,shopId,href,title,position:items.length+1,isTarget,isAd,matchBy,box:{x:rect.x,y:rect.y,width:rect.width,height:rect.height}});
    if(items.length>=60)break;
  }
  const found=items.find(x=>x.isTarget);
  // Page state, so an empty read can be told apart from a page that never rendered one.
  const allAnchors=document.querySelectorAll('a').length;
  // Unfiltered product-link count: distinguishes "products present but filtered out by the
  // visibility check" from "no product links exist in the DOM at all".
  const totalProductAnchors=document.querySelectorAll("a[href*='-i.'],a[href*='/product/']").length;
  const bodyText=String((document.body&&document.body.innerText)||'').slice(0,3000).toLowerCase();
  const emptyState=/không tìm thấy|không có sản phẩm|no results|rất tiếc|xin lỗi/i.test(bodyText);
  const skeleton=!!document.querySelector("[class*='skeleton'],[class*='loading'],[class*='placeholder'],[class*='spinner']");
  return {
    count:items.length,
    // Reported separately so "the page had almost no product links" can be told apart from
    // "the links were there but deduped or unparsed".
    rawAnchors:anchors.length,
    totalAnchors:allAnchors,
    totalProductAnchors:totalProductAnchors,
    emptyState,
    skeleton,
    docTitle:String(document.title||'').slice(0,70),
    found:found||null,
    signature:items.slice(0,5).map(x=>x.id).join('|'),
    lookup:{targetItem,targetShop,hasItemKey,hasNameKey,nameTokens:nameTokens.slice(0,4)},
    sample:items.slice(0,6).map(x=>({id:x.id,shopId:x.shopId,title:(x.title||'').slice(0,40),isAd:x.isAd}))
  };
}

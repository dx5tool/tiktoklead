({action}) => {
  const visible=el=>!!el&&el.getClientRects().length>0;
  const horizontallyVisible=el=>{if(!visible(el))return false;const r=el.getBoundingClientRect();return r.width>0&&Math.min(r.right,innerWidth)>Math.max(r.left,0);};
  const nodes=[...document.querySelectorAll('button,a')].filter(visible);
  const viewButton=()=>{
    const shopLinks=[...document.querySelectorAll("a[href*='entryPoint=ShopByPDP']")];
    const exactText=el=>/^(xem shop|view shop)$/i.test((el.textContent||'').replace(/\u00a0/g,' ').trim());
    const exactShopLink=shopLinks.find(el=>horizontallyVisible(el)&&exactText(el))||[...document.querySelectorAll('a')].find(el=>horizontallyVisible(el)&&exactText(el));
    if(exactShopLink)return exactShopLink;
    return shopLinks.find(el=>horizontallyVisible(el)&&!!(el.textContent||'').trim()&&(el.matches(".btn,[role='button'],[class*='btn']")||!!el.querySelector("button,[role='button']")));
  };
  const productOverviewItem=()=>[...document.querySelectorAll('.section-seller-overview__item--clickable')].find(el=>{
    if(!visible(el))return false;
    const name=(el.querySelector('.section-seller-overview__item-text-name')?.textContent||'').replace(/\u00a0/g,' ').trim();
    return /^(sản phẩm|products?)\s*:/i.test(name);
  });
  if(action==='view'){
    const b=viewButton();
    if(!b||!visible(b))return{status:'NOT_FOUND'};
    const r=b.getBoundingClientRect();return{status:'READY',href:b.href||b.getAttribute('href')||'',box:{x:r.x,y:r.y,width:r.width,height:r.height},viewportHeight:innerHeight,viewportWidth:innerWidth,text:(b.textContent||'').trim()};
  }
  if(action==='products'){
    const b=productOverviewItem();
    if(!b)return{status:'NOT_FOUND'};
    const r=b.getBoundingClientRect();return{status:'READY',box:{x:r.x,y:r.y,width:r.width,height:r.height},viewportHeight:innerHeight,viewportWidth:innerWidth,text:(b.textContent||'').replace(/\s+/g,' ').trim()};
  }
  if(action==='pageState'){
    const root=document.documentElement;
    return{href:location.href,scrollY,height:root.scrollHeight,viewportHeight:innerHeight,viewportWidth:innerWidth,bottom:scrollY+innerHeight>=root.scrollHeight-100,productLinks:document.querySelectorAll("a[href*='-i.'],a[href*='/product/']").length};
  }
  if(action==='follow'){
    const b=nodes.find(x=>x.matches("button.shopee-button-outline--fill,button.shopee-button-outline,button.shopee-button-outline--complement,button[class*='follow'],button[aria-label*='follow' i]")||/^theo dõi$|^follow$/i.test((x.textContent||'').trim()));
    if(!b)return{status:'NOT_FOUND'};if(/đang theo dõi|following|unfollow/i.test((b.textContent||'')+' '+(b.getAttribute('aria-label')||'')))return{status:'SKIPPED_ALREADY'};return{status:'READY'};
  }
  return{};
}
({action}) => {
  const visible = el => !!el && el.getClientRects().length > 0;
  const loginPath = location.pathname.toLowerCase().includes('/buyer/login');
  const loginLink = [...document.querySelectorAll("a[href*='/buyer/login']")].find(a => visible(a) && /đăng nhập|log in|login/i.test(a.textContent || ''));
  const users = [...document.querySelectorAll("div.navbar__username,[class*='navbar__username']")].filter(visible);
  const user = users.find(el => {
    const text=(el.textContent || '').trim().toLowerCase();
    return text && !/đăng nhập|login|sign up|đăng ký/.test(text);
  });
  if (action === 'proof') return {
    loginProof:!loginPath && !loginLink && !!user,
    hasNavbarUsername:!!user,
    hasLoginLink:!!loginLink,
    nickname:user ? (user.textContent || '').trim() : '',
    loginPath
  };
  return {};
}
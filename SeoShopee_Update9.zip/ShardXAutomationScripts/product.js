({action,args}) => {
  const visible=el=>!!el&&el.getClientRects().length>0;
  const all=ss=>ss.flatMap(s=>[...document.querySelectorAll(s)]).filter(visible);
  const byText=re=>[...document.querySelectorAll('button,a,div,span')].find(x=>visible(x)&&re.test((x.textContent||'').trim()));
  const lightbox=()=>all(["[role='dialog']",'.UCGJYT','.NDTw5b','.aUuKn4',"[class*='product-image'] [class*='modal']","[class*='video'] [class*='modal']"]).find(x=>x.querySelector('img,video')||/media|image|video/i.test(x.className||''));
  if(action==='probe')return{ready:!!document.querySelector("[class*='product'],[class*='product-detail']"),href:location.href};
  if(action==='mediaInventory'){
    const thumbs=all(['.Wi_1Rq .qIctnQ','.Wi_1Rq .mdCA_C','div.thumbnail-selected-mask']);
    const isVideo=x=>!!x.querySelector?.("img.emXGWZ,img[alt*='video' i],video")||x.matches?.("video,img.emXGWZ");
    return{hrefPath:location.pathname,thumbnailCount:thumbs.length,videoThumbnails:thumbs.filter(isVideo).length,imageThumbnails:thumbs.filter(x=>!isVideo(x)&&!!x.querySelector?.('img')).length,visibleImages:all(["[class*='image-carousel'] img","[class*='product-image'] img"]).length,visibleVideos:all(["[class*='product-detail'] video",'video']).length,lightboxOpen:!!lightbox()};
  }
  if(action==='mediaTarget'){
    const c=all(['.Wi_1Rq .qIctnQ','.Wi_1Rq .mdCA_C','.Wi_1Rq img.emXGWZ','.Wi_1Rq img.P39yUt','.airUhU .UBG7wZ','.YM40Nc','div.thumbnail-selected-mask',"[class*='image-carousel'] img","[class*='product-detail'] video",'video',"[class*='product-image'] img"]);
    const videoIcon=c.find(x=>x.matches('img.emXGWZ')||/icon video play/i.test(x.getAttribute('alt')||''));
    const t=(videoIcon&&(videoIcon.closest('.qIctnQ')||videoIcon.closest('.mdCA_C')))||c.find(x=>x.matches('.qIctnQ'))||c[0];
    if(!t)return{found:false};
    const r=t.getBoundingClientRect();
    return{found:r.width>0&&r.height>0,selector:'',video:!!videoIcon,box:{x:r.x,y:r.y,width:r.width,height:r.height}};
  }
  if(action==='mediaImageTarget'){
    const thumbs=all(['.Wi_1Rq .qIctnQ','.Wi_1Rq .mdCA_C']);
    const isVideo=x=>!!x.querySelector("img.emXGWZ,img[alt*='video' i],video");
    const t=thumbs.find(x=>!isVideo(x)&&!!x.querySelector('img'));
    if(!t)return{found:false,thumbnailCount:thumbs.length};
    const r=t.getBoundingClientRect();
    return{found:r.width>0&&r.height>0,box:{x:r.x,y:r.y,width:r.width,height:r.height},thumbnailCount:thumbs.length};
  }
  if(action==='lightbox')return{open:!!lightbox()};
  if(action==='mediaNext'){
    const box=lightbox();if(!box)return{found:false,reason:'LIGHTBOX_NOT_OPEN'};
    const n=all(["img[alt='icon arrow right bold']",'.RZy1Jt','.C2knlh','button[aria-label*=next i]']).find(x=>box.contains(x));
    if(!n)return{found:false,reason:'NEXT_NOT_FOUND'};
    const target=n.closest('button')||n;const r=target.getBoundingClientRect();
    return{found:r.width>0&&r.height>0,box:{x:r.x,y:r.y,width:r.width,height:r.height}};
  }
  if(action==='mediaClose'){
    const box=lightbox();if(!box)return{open:false,found:false};
    const c=all(['.aUuKn4 .dqUa8V','.dqUa8V','button[aria-label*=close i]','button[aria-label*=đóng i]','img[alt*=close i]']).find(x=>box.contains(x));
    if(!c)return{open:true,found:false,reason:'CLOSE_NOT_FOUND'};
    const target=c.closest('button')||c;const r=target.getBoundingClientRect();
    return{open:true,found:r.width>0&&r.height>0,box:{x:r.x,y:r.y,width:r.width,height:r.height}};
  }
  if(action==='mediaState'){
    // Read-only counterpart of mediaPause. Pausing every <video> from script, with no
    // gesture behind it, is a page-visible media mutation; plain scrolling past a
    // playing video is what a person does, so the normal path must not mutate anything.
    const videos=[...document.querySelectorAll('video')];
    return{videoCount:videos.length,playing:videos.filter(v=>v.getClientRects().length>0&&!v.paused&&!v.ended).length,lightboxOpen:!!lightbox()};
  }
  if(action==='mediaPause'){
    const videos=[...document.querySelectorAll('video')];
    const playingBefore=videos.filter(v=>!v.paused&&!v.ended).length;
    let paused=0;
    for(const video of videos){try{if(!video.paused&&!video.ended){video.pause();paused++;}}catch{}}
    return{videoCount:videos.length,playingBefore,paused,playingAfter:videos.filter(v=>!v.paused&&!v.ended).length,lightboxOpen:!!lightbox()};
  }
  if(action==='like'){
    const icon=all(['svg.xwwO4T',"svg[width='24'][height='20']"]).find(x=>x.querySelector("path[stroke='#FF424F'],path[stroke='#ff424f']"));
    if(!icon)return{status:'NOT_FOUND'};
    const path=icon.querySelector('path');const liked=(path&&String(path.getAttribute('fill')||'').toLowerCase()==='#ff424f');
    if(liked)return{status:'SKIPPED_ALREADY'};
    const r=icon.getBoundingClientRect();return{status:'READY',box:{x:r.x,y:r.y,width:r.width,height:r.height}};
  }
  if(action==='pointDiag'){
    const optionSelector=['button.product-variation',"button[class*='product-variation']",'button.sApkZm','button.selection-box-unselected','button.selection-box-selected'].join(',');
    const x=Number(args?.x),y=Number(args?.y),hit=document.elementFromPoint(x,y),button=hit?.closest?.(optionSelector);
    return{href:location.href,hit:hit?.tagName||'',insideVariant:!!button,buttonText:(button?.textContent||'').replace(/\s+/g,' ').trim().slice(0,80),buttonClass:String(button?.className||'').slice(0,160),x,y};
  }
  if(action==='variants'){
    const optionSelector=['button.product-variation',"button[class*='product-variation']",'button.sApkZm','button.selection-box-unselected','button.selection-box-selected'].join(',');
    const soldOut=b=>b.disabled||b.getAttribute('aria-disabled')==='true'||/disabled|sold.?out|out.?of.?stock|hết.?hàng/i.test(`${b.className||''} ${b.getAttribute('aria-label')||''} ${b.getAttribute('title')||''}`);
    const selected=b=>b.getAttribute('aria-pressed')==='true'||b.classList.contains('selection-box-selected');
    const buttons=all([optionSelector]).filter(b=>!soldOut(b));
    const parents=[...new Set(buttons.map(b=>b.parentElement).filter(Boolean))];
    const groups=parents.map(p=>[...p.querySelectorAll(optionSelector)].filter(b=>visible(b)&&!soldOut(b))).filter(g=>g.length);
    const selectedGroups=groups.filter(g=>g.some(selected)).length;
    const pending=groups.find(g=>!g.some(selected));
    if(!pending)return{clicked:false,selectedGroups,totalGroups:groups.length,available:buttons.length,complete:selectedGroups===groups.length};
    const viewportChoices=pending.filter(b=>{const r=b.getBoundingClientRect();const cx=r.left+r.width/2;return r.width>0&&cx>=1&&cx<=innerWidth-1;});
    if(!viewportChoices.length)return{clicked:false,selectedGroups,totalGroups:groups.length,available:buttons.length,complete:false,reason:'NO_HORIZONTAL_TARGET',viewportWidth:innerWidth};
    const choice=viewportChoices[Math.floor(Math.random()*viewportChoices.length)];const r=choice.getBoundingClientRect();
    return{clicked:true,selectedGroups,totalGroups:groups.length,available:buttons.length,expectedSelectedGroups:selectedGroups+1,target:choice.getAttribute('aria-label')||(choice.textContent||'').trim(),box:{x:r.x,y:r.y,width:r.width,height:r.height},viewportHeight:innerHeight,viewportWidth:innerWidth};
  }
  if(action==='cart'||action==='cartScroll'){
    const b=all(["button:has(img[alt='icon-add-to-cart'])",'button.btn.btn-tinted.btn--l','button.btn-tinted.btn--l',"button[aria-label*='thêm vào giỏ' i]","button[aria-label*='add to cart' i]",'button.btn-tinted',"button[class*='btn-tinted']"])[0]||byText(/thêm vào giỏ|add to cart/i);
    if(!b)return{status:'NOT_FOUND'};
    if(action==='cartScroll'){b.scrollIntoView({behavior:'smooth',block:'center'});return{status:'OK'};}
    if(b.disabled||b.getAttribute('aria-disabled')==='true')return{status:'BLOCKED'};
    const badge=document.querySelector('.shopee-cart-number-badge,[class*=cart-number-badge],a[href*="/cart"] [class*=badge]');
    const r=b.getBoundingClientRect();return{status:'READY',box:{x:r.x,y:r.y,width:r.width,height:r.height},cartCount:badge?(badge.textContent||'').trim():''};
  }
  if(action==='cartResult'){
    const text=document.body?.innerText||'';const badge=document.querySelector('.shopee-cart-number-badge,[class*=cart-number-badge],a[href*="/cart"] [class*=badge]');
    return{added:/đã được thêm vào giỏ hàng|added to (your )?cart/i.test(text),captcha:/\/verify\/(?:traffic|captcha)|\/captcha/i.test(location.href)||!!document.querySelector("iframe[src*='captcha']"),cartCount:badge?(badge.textContent||'').trim():''};
  }
  if(action==='reviewAnchor'){
    const a=all(['.product-ratings__header_score','.product-rating-overview__filter','.product-rating-overview',"[class*='product-ratings']","[class*='rating-overview']","[id*='review']","section[class*='rating']"])[0]||byText(/đánh giá|danh gia|product ratings|reviews/i);if(!a)return{found:false};return{found:true,top:a.getBoundingClientRect().top};
  }
  return{};
}
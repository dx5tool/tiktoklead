({action, args}) => {
  const visible = el => !!el && el.getClientRects().length > 0;
  if (action === 'risk') {
    const href = location.href.toLowerCase(); const text=(document.body?.innerText || '').toLowerCase();
    const iframe=document.querySelector("iframe[src*='captcha']");
    const detail=(reason,risk,trafficGate=false)=>{let iframePath='';try{iframePath=iframe?new URL(iframe.src,location.href).pathname:'';}catch{}return{risk,trafficGate,reason,hrefPath:location.pathname,iframePath,readyState:document.readyState};};
    if (href.includes('/verify/traffic/error')) return detail('TRAFFIC_URL','',true);
    if (href.includes('/verify/traffic') || href.includes('/verify/captcha') || href.includes('/captcha')) return detail('CAPTCHA_URL','NEED_CAPTCHA');
    if (iframe) return detail('CAPTCHA_IFRAME','NEED_CAPTCHA');
    if (href.includes('/verify/email-link') || text.includes('verify your identity') || text.includes('xác minh danh tính')) return detail('VERIFY_PAGE_OR_TEXT','NEED_VERIFY');
    if (text.includes('mã otp') || text.includes('verification code') || text.includes('mã xác nhận')) return detail('OTP_TEXT','NEED_OTP');
    if (text.includes('unusual activity') || text.includes('automated tools') || text.includes('account locked')) return detail('LOCKED_TEXT','ACCOUNT_LOCKED');
    return {risk:'',trafficGate:false,reason:'NONE',hrefPath:location.pathname,iframePath:'',readyState:document.readyState};
  }
  if (action === 'popup') {
    const scope=document.querySelector("#HomePagePopupBannerSection,section[id*='HomePagePopup']");
    if (!scope || !visible(scope)) return {found:false,closed:false};
    const selectors=['div.e_KtkD.Xg_fY5','div.qGCNW3.f8dS_D','div.e_KtkD','div.qGCNW3','button[aria-label*=close i]'];
    let close=selectors.map(s => scope.querySelector(s)).find(visible);
    if (!close) { const svg=scope.querySelector('svg.KQjk2l'); close=svg && (svg.closest('button,div') || svg); }
    if (!close) return {found:true,closed:false}; close.click(); return {found:true,closed:true};
  }
  if (action === 'popupVisible') { const p=document.querySelector("#HomePagePopupBannerSection,section[id*='HomePagePopup']"); return {visible:visible(p)}; }
  if (action === 'scroll') { const amount=Math.max(120,Math.min(Number(args?.amount || 220),innerHeight)); scrollBy({top:amount,behavior:'smooth'}); return {scrollY,height:document.documentElement.scrollHeight,bottom:scrollY+innerHeight>=document.documentElement.scrollHeight-100}; }
  return {};
}
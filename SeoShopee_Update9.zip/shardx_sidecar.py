from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
import platform
import random
import shutil
import sys
import threading
from pathlib import Path
from typing import Any

SIDECAR_ROOT = Path(__file__).resolve().parent
if str(SIDECAR_ROOT) not in sys.path:
    sys.path.insert(0, str(SIDECAR_ROOT))

PROTOCOL = "shardx/1"
# Engine bỏ tab welcome `chrome://shardx/` khi marker này có trong user-data-dir.
WELCOME_MARKER = "ShardXWelcomeSeen"


def emit(value: str) -> None:
    print(value, flush=True)


def diagnostic(value: str) -> None:
    print(value, file=sys.stderr, flush=True)


class OfflineRuntimeError(RuntimeError):
    pass


def load_seed_manifest(runtime_root: Path) -> dict[str, Any]:
    manifest_path = runtime_root / "seed-manifest.json"
    if not manifest_path.is_file():
        raise OfflineRuntimeError(f"Missing seed manifest: {manifest_path}")
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    if data.get("schema_version") != 1 or data.get("platform") != "windows-x64":
        raise OfflineRuntimeError("Unsupported ShardX seed manifest")
    return data


def validate_seed(runtime_root: Path) -> dict[str, Any]:
    if sys.platform != "win32" or platform.machine().lower() not in {"amd64", "x86_64"}:
        raise OfflineRuntimeError("ShardX seed supports Windows x64 only")
    seed = load_seed_manifest(runtime_root)
    required = [
        runtime_root / "ShardX-Windows" / "chrome.exe",
        runtime_root / "ShardX-Windows" / "WidevineCdm" / "manifest.json",
        runtime_root / "ShardX-Windows" / "WidevineCdm" / "_platform_specific" / "win_x64" / "widevinecdm.dll",
        runtime_root / "ShardX-Windows" / "WidevineCdm" / "_platform_specific" / "win_x64" / "widevinecdm.dll.sig",
    ]
    missing = [str(path) for path in required if not path.is_file()]
    if missing:
        raise OfflineRuntimeError("Missing ShardX runtime files: " + ", ".join(missing))
    files = seed.get("files")
    if not isinstance(files, dict) or not files:
        raise OfflineRuntimeError("Seed manifest has no file hashes")
    for relative, expected in files.items():
        path = runtime_root / Path(str(relative))
        if not path.is_file():
            raise OfflineRuntimeError(f"Missing seeded file: {path}")
        actual = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual.lower() != str(expected).lower():
            raise OfflineRuntimeError(f"Seed hash mismatch: {path}")
    fingerprint_dir = runtime_root / "fingerprints"
    fingerprints = list(fingerprint_dir.glob("*.json"))
    if not fingerprints:
        raise OfflineRuntimeError(f"Missing fingerprint library: {fingerprint_dir}")
    for path in fingerprints:
        if not isinstance(json.loads(path.read_text(encoding="utf-8")), dict):
            raise OfflineRuntimeError(f"Invalid fingerprint: {path}")
    return seed


def create_offline_sdk(runtime_root: Path, profiles_root: Path):
    seed = validate_seed(runtime_root)

    from shardx import ShardX
    from shardx.browser import Browser
    from shardx.profile import FingerprintLibrary
    from shardx.runtime import Runtime

    class OfflineRuntime(Runtime):
        def install(self, force: bool = False) -> None:
            if force:
                raise OfflineRuntimeError("ShardX runtime download/update is disabled")
            if self._checked_in_process:
                return
            current = validate_seed(Path(self.root))
            self._chromium_version = str(current.get("chromium_version") or "")
            self._grease_brand = current.get("grease_brand")
            self._grease_version = current.get("grease_version")
            self._tls = current.get("tls")
            self._checked_in_process = True

    sdk = ShardX(cache_dir=str(runtime_root), profiles_dir=str(profiles_root))
    runtime = OfflineRuntime(cache_dir=runtime_root, profiles_dir=profiles_root)
    sdk.runtime = runtime
    sdk.library = FingerprintLibrary(runtime)
    sdk._browser = Browser(runtime)
    runtime.install()
    return sdk, seed


def load_payload(path: Path) -> dict[str, Any]:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    finally:
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass


def prepare_profile_state(user_data_dir: Path) -> None:
    """Chuẩn bị profile trước khi mở ShardX Chromium.

    - Tạo marker `ShardXWelcomeSeen` để engine bỏ tab welcome `chrome://shardx/`
      (engine đọc marker này trong startup_tab_provider.cc).
    - Tắt password manager của profile: `credentials_enable_service=false` là pref
      gốc của tuỳ chọn "Offer to save passwords", nên bong bóng "Save password?"
      không còn được tạo. Chromium 152 không có flag dòng lệnh nào làm việc này.
    """
    try:
        user_data_dir.mkdir(parents=True, exist_ok=True)
        (user_data_dir / WELCOME_MARKER).write_text("", encoding="utf-8")
    except OSError as ex:
        diagnostic(f"SHARDX_PROFILE_MARKER_SKIP: {type(ex).__name__}: {ex}")

    prefs_path = user_data_dir / "Default" / "Preferences"
    data: dict[str, Any] = {}
    if prefs_path.is_file():
        try:
            loaded = json.loads(prefs_path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as ex:
            # File hỏng hoặc không đọc được: không ghi đè để tránh mất cấu hình khác.
            diagnostic(f"SHARDX_PREFS_SKIP: {type(ex).__name__}: {ex}")
            return
        if not isinstance(loaded, dict):
            return
        data = loaded
    data["credentials_enable_service"] = False
    profile_section = data.setdefault("profile", {})
    if isinstance(profile_section, dict):
        profile_section["password_manager_leak_detection"] = False
    try:
        prefs_path.parent.mkdir(parents=True, exist_ok=True)
        prefs_path.write_text(json.dumps(data), encoding="utf-8")
    except OSError as ex:
        diagnostic(f"SHARDX_PREFS_WRITE_SKIP: {type(ex).__name__}: {ex}")


def prepare_new_windows_profile(sdk, profile_id: str, runtime_profile_id: str, profile_json: Path):
    windows_templates = list(sdk.library.filter(platform="Windows"))
    if not windows_templates:
        raise RuntimeError("ShardX fingerprint library has no Windows profiles")
    template = random.choice(windows_templates)
    config = json.loads(json.dumps(sdk.library.load(template).config))
    config["timezone"] = "auto"
    config["icu_locale"] = "auto"
    navigator = config.setdefault("navigator", {})
    navigator["language"] = "auto"
    navigator["accept_language"] = "auto"
    navigator["languages"] = []
    config["geolocation"] = {"mode": "auto"}

    from shardx.profile import Profile
    from shardx.randomize import randomize_hardware, randomize_platform_version

    randomize_hardware(config, profile_id=profile_id)
    randomize_platform_version(config)
    profile_json.parent.mkdir(parents=True, exist_ok=True)
    profile_json.write_text(json.dumps(config, indent=2), encoding="utf-8")
    return Profile(config, id=runtime_profile_id)


def load_extension_args(paths: list[str]) -> list[str]:
    resolved: list[str] = []
    for raw in paths:
        path = Path(raw).resolve()
        manifest = path / "manifest.json"
        if not manifest.is_file():
            raise FileNotFoundError(f"Chromium extension manifest not found: {manifest}")
        resolved.append(str(path))
    if not resolved:
        return []
    joined = ",".join(resolved)
    return [f"--disable-extensions-except={joined}", f"--load-extension={joined}"]


def stop_reader(stop_event: threading.Event) -> None:
    try:
        for line in sys.stdin:
            if line.strip().upper() == "STOP":
                stop_event.set()
                return
    finally:
        stop_event.set()


async def first_visible(page, selectors: list[str], timeout_ms: int = 15000):
    deadline = asyncio.get_running_loop().time() + timeout_ms / 1000.0
    while asyncio.get_running_loop().time() < deadline:
        for selector in selectors:
            locator = page.locator(selector).first
            try:
                if await locator.is_visible(timeout=300):
                    return locator
            except Exception:
                pass
        await asyncio.sleep(0.2)
    return None


async def login_proof(page) -> bool:
    if "/buyer/login" in (page.url or "").lower():
        return False
    locator = page.locator("div.navbar__username").first
    try:
        return await locator.is_visible(timeout=1000) and bool((await locator.inner_text()).strip())
    except Exception:
        return False


async def classify_login(page) -> dict[str, str]:
    url = (page.url or "").lower()
    try:
        text = (await page.locator("body").inner_text(timeout=1500)).lower()
    except Exception:
        text = ""
    if await login_proof(page):
        return {"status": "SUCCESS", "message": "đăng nhập Shopee thành công."}
    if "/verify/captcha" in url or "/captcha" in url or await page.locator("iframe[src*='captcha']").count() > 0:
        return {"status": "NEED_CAPTCHA", "message": "Shopee yêu cầu CAPTCHA; giữ trình duyệt mở để xử lý."}
    if "/verify/email-link" in url or "verify your identity" in text or "xác minh danh tính" in text:
        return {"status": "NEED_VERIFY", "message": "Shopee yêu cầu xác minh danh tính."}
    if any(value in text for value in ("mã otp", "verification code", "mã xác nhận", "xác minh qua sms")):
        return {"status": "NEED_OTP", "message": "Shopee yêu cầu OTP hoặc mã xác nhận."}
    if any(value in text for value in ("incorrect password", "sai mật khẩu", "mật khẩu không đúng", "invalid password")):
        return {"status": "BAD_CREDENTIALS", "message": "Shopee báo sai thông tin đăng nhập."}
    if any(value in text for value in ("unusual activity", "automated tools", "tài khoản đã bị khóa", "account locked")):
        return {"status": "ACCOUNT_LOCKED", "message": "Shopee cảnh báo hoặc khóa tài khoản."}
    return {"status": "PENDING", "message": "đang chờ kết quả đăng nhập."}


async def type_and_login(page, username: str, password: str) -> dict[str, str]:
    if await login_proof(page):
        return {"status": "SUCCESS", "message": "SPC_F/profile đã đăng nhập Shopee."}
    user = await first_visible(page, [
        "input[name='loginKey']", "input[autocomplete='username']",
        "input[name='username']", "form input[type='text']",
    ])
    secret = await first_visible(page, [
        "input[name='password']", "input[autocomplete='current-password']",
        "input[type='password']",
    ])
    if user is None or secret is None:
        state = await classify_login(page)
        if state["status"] != "PENDING":
            return state
        return {"status": "LOGIN_TIMEOUT", "message": "không tìm thấy form đăng nhập Shopee."}
    await user.click()
    await asyncio.sleep(random.uniform(0.12, 0.25))
    await user.press("Control+a")
    await user.press("Backspace")
    await asyncio.sleep(random.uniform(0.08, 0.16))
    for ch in username:
        await user.press_sequentially(ch, delay=random.randint(55, 135))
        await asyncio.sleep(random.uniform(0.01, 0.05))
    await asyncio.sleep(random.uniform(0.25, 0.55))
    await secret.click()
    await asyncio.sleep(random.uniform(0.12, 0.25))
    await secret.press("Control+a")
    await secret.press("Backspace")
    await asyncio.sleep(random.uniform(0.08, 0.16))
    for ch in password:
        await secret.press_sequentially(ch, delay=random.randint(50, 125))
        await asyncio.sleep(random.uniform(0.01, 0.04))
    await asyncio.sleep(random.uniform(0.35, 0.70))
    if (await user.input_value()) != username or (await secret.input_value()) != password:
        return {"status": "LOGIN_TIMEOUT", "message": "không điền được đầy đủ username/password."}
    submit = await first_visible(page, [
        "form button[type='submit']", "button[type='submit']",
        "form button.b5aVaf", "button.b5aVaf.PVSuiZ", "button.b5aVaf",
        "button[aria-label='Đăng nhập']", "button[aria-label='Log in']",
    ], timeout_ms=10000)
    if submit is not None:
        deadline = asyncio.get_running_loop().time() + 10
        while await submit.is_disabled() and asyncio.get_running_loop().time() < deadline:
            await asyncio.sleep(0.25)
        if not await submit.is_disabled():
            await submit.click()
        else:
            await secret.press("Enter")
    else:
        await secret.press("Enter")
    deadline = asyncio.get_running_loop().time() + 30
    while asyncio.get_running_loop().time() < deadline:
        state = await classify_login(page)
        if state["status"] != "PENDING":
            return state
        await asyncio.sleep(0.75)
    return {"status": "LOGIN_TIMEOUT", "message": "hết thời gian chờ kết quả đăng nhập; giữ trình duyệt mở."}


async def run(payload: dict[str, Any]) -> None:
    runtime_root = Path(payload["runtime_root"]).resolve()
    profiles_root = Path(payload["profiles_root"]).resolve()
    user_data_dir = Path(payload["user_data_dir"]).resolve()
    profile_id = str(payload.get("profile_id") or "shardx-test").strip()
    runtime_profile_id = user_data_dir.name
    target_url = str(payload.get("target_url") or "https://shopee.vn/buyer/login")
    proxy = str(payload.get("proxy") or "").strip() or None
    login_username = str(payload.get("login_username") or "").strip()
    password = str(payload.get("password") or "")
    spc_f = str(payload.get("spc_f") or "").strip()
    cookie_text = str(payload.get("cookie") or "")
    if not spc_f and cookie_text:
        # App C# chỉ gửi `cookie` dạng "SPC_F=<value>;", không gửi khoá `spc_f`.
        for part in cookie_text.split(";"):
            name, _, value = part.strip().partition("=")
            if name == "SPC_F":
                spc_f = value.strip()
                break
    automation_mode = bool(payload.get("automation_mode"))
    if not automation_mode and (not login_username or not password or not spc_f):
        raise ValueError("login_username, password and spc_f are required")
    if automation_mode and not login_username:
        raise ValueError("login_username is required for automation")
    extension_paths = list(payload.get("extension_paths") or [])
    actions = {name.strip(): True for name in str(payload.get("automation_actions") or "").split(",") if name.strip()}
    if actions.get("addToCart"):
        rate = max(0, min(100, int(payload.get("automation_add_to_cart_percent") or 0)))
        actions["addToCart"] = rate >= 100 or (rate > 0 and random.randrange(100) < rate)
    items = json.loads(str(payload.get("automation_keywords_json") or "[]"))
    direct_payload = {
        "account": login_username,
        "user": login_username,
        "password": password,
        "cookie": cookie_text,
        "items": items,
        "actions": actions,
        "maxSearchPages": int(payload.get("automation_max_search_pages") or 2),
        "captchaWaitSeconds": max(1, int(payload.get("automation_captcha_wait_seconds") or 9)),
        "productViewPauseMin": int(payload.get("automation_product_view_min") or 15),
        "productViewPauseMax": int(payload.get("automation_product_view_max") or 25),
        "loadImages": bool(payload.get("load_images", True)),


    }
    extension_args = load_extension_args(extension_paths)
    browser_extra_args = [str(value) for value in (payload.get("browser_extra_args") or []) if str(value).strip()]
    if "--mute-audio" not in browser_extra_args:
        browser_extra_args.append("--mute-audio")
    extension_args.extend(browser_extra_args)
    sdk, seed = create_offline_sdk(runtime_root, profiles_root)
    if automation_mode:
        import shardx

    saved = user_data_dir / "profile.json"
    profile_was_saved = saved.is_file()
    if profile_was_saved:
        from shardx.profile import Profile
        profile = Profile(json.loads(saved.read_text(encoding="utf-8")), id=runtime_profile_id)
    else:
        profile = prepare_new_windows_profile(sdk, profile_id, runtime_profile_id, saved)
    prepare_profile_state(user_data_dir)
    stop_event = threading.Event()
    threading.Thread(target=stop_reader, args=(stop_event,), daemon=True).start()
    emit(f"SIDECAR_PROTOCOL:{PROTOCOL}")
    emit(f"PROFILE_ID:{profile_id}")
    emit(f"PROFILE_DIR:{user_data_dir}")
    async with sdk.session(
        profile,
        proxy=proxy,
        headless=False,
        screen_mode="use_host",
        # ShardX appends profile.id to this base. Pass the parent so the
        # effective UDD remains exactly `<PathDataCache>\CacheSeoShopee\sdx-<username>`.
        user_data_dir=user_data_dir.parent,
        extra_args=extension_args,
    ) as browser:
        session = browser._shardx
        emit(f"BROWSER_PID:{session.pid}")
        context = browser.contexts[0]
        if not automation_mode:
            await context.add_cookies([{
                "name": "SPC_F",
                "value": spc_f,
                "domain": ".shopee.vn",
                "path": "/",
                "secure": True,
                "httpOnly": False,
                "sameSite": "Lax",
            }])
            imported = await context.cookies("https://shopee.vn/")
            actual_spc_f = next((item.get("value") for item in imported if item.get("name") == "SPC_F"), None)
            if actual_spc_f != spc_f:
                raise RuntimeError("SPC_F import verification failed")
        page = context.pages[0] if context.pages else await context.new_page()
        if page.url.startswith("chrome://shardx"):
            # Lưới an toàn: marker đã chặn tab welcome, nhưng session khôi phục
            # vẫn có thể mở lại trang này.
            await page.goto("about:blank", wait_until="commit", timeout=15000)
        # Cửa sổ đầu tiên: proxy có thể chập chờn ngay sau khi cấp IP, nên thử lại vài lần
        # trước khi để sidecar thoát. Thoát ở đây làm cả phiên nick mất trắng.
        last_navigation_error = None
        for navigation_attempt in range(1, 4):
            try:
                await page.goto(target_url, wait_until="commit", timeout=60000)
                last_navigation_error = None
                break
            except Exception as ex:
                last_navigation_error = ex
                diagnostic(
                    f"SHARDX_SIDECAR_NAVIGATION_RETRY attempt={navigation_attempt} "
                    f"error={type(ex).__name__}: {ex}"
                )
                if navigation_attempt < 3:
                    await asyncio.sleep(4)
        if last_navigation_error is not None:
            raise last_navigation_error
        try:
            await page.wait_for_load_state("domcontentloaded", timeout=20000)
        except Exception:
            pass
        if automation_mode:
            from shardx_shopee_runner import DirectPatchrightRunner
            motion_session = None
            motion_supported = False
            try:
                motion_session = await browser.new_browser_cdp_session()
                await motion_session.send("Motion.createPointer", {"x": 64, "y": 64})
                await motion_session.send("Motion.destroyPointer")
                motion_supported = True
            except Exception:
                motion_session = None
            target_motion_session = None
            target_motion_supported = False
            try:
                target_motion_session = await context.new_cdp_session(page)
                await target_motion_session.send("Motion.createPointer", {"x": 64, "y": 64})
                await target_motion_session.send("Motion.destroyPointer")
                target_motion_supported = True
            except Exception:
                pass
            if not motion_supported and target_motion_supported and target_motion_session is not None:
                motion_session = target_motion_session
                motion_supported = True
            if not motion_supported or motion_session is None:
                raise RuntimeError("ShardX Motion unavailable; verify SDK/runtime 2.0.2 and --shardx-automation")
            runner = DirectPatchrightRunner(
                context,
                page,
                direct_payload,
                stop_event,
                emit,
                Path(__file__).resolve().parent / "ShardXAutomationScripts",
                session.pid,
                motion_session,
            )
            emit("LOGIN_RESULT:" + json.dumps({"status":"AUTOMATION","message":"đã khởi động ShardX direct runner."}, ensure_ascii=False, separators=(",", ":")))
            emit("READY")
            try:
                await runner.run()
            except asyncio.CancelledError:
                raise
            except Exception as ex:
                diagnostic(f"SHARDX_RUNNER_ERROR: {type(ex).__name__}: {ex}")
                emit("AUTOMATION_RUNNER_ERROR: " + type(ex).__name__)
                # Keep Chromium open for inspection instead of unwinding the
                # ShardX context manager and closing it after an automation bug.
                while not stop_event.is_set() and browser.is_connected():
                    process = getattr(session, "process", None)
                    if process is not None and process.poll() is not None:
                        break
                    await asyncio.sleep(0.25)
        else:
            login_result = await type_and_login(page, login_username, password)
            emit("LOGIN_RESULT:" + json.dumps(login_result, ensure_ascii=False, separators=(",", ":")))
            emit("READY")
        password = ""
        spc_f = ""
        while not stop_event.is_set() and not automation_mode:
            # BrowserSession 2.0.1 exposes the subprocess as `process`.
            # Keep compatibility with SDK builds that do not expose it: the
            # Patchright browser connection will be closed by the context
            # manager when STOP/EOF ends this loop.
            process = getattr(session, "process", None)
            if process is not None and process.poll() is not None:
                break
            if not browser.is_connected():
                break
            await asyncio.sleep(0.25)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("--payload")
    parser.add_argument("--validate-only", action="store_true")
    parser.add_argument("--data-root")
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        if args.validate_only:
            if not args.data_root:
                raise ValueError("--data-root is required with --validate-only")
            data_root = Path(args.data_root).resolve()
            create_offline_sdk(data_root / "Runtime", data_root / "Profiles")
            emit("VALID")
            return 0
        if not args.payload:
            raise ValueError("--payload is required")
        payload = load_payload(Path(args.payload).resolve())
        asyncio.run(run(payload))
        return 0
    except Exception as ex:
        diagnostic(f"SHARDX_SIDECAR_ERROR: {type(ex).__name__}: {ex}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

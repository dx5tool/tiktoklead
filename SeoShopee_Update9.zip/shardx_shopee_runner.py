from __future__ import annotations

import asyncio
import random
import re
import unicodedata
from pathlib import Path
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlsplit, urlunsplit

from shopee_automation_state import AutomationStateMachine


# The visit ladder is fixed: whole-marketplace search, then the shop's own listings, then
# the saved link entered through Facebook, then the saved link directly. Every rung ends on
# its own evidence (product found, no next page, empty result page), so the ladder is
# bounded by page counts instead of a wall clock. A 45-second wall-clock budget sat here
# before and skipped the shop rung on exactly the runs that needed it: two scanned search
# pages already cost ~75 seconds, so the run fell from the marketplace search straight to
# Facebook while the shop was never read.
#
# The ceiling below covers the whole ladder - both search rungs, the Facebook hop and the
# direct link - because a task killed at the ceiling aborts the keyword and the visit is lost.
OPEN_PRODUCT_TASK_TIMEOUT_SECONDS = 420.0
# The keyword ceiling sits above the sum of its task ceilings, so it only fires when a task
# overran its own timeout instead of cutting the keyword short while the ladder is still
# climbing (search, shop, Facebook, scroll, interactions).
KEYWORD_TASK_BUDGET_SECONDS = 900.0
# The shop rung walks every page of an in-shop query until Shopee reports no next page; this
# cap only bounds a pathological query.
SHOP_SEARCH_PAGE_SAFETY_CAP = 10
# The shop rung's own budget. A query matching hundreds of listings would otherwise walk pages
# until the task ceiling killed the keyword, which loses the visit; stopping here keeps the
# ladder moving to the Facebook hop the operator asked for, and the pages already read stay
# valid evidence.
SHOP_SEARCH_BUDGET_SECONDS = 240.0
# Two challenges seen within this window belong to the same block: the search task and the
# product task both notice the same interstitial seconds apart, and it must count once. A
# challenge on another keyword or product starts the streak over instead of adding to it.
CAPTCHA_SAME_HIT_WINDOW_SECONDS = 2.0
# The nick is closed after three challenges in a row on the same keyword and product; every
# earlier hit is recovered from and the run keeps going.
CAPTCHA_CONSECUTIVE_LIMIT = 3
# Shopee renders a whole results page in one grid of this many cards, and search.js stops
# collecting at the same count. A page that already reads full cannot reveal anything more,
# so the scan ends there instead of spending four more wheel passes proving it is stable.
SEARCH_PAGE_ITEM_CAP = 60
# Tổng thời gian xem Video/Ảnh của một sản phẩm. Dưới 5 giây thì chưa đủ để tính là đã xem,
# còn quá 10 giây chỉ kéo dài lượt chạy mà không thêm tín hiệu nào. Mọi khoảng chờ trong
# khâu này đều lấy phần ngân sách còn lại, và phần chưa đủ 5 giây được ngồi thêm cho tròn.
PRODUCT_MEDIA_VIEW_MIN_SECONDS = 5.0
PRODUCT_MEDIA_VIEW_MAX_SECONDS = 10.0
# Thời gian để đóng popup ảnh/video sau khi xem xong: ngân sách 10 giây phải chừa sẵn
# khoản này, nếu không việc đóng popup sẽ đẩy tổng thời gian vượt trần.
PRODUCT_MEDIA_CLOSE_RESERVE_SECONDS = 1.2


def product_media_time_left(started_at, reserve=PRODUCT_MEDIA_CLOSE_RESERVE_SECONDS, now=None):
    """Số giây còn lại của ngân sách xem ảnh/video, đã trừ thời gian cần để đóng popup."""
    current = asyncio.get_running_loop().time() if now is None else float(now)
    return PRODUCT_MEDIA_VIEW_MAX_SECONDS - (float(current) - float(started_at)) - float(reserve)


# The cart drawer slides over the product page while the run is reading it. It is hidden
# only after Shopee has accepted the login, and it is injected as a document-level style so
# every later navigation carries the rule without another round trip.
HIDE_CART_DRAWER_JS = """
(() => {
  const ID = 'shardx-hide-cart-drawer';
  const CSS = 'div.cart-drawer-container{display:none !important;visibility:hidden !important;pointer-events:none !important;}';
  const apply = () => {
    if (document.getElementById(ID)) return true;
    const root = document.head || document.documentElement;
    if (!root) return false;
    const style = document.createElement('style');
    style.id = ID;
    style.textContent = CSS;
    root.appendChild(style);
    return true;
  };
  if (!apply()) document.addEventListener('DOMContentLoaded', apply, { once: true });
})();
"""


def _fold_name(value) -> str:
    """Lowercase, strip diacritics and punctuation - the same fold search.js applies."""
    text = unicodedata.normalize("NFD", str(value or "")).lower()
    text = "".join(ch for ch in text if not unicodedata.combining(ch))
    text = text.replace("đ", "d")
    return re.sub(r"[^a-z0-9]+", " ", text).strip()


def build_product_lookup(product_id, product_name, product_url) -> dict:
    """Resolve the saved product into an item id and/or name tokens.

    `product_id` arrives as whatever KeywordTrackingStore.ExtractProductIdFromLink
    produced ("i.<shopId>.<itemId>"), and that helper returns an empty string when the
    operator saved a short redirector link rather than a canonical product URL. The
    canonical URL is the last chance to recover the item id; when even that fails, the
    product name is the only key the scan has left.
    """
    item_id = ""
    shop_id = ""
    raw_id = str(product_id or "").strip()
    for candidate in (raw_id, str(product_url or "").strip()):
        if not candidate:
            continue
        match = re.search(r"(?:-i\.|i\.|/product/|^)(\d+)(?:[./](\d+))?", candidate, re.IGNORECASE)
        if not match:
            continue
        first, second = match.group(1), match.group(2)
        if second:
            shop_id, item_id = first, second
        elif len(first) >= 6:
            item_id = first
        if item_id:
            break
    tokens = [token for token in _fold_name(product_name).split(" ") if len(token) >= 3]
    raw_name = str(product_name or "").strip()
    return {
        "item_id": item_id,
        "shop_id": shop_id,
        "item_id_from_url": bool(item_id) and not raw_id,
        "name_tokens": tokens,
        "raw_name": raw_name,
        # A title search needs enough words to be specific about one listing; a two-word
        # name is a category query and would return the same page the keyword did.
        "title_query": raw_name if len(tokens) >= 3 else "",
    }



class DirectPatchrightRunner:
    def __init__(self, context, page, payload, stop_event, emit, scripts_root: Path, browser_pid: int | None = None, motion_session=None):
        self.context = context
        self.page = page
        self.payload = payload
        self.stop_event = stop_event
        self.emit = emit
        self.browser_pid = int(browser_pid or 0)
        if motion_session is None:
            raise ValueError("motion_session is required")
        self.motion_session = motion_session
        self._motion_pointer_created = False
        self.scripts = {p.stem: p.read_text(encoding="utf-8") for p in scripts_root.glob("*.js")}
        self.machine = AutomationStateMachine(payload, emit)
        self.logged_in = False
        self.last_product = None
        self.on_shop = False
        self._workflow_stage = "startup"

        self._pending_navigation_risk = ""
        self._pending_navigation_risk_url = ""
        self._pending_navigation_risk_source = {}

        self._captcha_occurrences = 0
        # The streak that closes a nick follows one keyword + one product; it is reset by
        # a challenge elsewhere and by the window above when the same block is seen twice.
        self._captcha_consecutive = 0
        self._captcha_scope_seen = None
        self._captcha_last_hit_at = 0.0
        self._last_product_url = ""
        self._last_product_open_method = ""
        self._last_shop_url = ""
        self._skip_media_for_current_product = False
        self._cart_drawer_hidden = False

        self.page.on("framenavigated", self._capture_risk_navigation)

    async def _motion_ensure_pointer(self):
        if self.motion_session is None:
            raise RuntimeError("ShardX Motion session is required")
        if self._motion_pointer_created:
            return
        try:
            dims = await self.page.evaluate("() => [window.innerWidth, window.innerHeight]")
            if isinstance(dims, (list, tuple)) and len(dims) >= 2:
                width, height = float(dims[0]), float(dims[1])
            else:
                width, height = 1280.0, 800.0
        except Exception:
            width, height = 1280.0, 800.0

        # Natural cursor start position (upper-central area near toolbar / search region)
        start_x = round(float(width) * random.uniform(0.25, 0.65))
        start_y = round(float(height) * random.uniform(0.12, 0.40))

        account_key = str(self.payload.get("user") or self.payload.get("account") or "shardx_runner")
        account_seed = sum((idx + 1) * ord(c) for idx, c in enumerate(account_key))
        rng = random.Random(account_seed)
        # Unique individual pace scale per profile (human speed variation: 0.92 - 1.22)
        pace_scale = round(rng.uniform(0.92, 1.22), 3)

        await self.motion_session.send("Motion.createPointer", {
            "x": start_x,
            "y": start_y,
            "paceScale": pace_scale,
            "seed": account_seed % 1000000,
        })
        self._motion_pointer_created = True
        await asyncio.sleep(random.uniform(0.08, 0.18))

    async def _motion_click_at(self, x, y, target_width=None, click_count=1):
        await self._motion_ensure_pointer()
        # Fitts's law: targetWidth drives human deceleration and precision
        result = await self.motion_session.send("Motion.glideTo", {
            "x": round(float(x)),
            "y": round(float(y)),
            "targetWidth": max(1, round(float(target_width or 48))),
        })
        # Dwell time: eye-hand coordination confirmation delay before pressing button (70ms - 180ms)
        await asyncio.sleep(random.uniform(0.07, 0.18))
        await self.motion_session.send("Motion.tap", {
            "button": "left",
            "clickCount": max(1, min(3, int(click_count))),
        })
        # Post-click observation hesitation (100ms - 220ms)
        await asyncio.sleep(random.uniform(0.10, 0.22))
        return result or {}

    async def _motion_click_locator(self, locator, click_count=1, timeout=15000):
        await locator.wait_for(state="visible", timeout=timeout)
        await locator.scroll_into_view_if_needed(timeout=timeout)
        box = await locator.bounding_box(timeout=timeout)
        if not box:
            raise RuntimeError("Motion target has no bounding box")
        # Organic Gaussian distribution centered around element midpoint
        rel_x = max(0.18, min(0.82, random.gauss(0.5, 0.11)))
        rel_y = max(0.20, min(0.80, random.gauss(0.5, 0.10)))
        x = float(box["x"]) + float(box["width"]) * rel_x
        y = float(box["y"]) + float(box["height"]) * rel_y
        await self._motion_click_at(x, y, box.get("width"), click_count)
        return {"x": x, "y": y, "box": box}

    async def _motion_fill_locator(self, locator, value, allow_typos=False):
        # Click once naturally to focus
        await self._motion_click_locator(locator, click_count=1)
        await asyncio.sleep(random.uniform(0.08, 0.16))
        # Clear existing text using natural select-all and backspace
        await self._motion_press_key("a", modifiers=["Control"])
        await asyncio.sleep(random.uniform(0.05, 0.12))
        await self._motion_press_key("Backspace")
        await asyncio.sleep(random.uniform(0.10, 0.20))
        result = await self.motion_session.send("Motion.enterText", {
            "text": str(value),
            "allowTypos": bool(allow_typos),
        })
        await asyncio.sleep(random.uniform(0.12, 0.28))
        return result or {}

    async def _motion_press_key(self, key, modifiers=None):
        await self._motion_ensure_pointer()
        params = {"key": str(key)}
        if modifiers:
            params["modifiers"] = list(modifiers)
        return await self.motion_session.send("Motion.pressKey", params)

    async def _motion_look_at(self, x, y, target_width=None, dwell=None):
        """Glide the cursor onto a target and hold it there without pressing - a human reading/aiming."""
        await self._motion_ensure_pointer()
        await self.motion_session.send("Motion.glideTo", {
            "x": round(float(x)),
            "y": round(float(y)),
            "targetWidth": max(1, round(float(target_width or 90))),
        })
        await asyncio.sleep(dwell if dwell is not None else random.uniform(0.25, 0.60))

    async def _motion_wheel(self, delta_y, x=None, y=None, delta_x=0):
        await self._motion_ensure_pointer()
        if x is not None and y is not None:
            await self.motion_session.send("Motion.glideTo", {
                "x": round(float(x)),
                "y": round(float(y)),
                "targetWidth": 64,
            })
            await asyncio.sleep(random.uniform(0.05, 0.12))
        else:
            try:
                dims = await self.page.evaluate("() => [window.innerWidth, window.innerHeight]")
                if isinstance(dims, (list, tuple)) and len(dims) >= 2:
                    width, height = float(dims[0]), float(dims[1])
                else:
                    width, height = 1280.0, 800.0
            except Exception:
                width, height = 1280.0, 800.0
            target_x = round(float(width) * random.uniform(0.38, 0.62))
            target_y = round(float(height) * random.uniform(0.35, 0.65))
            await self.motion_session.send("Motion.glideTo", {
                "x": target_x,
                "y": target_y,
                "targetWidth": 80,
            })
            await asyncio.sleep(random.uniform(0.05, 0.12))

        abs_y = abs(float(delta_y))
        direction = 1 if float(delta_y) >= 0 else -1

        # Small scroll delta: single natural notch
        if abs_y <= 120:
            params = {"deltaY": float(delta_y)}
            if delta_x:
                params["deltaX"] = float(delta_x)
            result = await self.motion_session.send("Motion.wheel", params)
            await asyncio.sleep(random.uniform(0.08, 0.18))
            return result

        # Larger scroll: break into multi-tick momentum decay bursts (finger rolling wheel)
        num_ticks = max(2, min(4, int(abs_y // 75) + 1))
        weights = [1.4, 1.0, 0.7, 0.4][:num_ticks]
        total_w = sum(weights)

        last_result = {}
        for w in weights:
            chunk = round(abs_y * (w / total_w) * direction)
            if chunk == 0:
                continue
            params = {"deltaY": float(chunk)}
            if delta_x:
                params["deltaX"] = float(delta_x) / num_ticks
            last_result = await self.motion_session.send("Motion.wheel", params)
            await asyncio.sleep(random.uniform(0.035, 0.085))

        # Subtle human overshoot recovery for larger scrolls (~18% chance)
        if abs_y >= 200 and random.random() < 0.18:
            await asyncio.sleep(random.uniform(0.18, 0.35))
            rebound = -direction * random.randint(30, 65)
            await self.motion_session.send("Motion.wheel", {"deltaY": float(rebound)})
            await asyncio.sleep(random.uniform(0.06, 0.14))

        return last_result
    async def _human_scan_scroll(self, pass_index):
        """One read-like scroll while scanning a listing.

        The scan used to wheel a fixed 450-680px every 0.55-1.05s for sixteen identical
        passes. Nothing about that rhythm is human: real reading is uneven bursts with
        pauses to actually look at what appeared, and the occasional correction upward.
        """
        if random.random() < 0.30:
            amount = random.randint(140, 260)
        elif random.random() < 0.75:
            amount = random.randint(320, 520)
        else:
            amount = random.randint(560, 760)
        await self._motion_wheel(amount)
        # An eighth of the passes stop to read before moving on. The operator asked for the
        # scan to stop burning time on pauses nobody acts on, so every beat here is shorter
        # than it used to be - the uneven rhythm is what matters, not the length of the pause.
        if random.random() < 0.12:
            await asyncio.sleep(random.uniform(1.6, 3.0))
        else:
            await asyncio.sleep(random.uniform(0.30, 0.90))
        # Occasionally look back at something that scrolled past.
        if pass_index >= 2 and random.random() < 0.15:
            await self._motion_wheel(-random.randint(60, 140))
            await asyncio.sleep(random.uniform(0.4, 0.9))

    async def _page_scroll_state(self):
        return await self.page.evaluate("() => ({scrollY: window.scrollY, height: document.documentElement.scrollHeight, bottom: window.scrollY + window.innerHeight >= document.documentElement.scrollHeight - 100})")

    async def _human_dwell_browsing(self, total_seconds: float):
        """Simulate a human reading product details: eye-reading mouse paths, gentle micro-scrolls, and attentive pauses."""
        deadline = asyncio.get_running_loop().time() + max(1.0, float(total_seconds))
        try:
            dims = await self.page.evaluate("() => [window.innerWidth, window.innerHeight]")
            if isinstance(dims, (list, tuple)) and len(dims) >= 2:
                width, height = float(dims[0]), float(dims[1])
            else:
                width, height = 1280.0, 800.0
        except Exception:
            width, height = 1280.0, 800.0

        while asyncio.get_running_loop().time() < deadline:
            if self.stop_event.is_set() or self._pending_navigation_risk or self._captcha_navigation_active():
                break
            remaining = deadline - asyncio.get_running_loop().time()
            if remaining <= 0.5:
                break
            action_type = random.choices(["read_hover", "micro_scroll", "reading_pause"], weights=[40, 25, 35])[0]
            if action_type == "read_hover":
                target_x = round(float(width) * random.uniform(0.20, 0.65))
                target_y = round(float(height) * random.uniform(0.25, 0.70))
                try:
                    await self.motion_session.send("Motion.glideTo", {
                        "x": target_x,
                        "y": target_y,
                        "targetWidth": random.randint(80, 180),
                    })
                except Exception:
                    pass
                dwell = min(remaining, random.uniform(1.8, 3.8))
                await asyncio.sleep(dwell)
            elif action_type == "micro_scroll":
                delta = random.randint(70, 150) if random.random() < 0.75 else -random.randint(40, 90)
                try:
                    await self.motion_session.send("Motion.wheel", {"deltaY": float(delta)})
                except Exception:
                    pass
                dwell = min(remaining, random.uniform(1.5, 3.2))
                await asyncio.sleep(dwell)
            else:
                dwell = min(remaining, random.uniform(2.0, 4.0))
                await asyncio.sleep(dwell)

    async def _block_product_ratings(self, route):
        await route.abort("blockedbyclient")

    def _capture_risk_navigation(self, frame):
        try:
            if frame != self.page.main_frame:
                return
            parts = urlsplit(str(frame.url or ""))
            path = (parts.path or "").lower()
            if path.startswith("/verify/traffic") or path.startswith("/verify/captcha") or "/captcha" in path:
                self._pending_navigation_risk = "NEED_CAPTCHA"
                self._pending_navigation_risk_url = str(frame.url or "")
                self._pending_navigation_risk_source = {"path": parts.path, "stage": self._workflow_stage}
        except Exception:
            pass

    async def evaluate(self, module: str, action: str, args=None):
        last_error = None
        for attempt in range(4):
            if self.stop_event.is_set():
                raise asyncio.CancelledError()
            try:
                return await self.page.evaluate(
                    self.scripts[module],
                    {"action": action, "args": args or {}},
                )
            except Exception as ex:
                last_error = ex
                text = str(ex).lower()
                navigation_race = (
                    "execution context was destroyed" in text
                    or "cannot find context with specified id" in text
                    or "target page, context or browser has been closed" in text
                )
                if not navigation_race or attempt >= 3:
                    raise
                try:
                    await self.page.wait_for_load_state("domcontentloaded", timeout=8000)
                except Exception:
                    await asyncio.sleep(0.4)
        raise last_error

    async def risk(self):
        result = await self.evaluate("common", "risk")
        detected = result.get("risk") or ""
        if detected:
            self._pending_navigation_risk = detected
            if not getattr(self, "_pending_navigation_risk_source", None):
                self._pending_navigation_risk_source = {"path": result.get("hrefPath") or "", "stage": self._workflow_stage}
        latched = getattr(self, "_pending_navigation_risk", "")
        if result.get("trafficGate"):
            await self.page.goto("https://shopee.vn/buyer/login?next=https%3A%2F%2Fshopee.vn%2F", wait_until="commit", timeout=60000)
            return ""
        return detected or latched

    def _clear_pending_navigation_risk(self):
        self._pending_navigation_risk = ""
        self._pending_navigation_risk_url = ""
        self._pending_navigation_risk_source = {}

    def _captcha_navigation_active(self):
        path = urlsplit(str(self.page.url or "")).path.lower()
        return (
            str(getattr(self, "_pending_navigation_risk", "") or "") == "NEED_CAPTCHA"
            or path.startswith("/verify/traffic")
            or path.startswith("/verify/captcha")
            or "/captcha" in path
        )

    def _captcha_recovery_target(self):
        source = dict(getattr(self, "_pending_navigation_risk_source", {}) or {})
        stage = str(source.get("stage") or getattr(self, "_workflow_stage", "") or "").lower()
        home_prefixes = ("task_search", "search_", "task_open_home", "login_", "startup_")
        shop_prefixes = ("task_view_shop", "view_shop", "task_scroll_shop", "scroll_shop", "task_follow_shop", "follow_shop")
        product_prefixes = ("task_open_product", "task_interact_product", "task_scroll_product", "media_", "like_", "cart_", "variant_", "review_", "scroll_product")
        if stage.startswith(home_prefixes):
            return "HOME", "https://shopee.vn/"
        if stage.startswith(shop_prefixes) and str(getattr(self, "_last_shop_url", "") or ""):
            return "SHOP", str(self._last_shop_url)
        if stage.startswith(product_prefixes) and str(getattr(self, "_last_product_url", "") or ""):
            return "PRODUCT", str(self._last_product_url)
        if bool(getattr(self, "on_shop", False)) and str(getattr(self, "_last_shop_url", "") or ""):
            return "SHOP", str(self._last_shop_url)
        if str(getattr(self, "_last_product_url", "") or ""):
            return "PRODUCT", str(self._last_product_url)
        return "HOME", "https://shopee.vn/"

    async def _recover_captcha_context(self, context, target_url, attempt):
        self.machine.log(f"CAPTCHA_RECOVER_BEGIN attempt={attempt} context={context}")
        self._workflow_stage = "captcha_recover_" + context.lower()
        self._clear_pending_navigation_risk()
        error_type = ""
        try:
            await self.page.goto(target_url, wait_until="domcontentloaded", timeout=60000)
        except Exception as ex:
            error_type = type(ex).__name__
        recovery_risk = await self.risk()
        current_url = str(self.page.url or "")
        target_path = urlsplit(str(target_url or "")).path.rstrip("/") or "/"
        current_path = urlsplit(current_url).path.rstrip("/") or "/"
        context_matches = current_path == target_path
        recovered = not recovery_risk and not error_type and context_matches
        if recovered:
            if context == "SHOP":
                self.on_shop = True
                self._last_shop_url = current_url
            elif context == "PRODUCT":
                self.on_shop = False
                self._last_product_url = current_url

            else:
                self.on_shop = False
            self.machine.log(f"CAPTCHA_RECOVER_OK context={context}")
        else:
            self.machine.log(f"CAPTCHA_RECOVER_RETRY attempt={attempt} context={context}")
        return recovered, recovery_risk

    async def wait_after_captcha(self):
        """Wait for a manually resolved Captcha and then re-check the page.

        Only the login flow asks for this wait: a challenge met while the keywords run is
        answered by re-entering the product, not by parking the run for the operator.
        """
        wait_seconds = max(1, int(self.payload.get("captchaWaitSeconds") or 9))
        pending_url = str(getattr(self, "_pending_navigation_risk_url", "") or "")
        recovery_context, recovery_url = self._captcha_recovery_target()
        recovery_path = urlsplit(str(recovery_url or "")).path.rstrip("/") or "/"
        current_path = urlsplit(str(self.page.url or "")).path.lower()
        current_is_gate = current_path.startswith("/verify/traffic") or current_path.startswith("/verify/captcha") or "/captcha" in current_path
        if pending_url and not current_is_gate:
            try:
                await self.page.goto(pending_url, wait_until="commit", timeout=60000)
            except Exception:
                pass
        self.machine.risk("NEED_CAPTCHA", close=False)
        self.machine.log(f"CAPTCHA_WAIT_BEGIN seconds={wait_seconds}")
        wait_candidate_count = 0
        wait_deadline = asyncio.get_running_loop().time() + wait_seconds
        exit_state = {}
        remaining_risk = "NEED_CAPTCHA"
        while asyncio.get_running_loop().time() < wait_deadline:
            remaining_ms = wait_seconds * 1000 if wait_candidate_count == 0 else max(1, int((wait_deadline - asyncio.get_running_loop().time()) * 1000))
            try:
                await self.page.wait_for_function(r"""expectedPath => {
                    const path = location.pathname.replace(/\/$/, '') || '/';
                    const gate = /\/verify\/(?:traffic|captcha)|\/captcha/i.test(location.href)
                        || !!document.querySelector("iframe[src*='captcha']");
                    return !gate && path === expectedPath;
                }""", arg=recovery_path, timeout=remaining_ms)
            except Exception:
                break
            wait_candidate_count += 1
            try:
                confirmation_ms = max(1, min(10000, int((wait_deadline - asyncio.get_running_loop().time()) * 1000)))
                await self.page.wait_for_load_state("networkidle", timeout=confirmation_ms)
            except Exception:
                pass
            try:
                exit_state = await self.page.evaluate("""() => ({hrefPath:location.pathname,readyState:document.readyState,captchaUrl:/\\/verify\\/(?:traffic|captcha)|\\/captcha/i.test(location.href),captchaIframe:!!document.querySelector("iframe[src*='captcha']")})""", None)
            except Exception as ex:
                exit_state = {"errorType": type(ex).__name__}
            post_path = str(exit_state.get("hrefPath") or "").rstrip("/") or "/"
            post_path_lower = post_path.lower()
            post_still_gate = post_path_lower.startswith("/verify/traffic") or post_path_lower.startswith("/verify/captcha") or "/captcha" in post_path_lower or bool(exit_state.get("captchaIframe"))
            post_context_matches = post_path == recovery_path
            if post_still_gate or not post_context_matches:
                continue
            self._clear_pending_navigation_risk()
            remaining_risk = await self.risk()
            if remaining_risk == "NEED_CAPTCHA":
                continue
            break
        return remaining_risk

    def _current_keyword_item(self):
        """The automation queue item for the keyword that is running right now."""
        try:
            index = int(getattr(self.machine, "index", -1))
        except Exception:
            index = -1
        try:
            items = list(getattr(self.machine, "items", []) or [])
            if 0 <= index < len(items):
                return dict(items[index] or {})
        except Exception:
            pass
        return {}

    def _captcha_recovery_product(self):
        """Where the Facebook hop should land after a challenge.

        The product page that is already open wins; a challenge met before the product
        was opened (home or search stage) falls back to the saved link of the keyword
        that is running, so the recovery still enters the product the operator asked for.
        """
        current = str(getattr(self, "_last_product_url", "") or "").strip()
        if current:
            product_id = ""
            try:
                item = self._current_keyword_item()
                product_id = str(item.get("productId") or "").strip()
            except Exception:
                product_id = ""
            return current, product_id
        item = self._current_keyword_item()
        return str(item.get("productUrl") or "").strip(), str(item.get("productId") or "").strip()

    def _captcha_scope_key(self):
        """The keyword + product the current challenge belongs to.

        The operator's rule is that a nick is only closed after three challenges in a row
        on the same keyword and the same product. The challenge has to be attributed to a
        pair, so the current keyword item is read from the automation queue; a challenge
        seen under another pair starts the streak over.
        """
        try:
            index = int(getattr(self.machine, "index", -1))
        except Exception:
            index = -1
        item = self._current_keyword_item()
        keyword = str(item.get("keyword") or "").strip()
        product = str(item.get("productUrl") or item.get("productId") or "").strip()
        return (index, keyword, product)

    async def finish_unresolved_captcha(self):
        # The streak follows one keyword + one product: a challenge under the same pair
        # adds to it, a challenge under another pair starts it over, and the same block
        # noticed again within seconds is not counted twice. Only the third hit in a row
        # closes the account; hits one and two are recovered from and the run continues.
        scope_key = self._captcha_scope_key()
        now = asyncio.get_running_loop().time()
        last_hit_at = float(getattr(self, "_captcha_last_hit_at", 0.0) or 0.0)
        same_scope = scope_key == getattr(self, "_captcha_scope_seen", None)
        if same_scope and (now - last_hit_at) < CAPTCHA_SAME_HIT_WINDOW_SECONDS:
            self.machine.log("CAPTCHA_OCCURRENCE_DEDUPE")
            attempt = max(1, int(getattr(self, "_captcha_consecutive", 0) or 0))
        elif same_scope:
            self._captcha_consecutive = int(getattr(self, "_captcha_consecutive", 0) or 0) + 1
            attempt = self._captcha_consecutive
        else:
            self._captcha_scope_seen = scope_key
            self._captcha_consecutive = 1
            attempt = 1
        self._captcha_last_hit_at = now
        self._captcha_occurrences = int(getattr(self, "_captcha_occurrences", 0) or 0) + 1
        self.machine.log(f"CAPTCHA_OCCURRENCE attempt={attempt}")
        if attempt >= CAPTCHA_CONSECUTIVE_LIMIT:
            breaker_scope, _ = self._captcha_recovery_target()
            self.machine.log(f"CAPTCHA_CIRCUIT_BREAKER scope={breaker_scope}")
            self.machine.log("CAPTCHA_THIRD_OCCURRENCE")
            self.machine.risk("NEED_CAPTCHA", close=True)
            return False

        # No manual wait any more: the challenge is answered by entering the product the
        # indirect way, through a Facebook outbound link. When no product link is known on
        # this stage (the challenge hit the home or search page) the context page is opened
        # again and the run continues from there.
        stage = str(getattr(self, "_workflow_stage", "") or "").lower()
        product_url, product_id = self._captcha_recovery_product()
        if product_url:
            self.machine.log(f"CAPTCHA_RECOVER_VIA_FACEBOOK_BEGIN attempt={attempt}")
            if await self._navigate_via_facebook(product_url, product_id):
                self._clear_pending_navigation_risk()
                if stage.startswith("media_"):
                    # Re-entering the product drops the gallery that was open, so the media
                    # part of this product is skipped instead of being opened again.
                    self._skip_media_for_current_product = True
                self._last_product_url = str(self.page.url or product_url)
                self._last_product_open_method = "FACEBOOK_INDIRECT"
                self.machine.log("CAPTCHA_RECOVER_VIA_FACEBOOK_OK")
                return True
            self.machine.log("CAPTCHA_RECOVER_VIA_FACEBOOK_FAIL")

        context, target_url = self._captcha_recovery_target()
        recovered, _ = await self._recover_captcha_context(context, target_url, attempt)
        if recovered and context == "PRODUCT" and stage.startswith("media_"):
            # This fallback also reloads the product page directly, which drops the gallery
            # that was open, so the media part of this product is skipped here as well.
            self._skip_media_for_current_product = True
        return bool(recovered)

    async def close_post_login_popups(self):
        closed = 0
        for _ in range(2):
            deadline = asyncio.get_running_loop().time() + 6
            while asyncio.get_running_loop().time() < deadline:
                result = await self.evaluate("common", "popup")
                if result.get("closed"):
                    closed += 1
                    await asyncio.sleep(random.uniform(1.2, 2.2))
                    break
                await asyncio.sleep(.4)
        return closed

    async def _hide_cart_drawer_after_login(self):
        """Hide the Shopee cart drawer for the rest of the session.

        The drawer slides over the page whenever the pointer crosses the header cart, so
        it is hidden once the login is proven. The context init script covers every later
        document; the page evaluate covers the page already open at login time.
        """
        if getattr(self, "_cart_drawer_hidden", False):
            return
        self._cart_drawer_hidden = True
        try:
            await self.context.add_init_script(HIDE_CART_DRAWER_JS)
        except Exception:
            pass
        try:
            await self.page.evaluate(HIDE_CART_DRAWER_JS)
            self.machine.log("CART_DRAWER_HIDDEN")
        except Exception:
            pass

    async def _mark_logged_in(self):
        self.logged_in = True
        await self.close_post_login_popups()
        await self._hide_cart_drawer_after_login()

    async def import_cookies(self):
        pairs = []
        for part in str(self.payload.get("cookie") or "").split(";"):
            if "=" not in part:
                continue
            name, value = part.split("=", 1)
            if name.strip():
                pairs.append({"name":name.strip(),"value":value.strip(),"domain":".shopee.vn","path":"/","secure":True,"sameSite":"Lax"})
        if pairs:
            await self.context.add_cookies(pairs)
        expected = next((x["value"] for x in pairs if x["name"].upper() == "SPC_F"), "")
        actual = next((x.get("value") for x in await self.context.cookies("https://shopee.vn/") if x.get("name"," ").upper() == "SPC_F"), "")
        return {"spcFExpected":expected,"spcFActual":actual,"verified":bool(expected and expected == actual)}

    async def _set_login_field(self, locator, value, field_name):

        await locator.wait_for(state="visible", timeout=60000)

        actual = ""
        exact_match = False
        for attempt in range(1, 4):
            await self._motion_fill_locator(locator, value)
            actual = await locator.input_value()
            exact_match = str(actual or "") == value
            if exact_match:
                break

        if not exact_match:
            raise RuntimeError("login_field_value_mismatch")

    async def ensure_login(self):
        self._workflow_stage = "login_proof_check"
        proof = await self.evaluate("login", "proof")
        if proof.get("loginProof"):
            await self._mark_logged_in()
            return True
        user = str(self.payload.get("user") or "")
        password = str(self.payload.get("password") or "")
        if not user or not password:
            return False
        self._workflow_stage = "login_navigate_form"
        await self.page.goto("https://shopee.vn/buyer/login?next=https%3A%2F%2Fshopee.vn%2F", wait_until="commit", timeout=60000)
        u = self.page.locator("input[name='loginKey'],input[autocomplete='username']").first
        p = self.page.locator("input[name='password'],input[type='password']").first
        form_or_session = self.page.locator("input[name='loginKey'],input[autocomplete='username'],div.navbar__username,[class*='navbar__username']").first

        try:
            await form_or_session.wait_for(state="attached", timeout=60000)
            restored_proof = await self.evaluate("login", "proof")
            if restored_proof.get("loginProof"):

                await self._mark_logged_in()
                return True
            await u.wait_for(state="attached", timeout=60000)

            await p.wait_for(state="attached", timeout=60000)
        except Exception:
            restored_proof = await self.evaluate("login", "proof")
            if restored_proof.get("loginProof"):

                await self._mark_logged_in()
                return True
            return False

        await self._set_login_field(u, user, "username")
        await self._set_login_field(p, password, "password")

        button = self.page.locator("form button[type='submit'],button[type='submit'],button.b5aVaf").first

        if await button.count():
            await self._motion_click_locator(button)
        else:
            await self._motion_press_key("Enter")

        try:
            await self.page.wait_for_load_state("domcontentloaded", timeout=15000)
        except Exception:
            pass

        deadline = asyncio.get_running_loop().time() + 30
        while asyncio.get_running_loop().time() < deadline:
            risk = await self.risk()
            if risk == "NEED_CAPTCHA":
                risk = await self.wait_after_captcha()
                deadline = asyncio.get_running_loop().time() + 30
            if risk:
                self.machine.risk(risk, close=risk != "NEED_CAPTCHA")
                return False
            proof = await self.evaluate("login", "proof")
            if proof.get("loginProof"):

                await self._mark_logged_in()
                return True
            await asyncio.sleep(.75)

        return False

    def _task_timeout_seconds(self, kind, captcha_wait):
        """How long one queued task may run before the keyword gives up on it.

        Opening the product now carries the full visit ladder (marketplace search, shop
        pages, Facebook hop, direct link), so it needs its own ceiling; the other tasks
        keep the old 75-second shape.
        """
        wait = float(captcha_wait or 0)
        if str(kind or "").upper() == "OPEN_PRODUCT":
            return max(OPEN_PRODUCT_TASK_TIMEOUT_SECONDS, wait + 75.0)
        return max(75.0, wait + 75.0)

    async def run(self):
        if not bool(self.payload.get("loadImages", True)):
            await self.context.route("**/*", lambda route: route.abort() if route.request.resource_type == "image" else route.continue_())
        cookie_result = await self.import_cookies()
        self.machine.result("IMPORT_COOKIES", "OK" if cookie_result["verified"] else "SKIP", cookie_result)
        await self.page.goto("https://shopee.vn/", wait_until="commit", timeout=60000)
        await self.evaluate("common", "popup")
        if not await self.ensure_login():
            if not self.machine.done:
                self.emit("AUTOMATION_LOGIN_FAILED")
                self.machine.finish()
            return
        self.machine.start_next_keyword()
        while not self.machine.done and not self.stop_event.is_set():
            task = self.machine.next_task()
            if task is None:
                await asyncio.sleep(.1); continue
            kind, data = task["type"], task["payload"]
            if self.machine.keyword_started_at and asyncio.get_running_loop().time() - self.machine.keyword_started_at >= KEYWORD_TASK_BUDGET_SECONDS:
                self.machine.keyword_done(True)
                continue
            try:
                captcha_wait = max(1, int(self.payload.get("captchaWaitSeconds") or 9))
                await asyncio.wait_for(self.dispatch(kind, data), timeout=self._task_timeout_seconds(kind, captcha_wait))
                if not self.machine.done:
                    post_task_risk = await self.risk()
                    if post_task_risk == "NEED_CAPTCHA":
                        await self.finish_unresolved_captcha()
                    elif post_task_risk:
                        self.machine.risk(post_task_risk, close=True)
            except asyncio.TimeoutError:
                self.machine.result(kind, "TIMEOUT", {})
                if kind == "OPEN_PRODUCT":
                    self.machine.abort_current_keyword("OPEN_PRODUCT_TIMEOUT")
                elif self.machine.keyword_started_at and asyncio.get_running_loop().time() - self.machine.keyword_started_at >= KEYWORD_TASK_BUDGET_SECONDS:
                    self.machine.keyword_done(True)
            except Exception as ex:
                self.machine.result(kind, "ERROR", {"error":type(ex).__name__})
                if kind == "OPEN_PRODUCT":
                    self.machine.abort_current_keyword("OPEN_PRODUCT_EXCEPTION")
            if self.machine.keyword_started_at and not self.machine.done and asyncio.get_running_loop().time() - self.machine.keyword_started_at >= KEYWORD_TASK_BUDGET_SECONDS:
                self.machine.keyword_done(True)
        if self.stop_event.is_set(): self.machine.stop()

    async def dispatch(self, kind, data):
        self._workflow_stage = "task_" + str(kind or "unknown").lower()
        risk = await self.risk()
        if risk == "NEED_CAPTCHA":
            if not await self.finish_unresolved_captcha():
                return
            risk = ""
        if risk:
            self.machine.risk(risk, close=True)
            return
        if kind == "OPEN_HOME":
            self.machine.log("TASK_BEGIN " + kind)
            await self.page.goto("https://shopee.vn/", wait_until="commit", timeout=60000)
            self.on_shop = False
            self.machine.result(kind,"OK",{"href":self.page.url}); return
        if kind == "NEXT_KEYWORD":
            self.machine.log("TASK_BEGIN " + kind)
            self.machine.start_next_keyword(); return
        if kind == "KEYWORD_DONE":
            self.machine.log("TASK_BEGIN " + kind)
            self.machine.keyword_done(); return
        if kind == "SCROLL_SHOP" and not self.on_shop:
            self.machine.result(kind,"NOT_FOUND",{"reason":"SHOP_NOT_OPEN"}); return
        self.machine.log("TASK_BEGIN " + kind)
        if kind == "SEARCH_KEYWORD": await self.search(data); return
        if kind == "OPEN_PRODUCT":
            product_opened = await self.open_product(data)
            if not product_opened:
                self.machine.abort_current_keyword("OPEN_PRODUCT_NOT_OPENED")
            return
        if kind == "INTERACT_PRODUCT": await self.interact(data); return
        if kind == "SCROLL_PRODUCT":
            self._workflow_stage = "scroll_product_before"
            # No script-injected media control here: pausing every <video> on the page from
            # JS, with no gesture behind it, immediately before a wheel burst is a
            # gestureless media mutation and reads as automation. PDP videos autoplay muted,
            # and a human who just scrolled past them leaves them playing.

            # Landing read. A person who has just arrived on a product page looks at the
            # title, price and shop before touching the wheel; going straight from the
            # gallery into a wheel burst is the moment this run kept getting challenged on.
            self._workflow_stage = "scroll_product_landing"
            await asyncio.sleep(random.uniform(1.6, 2.8))
            if self._pending_navigation_risk or self._captcha_navigation_active():
                self.machine.result(kind, "NEED_CAPTCHA", {"stepsCompleted": 0, "reason": "RISK_BEFORE_SCROLL"})
                await self.finish_unresolved_captcha()
                return

            steps = random.randint(3, 5)
            for scroll_index in range(steps):
                if self._pending_navigation_risk:
                    self.machine.result(kind, "NEED_CAPTCHA", {"stepsCompleted": scroll_index, "reason": "RISK_BEFORE_NEXT_SCROLL"})
                    await self.finish_unresolved_captcha()
                    return
                amount = random.randint(90, 160) if scroll_index == 0 else random.randint(180, 300)
                self._workflow_stage = f"scroll_product_{scroll_index + 1}"
                await self._motion_wheel(amount)
                if self._pending_navigation_risk or self._captcha_navigation_active():
                    self.machine.result(kind, "NEED_CAPTCHA", {"stepsCompleted": scroll_index + 1, "reason": "RISK_AFTER_SCROLL"})
                    await self.finish_unresolved_captcha()
                    return
                # Read what the scroll revealed before moving on; every so often stop longer.
                await asyncio.sleep(random.uniform(1.2, 2.1) if random.random() < 0.75 else random.uniform(2.4, 3.6))
            self._workflow_stage = "scroll_product_pause"

            pause_min = int(self.payload.get("productViewPauseMin", 15))
            pause_max = max(pause_min + 1, int(self.payload.get("productViewPauseMax", 25)))
            pause_seconds = random.randint(pause_min, pause_max)
            self.machine.log(f"PRODUCT_VIEW_DWELL seconds={pause_seconds}")
            await self._human_dwell_browsing(pause_seconds)
            if self._pending_navigation_risk or self._captcha_navigation_active():
                self.machine.result(kind, "NEED_CAPTCHA", {"stepsCompleted": steps, "reason": "RISK_DURING_DWELL"})
                await self.finish_unresolved_captcha()
                return
            self.machine.result(kind, "OK", {"steps": steps})
            return
        if kind == "VIEW_SHOP":


            self._workflow_stage = "view_shop_locate"
            before=self.page.url; state=await self.evaluate("shop","view"); self.on_shop=False
            if state.get("status")=="READY":
                self.machine.log("PRODUCT_SHOP_SCROLL_TO_BUTTON")
                for align_index in range(30):
                    state=await self.evaluate("shop","view")
                    box=state.get("box") or {}; viewport_height=float(state.get("viewportHeight") or 800); viewport_width=float(state.get("viewportWidth") or 1200)
                    if not box:
                        break
                    top=float(box["y"]); bottom=top+float(box["height"])
                    if top>=viewport_height*.15 and bottom<=viewport_height*.85:
                        break
                    self._workflow_stage = f"view_shop_align_scroll_{align_index + 1}"
                    delta=-random.randint(180,280) if top<viewport_height*.15 else random.randint(180,280)
                    await self._motion_wheel(delta, viewport_width*.5, viewport_height*.5)
                    try:
                        await self.page.wait_for_function("before => [...document.querySelectorAll(\"a[href*='entryPoint=ShopByPDP']\")].some(b => { const r=b.getBoundingClientRect(); const horizontal=r.width>0 && Math.min(r.right,innerWidth)>Math.max(r.left,0); return horizontal && Math.abs(r.top-before)>8; })",arg=top,timeout=1500)
                    except Exception:
                        pass
                state=await self.evaluate("shop","view")
                target_box=state.get("box") or {}; box=dict(target_box); href=str(state.get("href") or "")
                viewport_height=float(state.get("viewportHeight") or 800); viewport_width=float(state.get("viewportWidth") or 1200)
                visible_left=max(0.0,float(box.get("x") or 0)) if box else 0.0
                visible_right=min(viewport_width,float(box.get("x") or 0)+float(box.get("width") or 0)) if box else 0.0
                if box and (not (0 <= float(box["y"]) and float(box["y"])+float(box["height"]) <= viewport_height) or visible_right <= visible_left):
                    box={}
                if box and href:
                    fallback_url = urljoin(before, href)
                    self._last_shop_url = fallback_url
                    self.machine.log("PRODUCT_SHOP_CLICK_BUTTON")
                    x=visible_left+(visible_right-visible_left)*random.uniform(.35,.65)
                    y=float(box["y"])+float(box["height"])*random.uniform(.35,.65)
                    self._workflow_stage = "view_shop_click"


                    await self._motion_click_at(x, y, box.get("width"))

                    try: await self.page.wait_for_url(lambda url: str(url)!=before,timeout=25000)
                    except Exception: pass


                    if str(self.page.url or "") == str(before or "") and not self._pending_navigation_risk:
                        fallback_url = urljoin(before, href)
                        fallback_error = ""
                        try:
                            retry_state = await self.evaluate("shop", "view")
                            retry_box = retry_state.get("box") or {}
                            retry_href = str(retry_state.get("href") or "")
                            if not retry_box or not retry_href:
                                fallback_error = "CLICK_TARGET_LOST"
                            else:
                                retry_x = float(retry_box["x"]) + float(retry_box["width"]) * random.uniform(.35, .65)
                                retry_y = float(retry_box["y"]) + float(retry_box["height"]) * random.uniform(.35, .65)

                                await self._motion_click_at(retry_x, retry_y, retry_box.get("width"))
                                try:
                                    await self.page.wait_for_url(lambda url: str(url) != before, timeout=15000)
                                except Exception:
                                    pass
                                if str(self.page.url or "") == str(before or ""):
                                    fallback_error = "CLICK_NO_NAVIGATION"
                        except Exception as ex:
                            fallback_error = type(ex).__name__
                        if fallback_error:
                            state["reason"] = fallback_error
                    shop_navigation_risk = await self.risk()
                    if shop_navigation_risk == "NEED_CAPTCHA":
                        self.machine.result(kind, "NEED_CAPTCHA", {"href": self.page.url, "from": before, "stage": "SHOP_NAVIGATION"})
                        await self.finish_unresolved_captcha()
                        return
                    if shop_navigation_risk:
                        self.machine.risk(shop_navigation_risk, close=True)
                        return
                    expected_path=urlsplit(urljoin(before,href)).path.rstrip('/')
                    actual_path=urlsplit(self.page.url).path.rstrip('/')
                    self.on_shop=bool(expected_path and actual_path==expected_path)
                    if self.on_shop:
                        self._last_shop_url = str(self.page.url or self._last_shop_url)

                state["status"]="OK" if self.on_shop else "ERROR"
            self.machine.log(f"PRODUCT_SHOP_VIEW_RESULT status={state.get('status','NOT_FOUND')}")
            self.machine.result(kind,state.get("status","NOT_FOUND"),{"href":self.page.url,"from":before,"reason":state.get("reason","")}); return
        if kind == "FOLLOW_SHOP":
            state=await self.evaluate("shop","follow")
            if state.get("status")=="READY":
                clicked=await self.click_by_text(["Theo dõi","Follow"]); state["status"]="OK" if clicked else "ERROR"
            self.machine.result(kind,state.get("status","NOT_FOUND"),{}); return
        if kind == "SCROLL_SHOP":
            self._workflow_stage = "scroll_shop_ready"


            self._workflow_stage = "scroll_shop_wait_content"
            shop_ready_error = ""
            try:
                await self.page.wait_for_function(r"""() => {
                    const scroller = document.scrollingElement;
                    const productLinks = document.querySelectorAll("a[href*='-i.'],a[href*='/product/']").length;
                    return !!scroller && productLinks > 0 && scroller.scrollHeight > scroller.clientHeight + 100;
                }""", timeout=20000)
            except Exception as ex:
                shop_ready_error = type(ex).__name__

            if shop_ready_error:
                shop_ready_risk = await self.risk()
                if shop_ready_risk == "NEED_CAPTCHA":
                    self.machine.result(kind, "NEED_CAPTCHA", {"reason": "SHOP_CONTENT_CAPTCHA"})
                    await self.finish_unresolved_captcha()
                    return
                if shop_ready_risk:
                    self.machine.risk(shop_ready_risk, close=True)
                    return
                self.machine.result(kind, "NOT_FOUND", {"reason": "SHOP_CONTENT_NOT_READY", "errorType": shop_ready_error})
                return
            expand_shop_products = bool(self.payload.get("clickShopProductsBeforeScroll", False))
            if expand_shop_products:
                try:
                    await self.page.wait_for_function("() => [...document.querySelectorAll('.section-seller-overview__item--clickable')].some(el => { const name=(el.querySelector('.section-seller-overview__item-text-name')?.textContent||'').replace(/\\u00a0/g,' ').trim(); return el.getClientRects().length>0 && /^(sản phẩm|products?)\\s*:/i.test(name); })",timeout=15000)
                except Exception:
                    pass
                product_item=await self.evaluate("shop","products")
            else:
                product_item={"status":"SKIP"}
            if product_item.get("status")=="READY":
                box=product_item.get("box") or {}; viewport_height=float(product_item.get("viewportHeight") or 800); viewport_width=float(product_item.get("viewportWidth") or 1200)
                for shop_align_index in range(20):
                    if not box: break
                    top=float(box["y"]); bottom=top+float(box["height"])
                    if top>=viewport_height*.12 and bottom<=viewport_height*.88: break
                    before_y=float((await self.evaluate("shop","pageState")).get("scrollY") or 0)
                    self._workflow_stage = f"scroll_shop_align_{shop_align_index + 1}"
                    await self._motion_wheel(-random.randint(180,280) if top<viewport_height*.12 else random.randint(180,280), viewport_width*.5, viewport_height*.5)
                    try:
                        await self.page.wait_for_function("before => Math.abs(scrollY-before)>8",arg=before_y,timeout=1500)
                    except Exception:
                        pass
                    product_item=await self.evaluate("shop","products"); box=product_item.get("box") or {}
                if box and 0<=float(box["y"]) and float(box["y"])+float(box["height"])<=viewport_height:
                    before_state=await self.evaluate("shop","pageState")
                    x=float(box["x"])+float(box["width"])*random.uniform(.35,.65)
                    y=float(box["y"])+float(box["height"])*random.uniform(.35,.65)
                    self.machine.log("SHOP_PRODUCTS_CLICK_BUTTON")
                    self._workflow_stage = "scroll_shop_products_click"
                    await self._motion_click_at(x, y, box.get("width"))
                    try:
                        await self.page.wait_for_function("before => location.href!==before.href || document.documentElement.scrollHeight!==before.height || scrollY<before.scrollY",arg=before_state,timeout=10000)
                    except Exception:
                        pass
                    try:
                        await self.page.wait_for_function("() => document.querySelectorAll(\"a[href*='-i.'],a[href*='/product/']\").length>0 && document.documentElement.scrollHeight>innerHeight+100",timeout=15000)
                    except Exception:
                        pass
                    await self.evaluate("shop","pageState")
            elif product_item.get("status") != "SKIP":
                self.machine.log("SHOP_PRODUCTS_NOT_FOUND")
                self.machine.result(kind,"NOT_FOUND",{"reason":"PRODUCTS_ITEM_NOT_FOUND"}); return
            else:
                self._workflow_stage = "scroll_shop_products_click_skipped"
            steps=0; scroll={"bottom":False}
            for shop_scroll_index in range(80):
                before_scroll=await self.evaluate("shop","pageState")
                if before_scroll.get("bottom"):
                    scroll=before_scroll; break
                self._workflow_stage = f"scroll_shop_wheel_{shop_scroll_index + 1}"
                amount = random.randint(220,340)
                await self._motion_wheel(amount, float(before_scroll.get("viewportWidth") or 1200)*.6, float(before_scroll.get("viewportHeight") or 800)*.55);steps+=1
                try:
                    await self.page.wait_for_function("before => scrollY>before.scrollY || document.documentElement.scrollHeight>before.height",arg=before_scroll,timeout=1800)
                except Exception:
                    pass
                await asyncio.sleep(random.uniform(.8,1.4))
                scroll=await self.evaluate("shop","pageState")
                if scroll.get("bottom"):break
            self.machine.result(kind,"OK",{"steps":steps,"reachedBottom":bool(scroll.get('bottom'))}); return

    async def _open_search_results_via_url(self, query):
        """Open the whole-marketplace search by URL instead of driving the searchbar.

        The operator's rule: a keyword search across all of Shopee navigates straight to
        `https://shopee.vn/search?keyword=...`; the searchbar is no longer typed into for
        it. Returns (method, hit_captcha) just like `_run_searchbar_query`.
        """
        query = str(query or "").strip()
        if not query:
            return "", False
        search_url = "https://shopee.vn/search?keyword=" + quote(query)
        self._workflow_stage = "search_url_navigation"
        self.machine.log(f"SEARCH_URL_NAVIGATE len={len(query)}")
        try:
            await self.page.goto(search_url, wait_until="commit", timeout=60000)
        except Exception as ex:
            self.machine.log(f"SEARCH_URL_NAVIGATE_FAIL reason={type(ex).__name__}")
            return "", self._captcha_navigation_active()
        if self._captcha_navigation_active():
            return "", True
        try:
            await self.page.wait_for_load_state("domcontentloaded", timeout=8000)
        except Exception:
            pass
        if self._captcha_navigation_active():
            return "", True
        navigated = await self._await_search_results(timeout=8.0)
        if self._captcha_navigation_active():
            return "", True
        if not navigated:
            self.machine.log("SEARCH_URL_NAVIGATE_NOT_ON_RESULTS")
            return "", False
        return "URL_NAVIGATE", False

    async def _run_searchbar_query(self, query, via_url=False):
        """Search `query` for this session and report how it went.

        With `via_url=True` the whole-marketplace search opens the search URL directly;
        otherwise the real shop searchbar is typed into and submitted. Returns
        (method, hit_captcha). `method` is empty only when a captcha stopped the
        attempt; every other failure ends in the URL fallback and says so.
        """
        query = str(query or "").strip()
        if via_url:
            return await self._open_search_results_via_url(query)
        self._workflow_stage = "search_input_begin"
        probe = await self.evaluate("search", "input")
        probe_deadline = asyncio.get_running_loop().time() + 6.0
        while not probe.get("found") and asyncio.get_running_loop().time() < probe_deadline:
            if self._captcha_navigation_active():
                break
            await asyncio.sleep(0.35)
            probe = await self.evaluate("search", "input")

        def _clickable(box, margin=4.0):
            if not box:
                return False
            # The magnifier on a shop searchbar is a small --s button; it must still be
            # clicked rather than falling through to a key press.
            return (
                float(box.get("width") or 0) >= 22
                and float(box.get("height") or 0) >= 14
                and float(box.get("x") or 0) + margin >= 0
                and float(box.get("y") or 0) + margin >= 0
            )

        async def _focus_searchbar():
            """Click the real searchbar input until the browser agrees it owns the focus."""
            for focus_attempt in range(1, 4):
                live = await self.evaluate("search", "input")
                box = live.get("box") or {}
                if not _clickable(box):
                    await asyncio.sleep(0.4)
                    continue
                # Aim left of centre. On a shop page the scope control sits immediately to
                # the right of this field, and a click that drifts into it opens the scope
                # menu - an interaction a shopper standing in the shop would never make.
                self._workflow_stage = f"searchbar_focus_{focus_attempt}"
                click_x = float(box["x"]) + float(box["width"]) * random.uniform(0.12, 0.42)
                click_y = float(box["y"]) + float(box["height"]) * random.uniform(0.35, 0.65)
                await self._motion_click_at(click_x, click_y, box.get("width"))
                await asyncio.sleep(random.uniform(0.18, 0.38))
                if (await self.evaluate("search", "focusCheck")).get("focused"):
                    return True
            return False

        async def _clear_searchbar():
            await self._motion_press_key("a", modifiers=["Control"])
            await asyncio.sleep(random.uniform(0.06, 0.12))
            await self._motion_press_key("Backspace")
            await asyncio.sleep(random.uniform(0.12, 0.25))

        try:
            if not probe.get("found"):
                raise RuntimeError("search_input_not_found")
            if not probe.get("inSearchbar"):
                self.machine.log("SEARCHBAR_SCOPE_WARN reason=input_outside_searchbar")
            if not await _focus_searchbar():
                raise RuntimeError("searchbar_focus_failed")

            if self._captcha_navigation_active():
                raise RuntimeError("captcha_after_search_focus")
            self._workflow_stage = "searchbar_type"
            await _clear_searchbar()
            try:
                await self.motion_session.send("Motion.enterText", {
                    "text": query,
                    "allowTypos": True,
                })
                await asyncio.sleep(random.uniform(0.25, 0.50))
            except Exception:
                pass
            if str((await self.evaluate("search", "focusCheck")).get("value") or "") != query:
                # A left-over typo or lost focus: retype deterministically into the verified field.
                self._workflow_stage = "searchbar_type_retry"
                if not await _focus_searchbar():
                    raise RuntimeError("searchbar_focus_lost")
                await _clear_searchbar()
                await self.motion_session.send("Motion.enterText", {
                    "text": query,
                    "allowTypos": False,
                })
                await asyncio.sleep(random.uniform(0.20, 0.38))

            if self._captcha_navigation_active():
                raise RuntimeError("captcha_after_search_type")
            if str((await self.evaluate("search", "focusCheck")).get("value") or "") != query:
                raise RuntimeError("search_input_value_mismatch")
            self._workflow_stage = "searchbar_submit"
            # Gaze hesitation before submit: glance at the autocomplete dropdown (0.55s - 1.10s)
            await asyncio.sleep(random.uniform(0.55, 1.10))
            submitted = False
            live_submit_probe = await self.evaluate("search", "input")
            button_box = live_submit_probe.get("buttonBox") or {}
            if _clickable(button_box):
                self._workflow_stage = "searchbar_submit_button"
                await self._motion_click_at(
                    float(button_box["x"]) + float(button_box["width"]) * random.uniform(0.35, 0.65),
                    float(button_box["y"]) + float(button_box["height"]) * random.uniform(0.35, 0.65),
                    button_box.get("width"),
                )
                submitted = True
            else:
                await self._motion_press_key("Enter")

            navigated = await self._await_search_results(timeout=6.0)
            if not navigated:
                # Second attempt through a different delivery path: Playwright's keyboard
                # posts a trusted Return to whatever holds focus, which covers the case
                # where the magnifier click was swallowed by an overlay.
                self._workflow_stage = "searchbar_submit_keyboard"
                try:
                    await self.page.keyboard.press("Enter")
                except Exception:
                    pass
                navigated = await self._await_search_results(timeout=5.0)
            self.machine.log(
                "SEARCHBAR_SUBMIT_RESULT"
                f" navigated={int(bool(navigated))}"
                f" submitted={int(submitted)}"
                f" url={(str(self.page.url or '') or '-').split('?')[0]}"
            )
            if not navigated:
                raise RuntimeError("search_submit_no_navigation")
            return ("MOTION_SEARCHBAR_BUTTON" if submitted else "MOTION_SEARCHBAR_ENTER"), False
        except Exception as ex:
            if self._captcha_navigation_active():
                return "", True
            self.machine.log(f"SEARCH_SUBMIT_FALLBACK query_len={len(query)} reason={type(ex).__name__}")
            self._workflow_stage = "search_fallback_navigation"
            await self.page.goto("https://shopee.vn/search?keyword=" + quote(query), wait_until="commit", timeout=60000)
            return "URL_FALLBACK", False

    async def search(self, data):
        keyword = str(data.get("keyword") or "").strip()
        await self.close_post_login_popups()
        # Từ khóa tìm kiếm toàn Shop đi thẳng bằng link, không gõ vào ô tìm kiếm.
        method, hit_captcha = await self._run_searchbar_query(keyword, via_url=True)
        if hit_captcha or self._captcha_navigation_active():
            self.machine.result("SEARCH_KEYWORD", "NEED_CAPTCHA", {"href": self.page.url, "method": method or "MOTION_SEARCHBAR"})
            await self.finish_unresolved_captcha()
            return
        await self._settle_results_page()
        if self._captcha_navigation_active():
            self.machine.result("SEARCH_KEYWORD", "NEED_CAPTCHA", {"href": self.page.url, "method": method})
            await self.finish_unresolved_captcha()
            return
        self._workflow_stage = "search_input_complete"
        self.machine.log("SEARCH_SCAN_BEGIN page=1")
        self.machine.result("SEARCH_KEYWORD", "OK", {"keyword": keyword, "href": self.page.url, "method": method})

    async def _await_search_results(self, timeout=12.0):
        """Wait until the browser is genuinely on a search results page for this keyword."""
        deadline = asyncio.get_running_loop().time() + float(timeout)
        while asyncio.get_running_loop().time() < deadline:
            if self._captcha_navigation_active():
                return False
            if "/search" in str(self.page.url or "").lower():
                return True
            await asyncio.sleep(0.25)
        return False

    async def _settle_results_page(self, lookup=None, timeout=20.0):
        """Wait until the result grid has actually been rendered, then let it settle.

        This used to be a Playwright visibility wait, which disagreed with the read the scan
        performs: the wait reported a card while the scan saw none, so a page that had not
        rendered its grid was scanned as if it had simply come back empty. The wait now polls
        the very same read, so "ready" means the grid is ready for the code that uses it.
        """
        args = self._scan_args(lookup or {"item_id": "", "raw_name": ""})
        started = asyncio.get_running_loop().time()
        deadline = started + float(timeout)
        state = {}
        first_scan = True
        while asyncio.get_running_loop().time() < deadline:
            if self._captcha_navigation_active():
                return state
            try:
                state = await self.page.evaluate(self.scripts["search"], {"action": "scan", "args": args})
            except Exception as ex:
                state = {"_scanError": type(ex).__name__}
            if first_scan:
                first_scan = False
            if int(state.get("rawAnchors") or 0) > 0 or int(state.get("count") or 0) > 0:
                # The grid is ready. Nothing is announced here on purpose: "Trang đã hiện
                # kết quả sau N giây" was operator noise about a wait nobody acts on.
                await asyncio.sleep(random.uniform(0.3, 0.7))
                return state
            await asyncio.sleep(random.uniform(0.35, 0.70))
        self.machine.log(
            "RESULTS_RENDER_TIMEOUT"
            f" anchors={int(state.get('rawAnchors') or 0)}"
            f" allAnchors={int(state.get('totalAnchors') or 0)}"
            f" empty={int(bool(state.get('emptyState')))}"
            f" skeleton={int(bool(state.get('skeleton')))}"
            f" title={(str(state.get('docTitle') or '-').replace(' ', '_'))}"
        )
        return state

    async def _viewport_height(self):
        try:
            dims = await self.page.evaluate("() => [window.innerWidth, window.innerHeight]")
            if isinstance(dims, (list, tuple)) and len(dims) >= 2:
                return float(dims[1])
        except Exception:
            pass
        return 800.0

    async def _find_after_search(self, query, lookup, stage):
        """Search `query` and look for the product on the results it returns."""
        self.machine.log(f"OPEN_PRODUCT_SEARCH_BEGIN stage={stage} len={len(query)}")
        # Rung tìm theo tiêu đề cũng là tìm toàn Shop: mở bằng link như từ khóa.
        method, hit_captcha = await self._run_searchbar_query(query, via_url=True)
        if hit_captcha or not method or self._captcha_navigation_active():
            return None
        await self._settle_results_page(lookup)
        if self._captcha_navigation_active():
            return None
        return (await self.scan_current_search_page(self._scan_args(lookup))).get("found")

    def _shop_queries(self, lookup, keyword):
        """The keyword first, then the product's own title, de-duplicated."""
        queries = []
        for candidate in (str(keyword or "").strip(), lookup["title_query"]):
            if candidate and candidate not in queries:
                queries.append(candidate)
        return queries

    async def _search_inside_shop(self, query, lookup, deadline=None):
        """Search only this shop's listings via Shopee's shop-scoped search URL.

        This is the rung a new product needs. A brand new listing loses a global keyword
        search because it has to rank against millions of other listings; inside a shop of
        a few hundred there is nothing to rank against, so the keyword alone finds it.

        Typing into the searchbar here is flaky ("Không gửi được
        tìm kiếm"), and its failure fallback rebuilt a GLOBAL /search URL - so the full
        title query silently searched the whole marketplace. Navigating straight to the
        shop-scoped URL (`&shop=<id>`, the exact URL Shopee's own searchbar produced when
        it worked) keeps every query inside the shop by construction.
        """
        shop_id = str(lookup.get("shop_id") or "").strip()
        if not shop_id:
            self.machine.log("SHOP_SEARCH_UNAVAILABLE reason=no_shop_id")
            return None
        search_url = "https://shopee.vn/search?keyword=" + quote(str(query or "").strip()) + "&shop=" + shop_id
        self.machine.log(f"SHOP_SEARCH_BEGIN len={len(query)}")
        self._workflow_stage = "product_shop_search"
        try:
            await self.page.goto(search_url, wait_until="commit", timeout=60000)
        except Exception:
            return None
        await self._settle_results_page(lookup)
        if self._captcha_navigation_active():
            return None
        # A shop can hold many listings under one keyword, so every results page is read
        # rather than only the first. `_scan_results_pages` stops by itself when Shopee
        # reports no next page, so the cap only guards a runaway query; the deadline keeps a
        # very deep query from eating the whole task before the Facebook hop can run.
        configured = int(self.payload.get("maxShopSearchPages") or 0)
        max_pages = configured if configured > 0 else SHOP_SEARCH_PAGE_SAFETY_CAP
        found, _, _ = await self._scan_results_pages(lookup, max_pages, deadline=deadline)
        return found

    async def _find_on_shop_page(self, lookup, keyword):
        """The shop's own listing holds the product no matter how it ranks in search."""
        shop_url = "https://shopee.vn/shop/" + str(lookup["shop_id"])
        self.machine.log("OPEN_PRODUCT_SHOP_PAGE_BEGIN")
        self._workflow_stage = "product_shop_page"
        # The whole rung shares one budget: the shop page read, then every query and every
        # results page inside it. Running out of it still ends the ladder the way the
        # operator asked - not found in the shop means the Facebook hop is next.
        shop_deadline = asyncio.get_running_loop().time() + SHOP_SEARCH_BUDGET_SECONDS
        try:
            await self.page.goto(shop_url, wait_until="commit", timeout=60000)
        except Exception:
            return None
        self._last_shop_url = str(self.page.url or shop_url)
        await self._settle_results_page(lookup)
        if self._captcha_navigation_active():
            return None
        for query in self._shop_queries(lookup, keyword):
            if asyncio.get_running_loop().time() >= shop_deadline:
                self.machine.log("SHOP_SEARCH_STOP reason=shop_budget")
                break
            found = await self._search_inside_shop(query, lookup, shop_deadline)
            if found:
                return found
            if self._captcha_navigation_active():
                return None
        return None

    async def _click_product_card(self, found):
        """Open the card by clicking it in the live page.

        The scan reports the anchor's absolute href, but Shopee writes a relative href in
        the DOM, so selecting by href never matched and every open silently fell through to
        a cold page.goto - throwing away the in-site referrer the funnel had just earned.
        Re-resolve the live box and click it with the pointer instead.
        """
        for attempt in range(1, 4):
            live = await self.evaluate("search", "targetBox", {
                "itemId": str(found.get("id") or ""),
                "href": str(found.get("href") or ""),
            })
            box = live.get("box") or {}
            if not live.get("found") or not box:
                break
            height = await self._viewport_height()
            top = float(box.get("y") or 0)
            if top < 0 or top + float(box.get("height") or 0) > height:
                self._workflow_stage = f"product_card_align_{attempt}"
                await self._motion_wheel(260 if top < 0 else -260)
                await asyncio.sleep(random.uniform(0.4, 0.8))
                continue
            self._workflow_stage = f"product_card_click_{attempt}"
            before = str(self.page.url or "")
            await self._motion_click_at(
                float(box["x"]) + float(box["width"]) * max(0.20, min(0.80, random.gauss(0.5, 0.10))),
                float(box["y"]) + float(box["height"]) * max(0.20, min(0.80, random.gauss(0.5, 0.10))),
                box.get("width"),
            )
            try:
                await self.page.wait_for_url(lambda url: str(url) != before, timeout=15000)
            except Exception:
                pass
            if str(self.page.url or "") != before:
                try: await self.page.wait_for_load_state("load", timeout=20000)
                except Exception: pass
                if self.is_target_product_url(self.page.url, str(found.get("id") or "")):
                    return True
                # Landed somewhere unexpected (not the product, not a challenge): the direct
                # URL below is the last honest attempt instead of claiming success.
                if not self._captcha_navigation_active():
                    break
                return False
        # Only when the click genuinely cannot land: follow the URL and accept the loss of
        # referrer rather than losing the product.
        await self.page.goto(found["href"], wait_until="commit", timeout=60000)
        try: await self.page.wait_for_load_state("load", timeout=20000)
        except Exception: pass
        return self.is_target_product_url(self.page.url, str(found.get("id") or ""))

    async def _search_next_page_state(self):
        try:
            return await self.evaluate("search", "next")
        except Exception:
            return {}

    async def _scan_results_pages(self, lookup, max_pages, deadline=None):
        # `max_pages <= 0` means "walk until Shopee reports no next page", which is what the
        # shop rung needs: a listing sitting on the shop's page 3 is still reachable there.
        # `deadline` is the shop rung's safety valve: the walk is page-bounded, but a query
        # with dozens of matching pages would push the visit ladder past the task ceiling and
        # the keyword would be aborted before the Facebook hop. Hitting it hands the run over
        # to that hop instead, which is what the operator asked for when the shop comes back
        # empty.
        page_cap = int(max_pages or 0)
        page_no = 1
        last_scan = {}
        while page_cap <= 0 or page_no <= page_cap:
            last_scan = await self.scan_current_search_page(self._scan_args(lookup))
            if last_scan.get("found"):
                return last_scan["found"], page_no, last_scan
            if int(last_scan.get("count") or 0) == 0:
                # An empty page means the remaining pages of the same query hold nothing
                # either; walking them only spends the session.
                self.machine.log("SEARCH_PAGINATION_STOP reason=empty_page")
                break
            if page_cap > 0 and page_no >= page_cap:
                break
            if deadline and asyncio.get_running_loop().time() >= deadline:
                self.machine.log(f"SEARCH_PAGINATION_STOP reason=shop_budget page={page_no}")
                break
            state = await self._search_next_page_state()
            if not state.get("hasNext"):
                # Ask Shopee whether a next page exists instead of assuming one does.
                self.machine.log(
                    "SEARCH_PAGINATION_END"
                    f" page={int(state.get('current') or page_no)}"
                    f" total={int(state.get('total') or page_no)}"
                )
                break
            next_page = page_no + 1
            if not await self.advance_search_page(next_page, str(state.get("href") or "")):
                break
            page_no = next_page
            self.machine.log(f"SEARCH_SCAN_BEGIN page={page_no}")
        return None, page_no, last_scan

    def _scan_args(self, lookup):
        return {"productId": lookup["item_id"], "productName": lookup["raw_name"]}

    async def scan_current_search_page(self, lookup):
        """Scroll the results page until the saved product shows up.

        `lookup` carries whatever identity we hold: `productId` (any of the shapes
        KeywordTrackingStore emits) and/or `productName`, which is what saves the
        scan when the operator's saved link was a short redirector and no id exists.
        """
        best = await self.page.evaluate(self.scripts["search"], {"action": "scan", "args": lookup})
        self._log_search_scan(lookup, best, page_label="1", iteration=0)
        empty_passes = 0
        stagnant_passes = 0
        for scan_index in range(16):
            if best.get("found"):
                return best
            if int(best.get("count") or 0) >= SEARCH_PAGE_ITEM_CAP:
                # The page came back full on the very first read: every card Shopee is going to
                # render is already collected, so the remaining passes reveal nothing.
                self.machine.log(f"SEARCH_LIST_STABLE count={int(best.get('count') or 0)} passes=0")
                break
            if int(best.get("count") or 0) == 0:
                # Nothing to match against at all: a challenge, a genuinely empty result set,
                # or a page that is still rendering. Scrolling it only burns the session.
                empty_passes += 1
                if empty_passes >= 4:
                    self.machine.log("SEARCH_RESULTS_EMPTY passes=4")
                    break
                # The grid may be lazy-hydrated: one human-like wheel can bring the product
                # anchors into the visible set.
                if int(best.get("totalProductAnchors") or 0) > 0:
                    await self._motion_wheel(random.randint(220, 320))
                    await asyncio.sleep(random.uniform(0.8, 1.6))
                    current = await self.page.evaluate(self.scripts["search"], {"action": "scan", "args": lookup})
                    best = current if current.get("count", 0) >= best.get("count", 0) else best
                    continue
                await asyncio.sleep(random.uniform(1.4, 2.2))
                current = await self.page.evaluate(self.scripts["search"], {"action": "scan", "args": lookup})
                best = current if current.get("count", 0) >= best.get("count", 0) else best
                continue
            await self._human_scan_scroll(scan_index)
            scroll = await self._page_scroll_state()
            current = await self.page.evaluate(self.scripts["search"], {"action": "scan", "args": lookup})
            if current.get("found"):
                self._log_search_scan(lookup, current, page_label="1", iteration=scan_index + 1)
                return current
            if current.get("count", 0) > best.get("count", 0):
                stagnant_passes = 0
                best = current
                if int(best.get("count") or 0) >= SEARCH_PAGE_ITEM_CAP:
                    # The listing just reached the full page: nothing is left to reveal.
                    self.machine.log(f"SEARCH_LIST_STABLE count={int(best.get('count') or 0)} passes={scan_index + 1}")
                    break
            else:
                # The listing has stopped growing: everything it holds is already rendered,
                # so the remaining passes could only wheel a page with nothing left to reveal.
                stagnant_passes += 1
                if current.get("count", 0) >= best.get("count", 0):
                    best = current
                if stagnant_passes >= 4:
                    self.machine.log(f"SEARCH_LIST_STABLE count={int(best.get('count') or 0)} passes={stagnant_passes}")
                    break
            if scroll.get("bottom"):
                break
        self._log_search_scan(lookup, best, page_label="1", iteration="final")
        return best

    def _log_search_scan(self, lookup, scan_result, page_label, iteration):
        lookup_info = scan_result.get("lookup") or {}
        sample = scan_result.get("sample") or []
        sample_text = ",".join(f"{item.get('id')}@{item.get('shopId')}" for item in sample[:5])
        self.machine.log(
            "SEARCH_SCAN_PAGE"
            f" page={page_label} pass={iteration}"
            f" count={int(scan_result.get('count') or 0)}"
            f" url={(str(self.page.url or '') or '-').split('?')[0]}"
            f" raw={int(scan_result.get('rawAnchors') or 0)}"
            f" itemKey={int(bool(lookup_info.get('hasItemKey')))}"
            f" nameKey={int(bool(lookup_info.get('hasNameKey')))}"
            f" targetItem={lookup_info.get('targetItem') or ''}"
            f" targetShop={lookup_info.get('targetShop') or ''}"
            f" allAnchors={int(scan_result.get('totalAnchors') or 0)}"
            f" empty={int(bool(scan_result.get('emptyState')))}"
            f" ids={sample_text}"
        )

    async def advance_search_page(self, display_page: int, next_href: str = ""):
        parts = urlsplit(self.page.url)
        if next_href:
            # Follow the link Shopee itself rendered; it carries the shop and keyword scope.
            next_url = urljoin(self.page.url, next_href)
            # The dead arrow points at the site root - never follow that.
            if urlsplit(next_url).path.rstrip("/") in ("", "/"):
                return False
        else:
            query = dict(parse_qsl(parts.query, keep_blank_values=True))
            # Shopee uses zero-based page query: display page 2 => `page=1`.
            query["page"] = str(max(0, display_page - 1))
            next_url = urlunsplit((parts.scheme, parts.netloc, parts.path, urlencode(query), parts.fragment))
        before = await self.page.evaluate(self.scripts["search"], {"action":"scan","args":{}})
        await self.page.goto(next_url, wait_until="commit", timeout=60000)
        # Playwright treats display:contents anchors as invisible, so its visibility wait
        # would always burn the full 20s. Poll the same ancestor-aware rule the scan uses.
        ready_deadline = asyncio.get_running_loop().time() + 12.0
        while asyncio.get_running_loop().time() < ready_deadline:
            try:
                if (await self.evaluate("search", "productAnchorsReady")).get("any"):
                    break
            except Exception:
                pass
            await asyncio.sleep(0.25)
        now = await self.page.evaluate(self.scripts["search"], {"action":"scan","args":{}})
        current_query = dict(parse_qsl(urlsplit(self.page.url).query, keep_blank_values=True))
        expected_page_index = str(max(0, display_page - 1))
        reached_requested_page = current_query.get("page", "0") == expected_page_index
        return reached_requested_page or now.get("signature") != before.get("signature") or bool(now.get("count"))

    @staticmethod
    def is_shopee_url(url):
        try:
            host = (urlsplit(str(url or "")).hostname or "").lower()
            return host == "shopee.vn" or host.endswith(".shopee.vn")
        except Exception:
            return False

    @classmethod
    def is_target_product_url(cls, url, product_id):
        if not cls.is_shopee_url(url):
            return False
        path = urlsplit(str(url or "")).path
        if not product_id:
            # Nothing to compare against, so only a product-shaped path proves the visit
            # landed on a product page. Without this a shopee search or home page was
            # reported as an opened product and the run continued on the wrong page.
            return "-i." in path or "/product/" in path
        return str(product_id) in path

    async def _navigate_product_fallback(self, url, product_id):
        """Retry a direct product navigation only when a concurrent redirect aborted it."""
        try:
            await self.page.goto(url, wait_until="commit", timeout=60000)
        except Exception as ex:
            if self.is_target_product_url(self.page.url, product_id):
                return True
            if "ERR_ABORTED" not in str(ex).upper():
                raise
            try:
                await self.page.wait_for_load_state("domcontentloaded", timeout=10000)
            except Exception:
                pass
            if not self.is_target_product_url(self.page.url, product_id):
                await self.page.goto(url, wait_until="commit", timeout=60000)
        opened = self.is_target_product_url(self.page.url, product_id)
        return opened

    @staticmethod
    def _facebook_href_target(href):
        """The real destination behind a Facebook outbound link, if the href wraps one.

        The interstitial's continue control can carry either the destination itself or one
        more `l.facebook.com/l.php?u=<destination>` hop; navigating into the wrapper would
        only re-render the same notice, so the `u` parameter is unwrapped first.
        """
        text = str(href or "").strip()
        if not text:
            return ""
        try:
            parts = urlsplit(text)
        except Exception:
            return text
        host = (parts.hostname or "").lower()
        if "facebook.com" not in host:
            return text
        for key, value in parse_qsl(parts.query, keep_blank_values=True):
            if key.lower() == "u" and value.strip():
                return value.strip()
        return ""

    async def _click_facebook_follow_link(self):
        # Facebook renders the outbound-link interstitial a beat after the redirect
        # lands, and its continue control carries the real target. Poll for the
        # control before acting: click it like a person would when it is on screen,
        # and fall back to navigating to the anchor href when the box cannot be read.
        #
        # Vietnamese Facebook labels the control "Truy cập vào liên kết" (the log that
        # reported a missing click came from this page), so the label list covers both
        # languages and both generations of the page. "Quay lại" (the back control) must
        # never match, which is why the label is anchored on the outbound wording.
        state = {}
        for _ in range(12):
            try:
                state = await self.page.evaluate(r"""() => {
                    const label = /truy c.p|theo li.n k.t|follow link|ti.p t.c|continue|m. li.n k.t|open link|visit link|go to link/i;
                    const matches = (el) => {
                        const text = (el.textContent || "").trim();
                        // A container wrapping the whole notice also "contains" the label;
                        // only elements whose own caption is short are real controls.
                        if (text && text.length <= 60 && label.test(text)) return true;
                        return label.test((el.getAttribute("aria-label") || "").trim());
                    };
                    const boxOf = (el) => {
                        let r = el.getBoundingClientRect();
                        if (r.top < 0 || r.bottom > window.innerHeight) {
                            el.scrollIntoView({ block: "center", inline: "center" });
                            r = el.getBoundingClientRect();
                        }
                        return { x: r.x, y: r.y, width: r.width, height: r.height };
                    };
                    const seen = new Set();
                    const candidates = [];
                    const selectors = "a[href], button, [role='button'], [role='link'], div[tabindex]";
                    for (const el of document.querySelectorAll(selectors)) {
                        if (seen.has(el)) continue;
                        seen.add(el);
                        if (!matches(el)) continue;
                        const box = boxOf(el);
                        if (!(box.width > 0) || !(box.height > 0)) continue;
                        candidates.push({ href: el.href || "", box, area: box.width * box.height });
                    }
                    if (!candidates.length) return { found: false, href: "" };
                    // The continue control is small; the notice itself is not. Taking the
                    // smallest matching box keeps the pointer off the surrounding text.
                    candidates.sort((a, b) => a.area - b.area);
                    return { found: true, href: candidates[0].href, box: candidates[0].box };
                }""", None)
            except Exception:
                state = {}
            if isinstance(state, dict) and state.get("found"):
                break
            await asyncio.sleep(0.8)
        if not isinstance(state, dict) or not state.get("found"):
            return False
        href = str(state.get("href") or "")
        target = self._facebook_href_target(href)
        left_facebook = lambda url: "facebook.com" not in (urlsplit(str(url or "")).hostname or "").lower()
        box = state.get("box") or {}
        has_box = float(box.get("width") or 0) > 0 and float(box.get("height") or 0) > 0
        if has_box:
            try:
                x = float(box["x"]) + float(box["width"]) * random.uniform(0.4, 0.6)
                y = float(box["y"]) + float(box["height"]) * random.uniform(0.4, 0.6)
                await self._motion_click_at(x, y, box.get("width"))
            except Exception:
                has_box = False
            if has_box:
                try:
                    await self.page.wait_for_url(left_facebook, timeout=15000)
                    return True
                except Exception:
                    # The click missed or the notice re-rendered: follow the destination the
                    # control pointed at instead of reporting a click that never landed.
                    pass
        if not target:
            return False
        try:
            await self.page.goto(target, wait_until="commit", timeout=30000)
            return True
        except Exception:
            return False

    async def _navigate_via_facebook(self, product_url, product_id):
        # Enter the product link through Facebook's outbound redirect so the visit
        # carries a social referrer instead of a cold direct navigation. Facebook
        # shows an interstitial for outbound links; click through it when present,
        # and accept an immediate redirect when it is not.
        fb_redirect = "https://l.facebook.com/l.php?u=" + quote(str(product_url or ""), safe="")
        try:
            await self.page.goto(fb_redirect, wait_until="commit", timeout=60000)
        except Exception as ex:
            if not self.is_target_product_url(self.page.url, product_id):
                self.machine.log(f"OPEN_PRODUCT_FB_REDIRECT_FAIL error={type(ex).__name__}")
                return False
        try:
            await self.page.wait_for_load_state("domcontentloaded", timeout=15000)
        except Exception:
            pass
        for _ in range(3):
            if self.is_target_product_url(self.page.url, product_id):
                return True
            host = (urlsplit(str(self.page.url or "")).hostname or "").lower()
            if "facebook.com" not in host and "fb.com" not in host:
                # Left Facebook without landing on the product yet: let the
                # redirect chain settle before trying the follow link again.
                try:
                    await self.page.wait_for_load_state("domcontentloaded", timeout=8000)
                except Exception:
                    pass
                continue
            if not await self._click_facebook_follow_link():
                break
        return self.is_target_product_url(self.page.url, product_id)

    async def open_product(self, data):
        product_id = str(data.get("productId") or "")
        product_url = str(data.get("productUrl") or "")
        max_pages = int(self.payload.get("maxSearchPages") or 2)
        lookup = build_product_lookup(product_id, str(data.get("productName") or ""), product_url)
        self.machine.log(
            "OPEN_PRODUCT_LOOKUP"
            f" itemKey={int(bool(lookup['item_id']))}"
            f" nameKey={int(bool(lookup['name_tokens']))}"
            f" titleKey={int(bool(lookup['title_query']))}"
            f" shopKey={int(bool(lookup['shop_id']))}"
            f" productId={product_id or '-'}"
            f" resolvedFromUrl={int(bool(lookup['item_id_from_url']))}"
        )

        # A brand new listing is the normal case here, and a new listing does not rank for a
        # broad category keyword. So the keyword search is only the first rung: the product
        # is then looked for inside its own shop, and every rung stays inside Shopee so the
        # product keeps a real in-site referrer. Only when the whole ladder comes back empty
        # is the saved link entered through Facebook.
        #
        # The order is fixed and every rung is entered: marketplace search, then the shop's
        # own listings, then the Facebook hop, then the direct link. A 45-second wall-clock
        # budget used to sit in front of the shop rung, and two scanned search pages already
        # cost ~75 seconds, so the run skipped the shop and fell straight to Facebook - the
        # shop was never read even though it was the rung most likely to hold the product.
        found = None
        route = ""
        page_no = 1
        search_yields_results = True
        # The app sends this flag when the same (keyword + product) pair has just been missed
        # by several nicks in a row: a brand new listing does not rank for a broad keyword, so
        # the marketplace rung only spends the session. The rung is dropped and the shop's own
        # listings are read straight away. Without a shop id there is no rung 2 to fall back
        # on, so the marketplace search still runs there.
        skip_market_search = bool(data.get("skipMarketSearch")) and bool(lookup["shop_id"])
        if lookup["item_id"] or lookup["name_tokens"]:
            if skip_market_search:
                self.machine.log("MARKET_SEARCH_SKIPPED reason=streak")
                search_yields_results = False
            else:
                found, page_no, keyword_scan = await self._scan_results_pages(lookup, max_pages)
                if found:
                    route = "ORGANIC_SEARCH"
                else:
                    search_yields_results = int(keyword_scan.get("count") or 0) > 0
                    if not search_yields_results:
                        # An empty result page for a keyword that certainly has matches means the
                        # search endpoint is being held back for this session. Repeating the same
                        # search under another query would return the same empty shell.
                        self.machine.log("SEARCH_UNRELIABLE reason=empty_results_page")
        else:
            self.machine.log("SEARCH_ORGANIC_SKIPPED reason=no_lookup_key")

        shop_query = str(data.get("keyword") or "")

        # Rung 2 - the shop's own listings. This is the rung a new product needs: inside a
        # shop of a few hundred listings the keyword alone reaches it, and the in-shop search
        # walks every page until Shopee reports no next page.
        if not found and lookup["shop_id"]:
            found = await self._find_on_shop_page(lookup, shop_query)
            if found:
                route = "SHOP_SEARCH"

        # Rung 3, only when there is no shop to search inside: the product's own title as a
        # global query is the last chance before leaving Shopee.
        if not found and not lookup["shop_id"] and lookup["title_query"] and search_yields_results:
            found = await self._find_after_search(lookup["title_query"], lookup, "TITLE")
            if found:
                route = "TITLE_SEARCH"

        if found:
            self.machine.log(f"OPEN_PRODUCT_ROUTE route={route} position={int(found.get('position') or 0)}")
            await self._click_product_card(found)
            self.last_product = found
            # The page the click actually landed on decides success, not the route: without
            # this check a run that stayed on the search page was reported as "opened".
            opened_ok = self.is_target_product_url(self.page.url, str(found.get("id") or ""))
            result = {"searchOutcome": "FOUND", "route": route, "searchPage": page_no, "position": found["position"], "href": self.page.url, "method": route, "productOpened": opened_ok}
        else:
            actual_method = "DIRECT_URL"
            if product_url:
                self.machine.log(f"SEARCH_ORGANIC_NOT_FOUND page={page_no} max={max_pages}")
                self.machine.log("OPEN_PRODUCT_FB_NAVIGATE")
                if await self._navigate_via_facebook(product_url, product_id):
                    self.machine.log("OPEN_PRODUCT_FB_LANDED")
                    actual_method = "FACEBOOK_INDIRECT"
                else:
                    self.machine.log("OPEN_PRODUCT_FB_FAIL")
                    self.machine.log("OPEN_PRODUCT_DIRECT_FALLBACK")
                    await self._navigate_product_fallback(product_url, product_id)
                    if not self.is_target_product_url(self.page.url, product_id):
                        actual_method = "DIRECT_URL_UNVERIFIED"
                try: await self.page.wait_for_load_state("load", timeout=20000)
                except Exception: pass
            result = {"searchOutcome": "NOT_FOUND", "searchOutcomeLoggedEarly": bool(product_url), "searchPage": page_no, "position": 0, "href": self.page.url, "direct": True, "method": actual_method if product_url else "NO_PRODUCT_URL", "productOpened": self.is_target_product_url(self.page.url, product_id)}
        if result.get("productOpened", True):
            self._last_product_url = str(self.page.url or "")
            self._last_product_open_method = str(result.get("method") or ("ORGANIC_SEARCH" if result.get("searchOutcome") == "FOUND" else ""))
            self._skip_media_for_current_product = False
            self.on_shop = False
        # Emit result first so C# describes the search outcome before announcing
        # that the final product page (organic or fallback) is ready.
        product_opened = bool(result.get("productOpened", True))
        self.machine.result("OPEN_PRODUCT", "OK" if product_opened else "ERROR", result)
        if product_opened:
            # Settle delay: Allow Shopee telemetry, cookies, and anti-bot token to settle before interactions (1.5s - 2.5s)
            await asyncio.sleep(random.uniform(1.5, 2.5))
            self.emit("AUTOMATION_PRODUCT_CONTENT_READY: " + self.page.url)
        return product_opened

    async def click_by_text(self, texts):
        for text in texts:
            loc = self.page.locator("button,a,[role='button']").filter(has_text=text)
            try:
                for index in range(await loc.count()):
                    candidate = loc.nth(index)
                    if await candidate.is_visible(timeout=500):
                        await self._motion_click_locator(candidate, timeout=5000)
                        return True
            except Exception:
                continue
        return False

    async def click_stable_media_thumbnail(self, prefer_video: bool):
        """Resolve the live gallery thumbnail at click time so React replacements cannot stale the target."""
        thumbs = self.page.locator(".Wi_1Rq .qIctnQ,.Wi_1Rq .mdCA_C")
        target = None
        marker_selector = "img.emXGWZ,img[alt*='video' i],video"
        for index in range(min(await thumbs.count(), 20)):
            candidate = thumbs.nth(index)
            try:
                marker_count = await candidate.locator(marker_selector).count()
                image_count = await candidate.locator("img").count()
                if (prefer_video and marker_count > 0) or (not prefer_video and marker_count == 0 and image_count > 0):
                    target = candidate
                    break
            except Exception:
                continue
        if target is None:
            return {"clicked": False, "reason": "TARGET_NOT_FOUND"}
        try:
            await target.wait_for(state="visible", timeout=5000)
            initial_box = await target.bounding_box()
            if not initial_box:
                return {"clicked": False, "reason": "NO_BOUNDING_BOX"}
            live_box = await target.bounding_box()
            if not live_box:
                return {"clicked": False, "reason": "NO_BOUNDING_BOX"}
            relative_x = float(live_box["width"]) * max(0.20, min(0.80, random.gauss(0.5, 0.10)))
            relative_y = float(live_box["height"]) * max(0.20, min(0.80, random.gauss(0.5, 0.10)))

            # Natural gaze hesitation before clicking media thumbnail
            await asyncio.sleep(random.uniform(0.15, 0.35))
            await self._motion_click_at(float(live_box["x"]) + relative_x, float(live_box["y"]) + relative_y, live_box.get("width"))

            return {
                "clicked": True,
                "box": live_box,
                "point": {"x": float(live_box["x"]) + relative_x, "y": float(live_box["y"]) + relative_y},
            }
        except Exception as ex:
            return {"clicked": False, "reason": type(ex).__name__}

    async def click_main_product_image(self):
        """Click the live main product image after an image thumbnail has been selected."""
        candidates = self.page.locator("img.e3bgiU,.center.VmNEQ6 img,[class*='product-image'] img")
        for index in range(min(await candidates.count(), 12)):
            candidate = candidates.nth(index)
            try:
                if not await candidate.is_visible(timeout=500):
                    continue
                box = await candidate.bounding_box()
                if not box or float(box.get("width") or 0) < 240 or float(box.get("height") or 0) < 240:
                    continue
                relative_x = float(box["width"]) * max(0.20, min(0.80, random.gauss(0.5, 0.10)))
                relative_y = float(box["height"]) * max(0.20, min(0.80, random.gauss(0.5, 0.10)))

                await asyncio.sleep(random.uniform(0.15, 0.35))
                await self._motion_click_at(float(box["x"]) + relative_x, float(box["y"]) + relative_y, box.get("width"))

                return {"clicked": True, "box": box}
            except Exception:
                continue
        return {"clicked": False, "reason": "MAIN_IMAGE_NOT_FOUND"}

    async def interact(self, data):
        phase=data.get("phase"); actions=self.payload.get("actions") or {}
        result={"phase":phase}
        viewport = self.page.viewport_size
        if phase == "preScroll":

            if actions.get("viewMedia") and not bool(getattr(self, "_skip_media_for_current_product", False)):
                self.machine.log("PRODUCT_MEDIA_VIEW_BEGIN")
                self._workflow_stage = "media_before_input"
                # Đồng hồ của khâu xem ảnh/video: mọi khoảng chờ bên dưới chỉ được lấy phần
                # ngân sách còn lại, và cuối khâu sẽ ngồi thêm nếu chưa đủ 5 giây.
                media_started = asyncio.get_running_loop().time()

                def media_time_left(reserve=PRODUCT_MEDIA_CLOSE_RESERVE_SECONDS):
                    return product_media_time_left(media_started, reserve)

                def media_wait_ms(cap_ms):
                    """Chờ tối đa cho một bước, chừa sẵn cả thời gian đóng popup lẫn đường thoát dự phòng."""
                    budget = media_time_left(PRODUCT_MEDIA_CLOSE_RESERVE_SECONDS + 1.2)
                    return max(600, int(min(float(cap_ms), budget * 1000.0)))

                media_inventory = await self.evaluate("product", "mediaInventory")

                media = await self.evaluate("product", "mediaTarget")
                if media.get("found"):
                    media_stage = "target_created"
                    try:

                        media_stage = "coordinate_relocate"
                        media = await self.evaluate("product", "mediaTarget")
                        box = media.get("box") or {}
                        if not media.get("found") or not box:
                            raise RuntimeError("Media target has no current bounding box")

                        # Look at the gallery for a beat before enlarging it, the way a
                        # visitor decides which image is worth opening.
                        await self._motion_look_at(
                            float(box["x"]) + float(box["width"]) * random.uniform(.35, .65),
                            float(box["y"]) + float(box["height"]) * random.uniform(.35, .65),
                            box.get("width"),
                            dwell=min(random.uniform(0.9, 1.6), max(0.3, media_time_left())),
                        )
                        self._workflow_stage = "media_video_click"
                        stable_video_click = await self.click_stable_media_thumbnail(bool(media.get("video")))
                        if not stable_video_click.get("clicked"):
                            raise RuntimeError("Stable media target unavailable: " + str(stable_video_click.get("reason") or "UNKNOWN"))

                        try:
                            await self.page.wait_for_function("() => !!document.querySelector(\"[role='dialog'],.UCGJYT,.NDTw5b,.aUuKn4,[class*='product-image'] [class*='modal'],[class*='video'] [class*='modal']\") || [...document.querySelectorAll('video')].some(v => !v.paused)", timeout=media_wait_ms(5000))
                        except Exception:
                            pass
                        media_stage = "lightbox_check"
                        opened = (await self.evaluate("product", "lightbox")).get("open", False)
                        media_state = await self.page.evaluate("""() => ({playingVideoCount: [...document.querySelectorAll('video')].filter(video => video.getClientRects().length > 0 && !video.paused).length})""")
                        inline_video_playing = bool(media.get("video")) and int(media_state.get("playingVideoCount") or 0) > 0
                        playback_state = {}
                        if inline_video_playing:
                            try:
                                playback_state = await self.page.evaluate("""() => { const videos=[...document.querySelectorAll('video')].filter(v=>v.getClientRects().length>0&&!v.paused&&!v.ended); return {startTimes:videos.map(v=>Number(v.currentTime||0)),playing:videos.length}; }""")
                                await self.page.wait_for_function("""state => { const videos=[...document.querySelectorAll('video')].filter(v=>v.getClientRects().length>0); return videos.some((v,index)=>v.ended||v.paused||Number(v.currentTime||0)>=Number(state.startTimes[index]||0)+1.5); }""", arg=playback_state, timeout=media_wait_ms(6000))
                            except Exception:
                                pass
                        settled_lightbox = await self.evaluate("product", "lightbox")
                        opened = bool(settled_lightbox.get("open", False))
                        image_fallback = {"attempted": False, "found": False, "opened": False}
                        if media.get("video") and not opened and int(media_inventory.get("imageThumbnails") or 0) > 0:
                            media_stage = "image_fallback"
                            image_target = await self.evaluate("product", "mediaImageTarget")
                            image_fallback = {"attempted": True, "found": bool(image_target.get("found")), "opened": False}
                            image_box = image_target.get("box") or {}
                            if image_target.get("found") and image_box:
                                self._workflow_stage = "media_image_click"
                                stable_image_click = await self.click_stable_media_thumbnail(False)
                                if not stable_image_click.get("clicked"):
                                    raise RuntimeError("Stable image target unavailable: " + str(stable_image_click.get("reason") or "UNKNOWN"))
                                opened = bool((await self.evaluate("product", "lightbox")).get("open", False))
                                main_image_click = {"clicked": False, "reason": "THUMBNAIL_OPENED_LIGHTBOX"}
                                if not opened:
                                    self._workflow_stage = "media_main_image_click"
                                    main_image_click = await self.click_main_product_image()
                                    if not main_image_click.get("clicked"):
                                        raise RuntimeError("Main product image unavailable: " + str(main_image_click.get("reason") or "UNKNOWN"))

                                try:
                                    await self.page.wait_for_function("() => !!document.querySelector(\"[role='dialog'],.UCGJYT,.NDTw5b,.aUuKn4,[class*='product-image'] [class*='modal']\")", timeout=media_wait_ms(5000))
                                except Exception:
                                    pass
                                opened = (await self.evaluate("product", "lightbox")).get("open", False)
                                image_fallback["opened"] = bool(opened)
                                image_fallback["mainImageClicked"] = bool(main_image_click.get("clicked"))

                        next_viewed = 0
                        planned_next = random.randint(2, 3)
                        for media_next_index in range(planned_next):
                            self._workflow_stage = f"media_next_{media_next_index + 1}"
                            # Ngân sách 10 giây đã cạn: đóng popup luôn còn hơn mở thêm một
                            # ảnh rồi phải cắt ngang lúc đang xem.
                            if media_time_left(PRODUCT_MEDIA_CLOSE_RESERVE_SECONDS + 0.6) < 0.8:
                                break
                            next_state = {"found": False, "reason": "LIGHTBOX_NOT_OPEN"}
                            if opened:
                                next_state = await self.evaluate("product", "mediaNext")

                            next_box = next_state.get("box") or {}
                            if not opened or not next_state.get("found") or not next_box:
                                break
                            await self._motion_click_at(
                                float(next_box["x"]) + float(next_box["width"]) * random.uniform(.35, .65),
                                float(next_box["y"]) + float(next_box["height"]) * random.uniform(.35, .65),
                                next_box.get("width"),
                            )
                            next_viewed += 1

                            # Dwell on each frame before advancing: three images in eight
                            # seconds is a gallery crawl, not a person looking at photos.
                            # The dwell takes only what is left of the ten-second budget.
                            await asyncio.sleep(min(random.uniform(1.8, 3.0), max(0.2, media_time_left(PRODUCT_MEDIA_CLOSE_RESERVE_SECONDS + 0.4))))
                        self._workflow_stage = "media_close"
                        close = await self.evaluate("product", "mediaClose")
                        popup_closed = not bool(close.get("open"))
                        close_box = close.get("box") or {}
                        if not popup_closed and close.get("found") and close_box:
                            await self._motion_click_at(
                                float(close_box["x"]) + float(close_box["width"]) * random.uniform(.35, .65),
                                float(close_box["y"]) + float(close_box["height"]) * random.uniform(.35, .65),
                                close_box.get("width"),
                            )
                            try:
                                await self.page.wait_for_function("() => !document.querySelector(\"[role='dialog'],.UCGJYT,.NDTw5b,.aUuKn4,[class*='product-image'] [class*='modal'],[class*='video'] [class*='modal']\")", timeout=1500)
                            except Exception:
                                pass
                            popup_closed = not bool((await self.evaluate("product", "lightbox")).get("open", False))
                        if not popup_closed:

                            await self._motion_press_key("Escape")
                            try:
                                await self.page.wait_for_function("() => !document.querySelector(\"[role='dialog'],.UCGJYT,.NDTw5b,.aUuKn4,[class*='product-image'] [class*='modal'],[class*='video'] [class*='modal']\")", timeout=1500)
                            except Exception:
                                pass
                            popup_closed = not bool((await self.evaluate("product", "lightbox")).get("open", False))

                        # Tổng thời gian xem đạt tối thiểu 5 giây: đóng popup sớm hơn thì ngồi
                        # lại cho tròn, còn trần 10 giây đã được giữ ở mọi khoảng chờ phía trên.
                        media_elapsed = asyncio.get_running_loop().time() - media_started
                        if media_elapsed < PRODUCT_MEDIA_VIEW_MIN_SECONDS:
                            await asyncio.sleep(PRODUCT_MEDIA_VIEW_MIN_SECONDS - media_elapsed)

                        final_pause_state = await self.evaluate("product", "mediaState")
                        result["media"]={"status":"OK" if opened or inline_video_playing or media.get("video") else "NOT_FOUND","opened":opened,"video":bool(media.get("video")),"inlineVideoPlaying":inline_video_playing,"imageFallback":image_fallback,"nextViewed":next_viewed,"nextRequested":planned_next,"popupClosed":popup_closed,"videoPaused":int(final_pause_state.get("playing") or 0)==0}
                    except Exception as ex:
                        self._workflow_stage = "media_error_cleanup"
                        error_close = {}
                        error_popup_closed = False
                        error_pause = {}
                        try:
                            error_close = await self.evaluate("product", "mediaClose")
                            error_popup_closed = bool(error_close.get("closed"))
                            if not error_popup_closed:
                                await self._motion_press_key("Escape")
                                try:
                                    await self.page.wait_for_function("() => !document.querySelector(\"[role='dialog'],.UCGJYT,.NDTw5b,.aUuKn4,[class*='product-image'] [class*='modal'],[class*='video'] [class*='modal']\")", timeout=1500)
                                except Exception:
                                    pass
                                error_popup_closed = not bool((await self.evaluate("product", "lightbox")).get("open", False))
                            error_pause = await self.evaluate("product", "mediaPause")
                        except Exception:
                            pass
                        result["media"]={"status":"ERROR","stage":media_stage,"error":type(ex).__name__,"popupClosed":error_popup_closed,"videoPaused":int(error_pause.get("playingAfter") or 0)==0}
                else: result["media"]={"status":"NOT_FOUND"}
                self._workflow_stage = "media_complete"

                if self._captcha_navigation_active():
                    result["media"]={**result.get("media", {}),"status":"CAPTCHA","stage":"MEDIA"}
                    self.machine.log("PRODUCT_CAPTCHA_AFTER_MEDIA")
                    self.machine.result("INTERACT_PRODUCT", "NEED_CAPTCHA", result)
                    await self.finish_unresolved_captcha()
                    return
                media_result=result.get("media", {})
                if media_result.get("video") and not media_result.get("opened"):
                    self.machine.log("PRODUCT_MEDIA_VIDEO_DONE")
                elif media_result.get("status") == "OK":
                    self.machine.log(f"PRODUCT_MEDIA_VIEW_DONE next={int(media_result.get('nextViewed') or 0)} requested={int(media_result.get('nextRequested') or 0)} closed={1 if media_result.get('popupClosed') else 0}")
                # Read-back beat after the viewer closes, so the following scroll task does
                # not begin in the very same frame the popup disappeared.
                await asyncio.sleep(random.uniform(0.9, 1.7))
            elif actions.get("viewMedia"):
                result["media"] = {"status": "SKIPPED_CAPTCHA"}
                self.machine.log("PRODUCT_MEDIA_VIEW_SKIPPED_AFTER_CAPTCHA")
            if actions.get("like"):
                self.machine.log("PRODUCT_LIKE_BEGIN")
                clicked = False
                state=await self.evaluate("product","like")
                if state.get("status")=="READY":
                    box=state.get("box") or {}
                    if box:
                        x=float(box["x"])+float(box["width"])*random.uniform(.35,.65)
                        y=float(box["y"])+float(box["height"])*random.uniform(.35,.65)
                        self._workflow_stage = "like_click"
                        await self._motion_click_at(x, y, box.get("width"))
                        try:
                            await self.page.wait_for_function("() => { const p=document.querySelector('svg.xwwO4T path'); return p && String(p.getAttribute('fill')||'').toLowerCase()==='#ff424f'; }",timeout=5000)
                        except Exception:
                            pass
                        post_like=await self.evaluate("product","like")
                        clicked=post_like.get("status")=="SKIPPED_ALREADY"
                    state["status"]="OK" if clicked else "ERROR"
                self.machine.log(f"PRODUCT_LIKE_RESULT status={state.get('status', 'UNKNOWN')} clicked={1 if clicked else 0}")
                result["like"]=state
                if self._captcha_navigation_active():
                    self.machine.log("PRODUCT_CAPTCHA_AFTER_LIKE")
                    self.machine.result("INTERACT_PRODUCT", "NEED_CAPTCHA", result)
                    await self.finish_unresolved_captcha()
                    return
                await asyncio.sleep(random.uniform(1.5,3.0))
            if actions.get("addToCart"):
                self._workflow_stage = "cart_probe"
                self.machine.log("PRODUCT_ADD_TO_CART_BEGIN")
                variant_steps = []
                variant_captcha = False

                final_variant_state = {"selectedGroups": 0, "totalGroups": 0, "complete": True}
                for variant_index in range(8):
                    current_variant_path = urlsplit(str(self.page.url or "")).path.lower()
                    if current_variant_path.startswith("/verify/"):
                        variant_captcha = True
                        final_variant_state = {**final_variant_state, "clicked": False, "complete": False}
                        break
                    variant_state = await self.evaluate("product", "variants")
                    variant_steps.append(variant_state)
                    final_variant_state = variant_state
                    if not variant_state.get("clicked"):
                        break
                    box=variant_state.get("box") or {}; viewport_height=float(variant_state.get("viewportHeight") or 800); viewport_width=float(variant_state.get("viewportWidth") or 1200)
                    for _ in range(20):
                        if not box: break
                        top=float(box["y"]); bottom=top+float(box["height"])
                        if top>=viewport_height*.12 and bottom<=viewport_height*.88: break
                        before_y=float(await self.page.evaluate("scrollY"))
                        await self._motion_wheel(-random.randint(140,220) if top<viewport_height*.12 else random.randint(140,220), viewport_width*.5, viewport_height*.5)
                        try:
                            await self.page.wait_for_function("before => Math.abs(scrollY-before)>8",arg=before_y,timeout=1500)
                        except Exception:
                            pass
                        variant_state=await self.evaluate("product","variants"); box=variant_state.get("box") or {}
                    if not box or not (0<=float(box["x"]) and float(box["x"])+float(box["width"])<=viewport_width and 0<=float(box["y"]) and float(box["y"])+float(box["height"])<=viewport_height):
                        final_variant_state={**variant_state,"clicked":False,"complete":False}; break
                    x=float(box["x"])+float(box["width"])*random.uniform(.3,.7)
                    y=float(box["y"])+float(box["height"])*random.uniform(.3,.7)

                    point_diag_before=await self.evaluate("product","pointDiag",{"x":x,"y":y})

                    target_text = str(variant_state.get("target") or "").strip()
                    hit_text = str(point_diag_before.get("buttonText") or "").strip()
                    if not point_diag_before.get("insideVariant") or (target_text and hit_text and target_text != hit_text):
                        try:
                            await self.page.wait_for_url("**/verify/**", wait_until="commit", timeout=750)
                        except Exception:
                            pass
                        stale_path = urlsplit(str(self.page.url or "")).path.lower()
                        if stale_path.startswith("/verify/"):
                            variant_captcha = True
                            final_variant_state = {**variant_state, "clicked": False, "complete": False}
                            break
                        continue
                    self._workflow_stage = f"variant_{variant_index+1}_click"

                    await self._motion_click_at(x, y, box.get("width"))
                    expected = int(variant_state.get("expectedSelectedGroups") or 0)
                    if expected > 0:
                        try:
                            await self.page.wait_for_function("expected => document.querySelectorAll('button.selection-box-selected').length >= expected", arg=expected, timeout=3000)
                        except Exception:
                            pass
                    try:
                        await self.page.wait_for_url("**/verify/**", wait_until="commit", timeout=750)
                    except Exception:
                        pass
                    variant_captcha_after_click = self._captcha_navigation_active()

                    if variant_captcha_after_click:
                        variant_captcha = True
                        final_variant_state = {**variant_state, "clicked": False, "complete": False}
                        break
                    post_variant_state = await self.evaluate("product", "variants")
                    selected_before = int(variant_state.get("selectedGroups") or 0)
                    selected_after = int(post_variant_state.get("selectedGroups") or 0)
                    if selected_after <= selected_before:
                        final_variant_state = {**post_variant_state, "clicked": False, "complete": False}
                        break
                    final_variant_state = post_variant_state
                selected_groups = int(final_variant_state.get("selectedGroups") or 0)
                total_groups = int(final_variant_state.get("totalGroups") or 0)
                variants_complete = bool(final_variant_state.get("complete"))
                result["variants"] = {"steps": variant_steps, "selectedGroups": selected_groups, "totalGroups": total_groups, "complete": variants_complete}
                self.machine.log(f"PRODUCT_VARIANTS_RESULT selected={selected_groups} total={total_groups} complete={1 if variants_complete else 0}")
                state={"status":"CAPTCHA","stage":"VARIANT"} if variant_captcha else ({"status":"BLOCKED"} if total_groups > 0 and not variants_complete else await self.evaluate("product","cart"))
                if state.get("status")=="READY":
                    self.machine.log("PRODUCT_CART_SCROLL_TO_BUTTON")
                    await self.evaluate("product","cartScroll")
                    try:
                        await self.page.wait_for_function("() => { const b=document.querySelector(\"button:has(img[alt='icon-add-to-cart'])\"); if(!b)return false; const r=b.getBoundingClientRect(); return r.top>=0 && r.bottom<=innerHeight; }",timeout=5000)
                    except Exception:
                        pass
                    state=await self.evaluate("product","cart")
                    box=state.get("box") or {}; before_count=str(state.get("cartCount") or "")
                    if box:
                        x=float(box["x"])+float(box["width"])*random.uniform(.35,.65)
                        y=float(box["y"])+float(box["height"])*random.uniform(.35,.65)

                        self._workflow_stage = "cart_click"
                        await self._motion_click_at(x, y, box.get("width"))
                        try:
                            await self.page.wait_for_function("before => { const text=document.body?.innerText||''; const badge=document.querySelector('.shopee-cart-number-badge,[class*=cart-number-badge],a[href*=\"/cart\"] [class*=badge]'); const count=badge?(badge.textContent||'').trim():''; return /đã được thêm vào giỏ hàng|added to (your )?cart/i.test(text)||/\\/verify\\/captcha|\\/captcha/i.test(location.href)||(count&&count!==before); }",arg=before_count,timeout=8000)
                        except Exception:
                            pass
                        post_cart=await self.evaluate("product","cartResult")
                        count_changed=bool(post_cart.get("cartCount") and str(post_cart.get("cartCount"))!=before_count)
                        state={"status":"CAPTCHA" if post_cart.get("captcha") else ("OK" if post_cart.get("added") or count_changed else "ERROR"),"added":bool(post_cart.get("added") or count_changed),"cartCount":post_cart.get("cartCount","")}

                    else:
                        state={"status":"ERROR"}
                self.machine.log(f"PRODUCT_ADD_TO_CART_RESULT status={state.get('status', 'UNKNOWN')} stage={state.get('stage', '')}")
                result["addToCart"]=state
                if state.get("status") == "CAPTCHA":
                    self.machine.result("INTERACT_PRODUCT", "NEED_CAPTCHA", result)
                    await self.finish_unresolved_captcha()
                    return
                await asyncio.sleep(random.uniform(2.0,4.0))
        elif phase == "review":
            self._workflow_stage = "review_begin"
            self.machine.log("PRODUCT_REVIEW_BEGIN")
            if self._pending_navigation_risk or self._captcha_navigation_active():
                self.machine.result("INTERACT_PRODUCT", "NEED_CAPTCHA", {**result, "review":{"status":"CAPTCHA","stage":"ENTRY"}})
                await self.finish_unresolved_captcha()
                return
            anchor={"found":False}
            anchor_steps = 0
            viewport_height = viewport.get("height", 800) if isinstance(viewport, dict) else 800
            for step in range(30):
                if self._pending_navigation_risk or urlsplit(str(self.page.url or "")).path.lower().startswith("/verify/"):
                    self.machine.result("INTERACT_PRODUCT", "NEED_CAPTCHA", {**result, "review":{"status":"CAPTCHA","stage":"ANCHOR_SCROLL","steps":anchor_steps}})
                    await self.finish_unresolved_captcha()
                    return
                anchor=await self.evaluate("product","reviewAnchor")
                if anchor.get("found") and anchor.get("top",9999)<viewport_height*.85: break
                await self._motion_wheel(random.randint(180,240))
                anchor_steps += 1
                await asyncio.sleep(random.uniform(.5,.9))
            self._workflow_stage = "review_anchor_resolved"
            anchor_navigation_risk = self._captcha_navigation_active()
            if self._pending_navigation_risk or anchor_navigation_risk:
                self.machine.result("INTERACT_PRODUCT", "NEED_CAPTCHA", {**result, "review":{"status":"CAPTCHA","stage":"ANCHOR_RESOLVED","steps":anchor_steps}})
                await self.finish_unresolved_captcha()
                return
            result["reviewAnchor"]=anchor
            if anchor.get("found"):
                await asyncio.sleep(random.uniform(2.5,4.0))
                all_filter=self.page.get_by_text("Tất cả",exact=True).or_(self.page.get_by_text("All",exact=True)).first
                try:
                    if await all_filter.is_visible(timeout=1000): await self._motion_click_locator(all_filter); await asyncio.sleep(2.0)
                except Exception: pass
                media=self.page.locator(".shopee-rating-media-list-image__content--blur,.rating-media-list__image-wrapper")
                opened=0
                for i in range(min(await media.count(),3)):
                    if self._pending_navigation_risk or urlsplit(str(self.page.url or "")).path.lower().startswith("/verify/"):
                        self.machine.result("INTERACT_PRODUCT", "NEED_CAPTCHA", {**result, "review":{"status":"CAPTCHA","stage":"MEDIA","mediaOpened":opened}})
                        await self.finish_unresolved_captcha()
                        return
                    self._workflow_stage = f"review_media_{i+1}_before"

                    try:
                        await self._motion_click_locator(media.nth(i));opened+=1;await asyncio.sleep(random.uniform(1.4,2.6));await self._motion_press_key("Escape");await asyncio.sleep(0.6)
                    except Exception: pass
                    self._workflow_stage = f"review_media_{i+1}_after"

                result["review"]={"status":"OK","mediaOpened":opened}
            else: result["review"]={"status":"NOT_FOUND"}
            self._workflow_stage = "review_complete"

        status="OK" if any(v not in ({"status":"NOT_FOUND"},False,None) for k,v in result.items() if k!="phase") else "NOT_FOUND"
        self.machine.result("INTERACT_PRODUCT",status,result)

from __future__ import annotations

import json
import time
from collections import deque
from typing import Any, Callable

class AutomationStateMachine:
    """Deterministic task queue for the direct ShardX/Patchright executor."""

    def __init__(self, payload: dict[str, Any], emit: Callable[[str], None]):
        self.payload = payload
        self.emit = emit
        self.items = list(payload.get("items") or [])
        self.actions = dict(payload.get("actions") or {})
        self.queue: deque[dict[str, Any]] = deque()
        self.index = -1
        self.done = False
        self.keyword_started_at = 0.0
        self._pending_open_risk = ""

    def log(self, message: str, level: str = "info", **data: Any) -> None:
        body = {"level": level, "message": message}
        if data:
            body["data"] = data
        self.emit("AUTOMATION_LOG: " + json.dumps(body, ensure_ascii=False, separators=(",", ":")))

    def result(self, task_type: str, status: str, result: dict[str, Any] | None = None) -> None:
        self.emit(
            f"AUTOMATION_RESULT: {task_type} status={status} result="
            + json.dumps(result or {}, ensure_ascii=False, separators=(",", ":"))
        )

    def enqueue(self, task_type: str, payload: dict[str, Any] | None = None) -> None:
        self.queue.append({"type": task_type, "payload": payload or {}})
        self.emit("AUTOMATION_TASK_QUEUED: " + task_type)

    def start(self) -> None:
        self.enqueue("OPEN_HOME")
        self.enqueue("CHECK_LOGIN")

    def next_task(self) -> dict[str, Any] | None:
        return self.queue.popleft() if self.queue else None

    def start_next_keyword(self) -> None:
        self.index += 1
        if self.index >= len(self.items):
            self.finish()
            return
        self.keyword_started_at = time.monotonic()
        item = self.items[self.index]
        self.emit(f"AUTOMATION_KEYWORD_BEGIN: index={self.index + 1} total={len(self.items)}")
        self.enqueue("SEARCH_KEYWORD", item)
        self.enqueue("OPEN_PRODUCT", item)
        if any(self.actions.get(key) for key in ("viewMedia", "like", "addToCart")):
            self.enqueue("INTERACT_PRODUCT", {**item, "phase": "preScroll"})
        self.enqueue("SCROLL_PRODUCT", item)
        if self.actions.get("review"):
            self.enqueue("INTERACT_PRODUCT", {**item, "phase": "review"})
        if self.actions.get("viewShop"):
            self.enqueue("VIEW_SHOP", item)
            if self.actions.get("followShop"):
                self.enqueue("FOLLOW_SHOP", item)
            self.enqueue("SCROLL_SHOP", item)
        elif self.actions.get("followShop"):
            self.enqueue("FOLLOW_SHOP", item)
        self.enqueue("KEYWORD_DONE", item)

    def abort_current_keyword(self, reason: str) -> None:
        """Discard tasks that require the product when opening it did not succeed."""
        if self.done:
            return
        discarded = [task.get("type", "") for task in list(self.queue)]
        self.queue.clear()
        self.keyword_started_at = 0.0
        self.emit(f"AUTOMATION_KEYWORD_ABORTED: index={self.index + 1} reason={reason or 'UNKNOWN'}")
        self.emit(f"AUTOMATION_KEYWORD_DONE: {self.index + 1}/{len(self.items)} reason=open_product_failed")
        if self.index + 1 < len(self.items):
            self.emit("AUTOMATION_NEXT_KEYWORD_VIA_HOME")
            self.enqueue("OPEN_HOME", {"viaLogo": True})
            self.enqueue("NEXT_KEYWORD")
        else:
            self.finish()

    def keyword_done(self, timeout: bool = False) -> None:
        if self.done:
            return
        self.keyword_started_at = 0.0
        if timeout:
            self.queue.clear()
        reason = " reason=timeout" if timeout else ""
        if timeout:
            self.emit(f"AUTOMATION_KEYWORD_TIMEOUT: index={self.index + 1}")
        self.emit(f"AUTOMATION_KEYWORD_DONE: {self.index + 1}/{len(self.items)}{reason}")
        if self.index + 1 < len(self.items):
            self.emit("AUTOMATION_NEXT_KEYWORD_VIA_HOME")
            self.enqueue("OPEN_HOME", {"viaLogo": True})
            self.enqueue("NEXT_KEYWORD")
        else:
            self.finish()

    def risk(self, risk: str, close: bool = True) -> None:
        normalized = str(risk or "").strip()
        duplicate_close = bool(close and normalized and normalized == self._pending_open_risk)
        if not duplicate_close:
            self.emit(f"AUTOMATION_NICK_STATUS: risk={normalized} close={1 if close else 0}")
        self._pending_open_risk = "" if close else normalized
        if close:
            self.emit("AUTOMATION_CLOSE_BROWSER")
            self.finish()

    def finish(self) -> None:
        if self.done:
            return
        self.done = True
        self.emit("AUTOMATION_DONE")

    def stop(self) -> None:
        self.done = True
        self.queue.clear()

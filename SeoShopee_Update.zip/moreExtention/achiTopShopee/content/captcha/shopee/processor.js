CaptchaProcessors.register({
    captchaType: "shopee",
    canBeProcessed: function(e, t) {
        return !!$("#" + e.containerId).length
    },
    attachButton: function(e, t, n) {
        e = $("#" + e.containerId);
        n.css({
            width: e.find("iframe").outerWidth() + "px"
        }), e.append(n), t.tiktok_auto_solve && n.click()
    },
    getParams: function(e, t) {
        return e
    },
    onSolved: async function(e, t) {
        t = parseInt(t);
        let a = document.querySelector('[draggable="true"]');
        var n = a.getBoundingClientRect();
        let c = n.left + n.width / 2,
            o = n.top + n.height / 2 + 10 * Math.random() - 5,
            i = c + t,
            r = o + 10 * Math.random() - 5,
            l = (a.dispatchEvent(new MouseEvent("mousedown", {
                bubbles: !0,
                cancelable: !0,
                clientX: c,
                clientY: o
            })), setInterval(function() {
                var e = i - c + 3 * Math.random() - 3,
                    t = r - o,
                    n = 1e3 / l * 20,
                    e = (c += Math.min(e, n), o += Math.min(t, n), new MouseEvent("mousemove", {
                        bubbles: !0,
                        cancelable: !0,
                        clientX: c,
                        clientY: o
                    }));
                a.dispatchEvent(e)
            }, 50));
        await new Promise(e => setTimeout(e, 2483)), clearInterval(l), a.dispatchEvent(new MouseEvent("mouseup", {
            bubbles: !0,
            cancelable: !0,
            clientX: c,
            clientY: o
        })), await new Promise(e => setTimeout(e, 3e3)), resetCaptchaWidget(e.captchaType, e.widgetId)
    },
    getForm: function(e) {
        return !1
    },
    getCallback: function(e) {
        return null
    }
});
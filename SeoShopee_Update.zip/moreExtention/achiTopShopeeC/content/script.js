let scripts = [
    "content/core_helpers.js",
    "content/communication_helpers.js",
    "content/captcha/recaptcha/hunter.js",
    "content/captcha/recaptcha/interceptor.js"
];

for (let script of scripts) {
    let scriptElement = document.createElement("script");
    scriptElement.src = chrome.runtime.getURL(script);
    (document.head || document.documentElement).prepend(scriptElement);
}

let CaptchaProcessors = {
    list: {},
    register: function(processor) {
        this.list[processor.captchaType] = processor;
    },
    get: function(captchaType) {
        return this.list[captchaType];
    }
};

let CAPTCHA_WIDGETS_LOOP;

function doActionsOnSuccess(result) {
    try {
        let widgetInfo = getWidgetInfo(result.request.captchaType, result.request.widgetId);
        if (!widgetInfo) {
            console.error("Widget info not found");
            return;
        }

        let processor = CaptchaProcessors.get(result.request.captchaType);
        if (!processor) {
            console.error("Processor not found for captcha type:", result.request.captchaType);
            return;
        }

        processor.onSolved(widgetInfo, result.response);

        getConfig().then(() => {
            let callback = processor.getCallback(widgetInfo);
            if (callback) {
                let callbackTrigger = document.createElement("textarea");
                callbackTrigger.id = "twocaptcha-callback-trigger";
                callbackTrigger.setAttribute("data-function", callback);
                callbackTrigger.value = result.response;
                document.body.appendChild(callbackTrigger);
            }
        });
    } catch (error) {
        console.error("Error in doActionsOnSuccess:", error);
    }
}

function doActionsOnFail(result) {
    try {
        if (!result || !result.request) {
            console.error("Invalid result object in doActionsOnFail");
            return;
        }

        let widgetInfo = getWidgetInfo(result.request.captchaType, result.request.widgetId);
        if (!widgetInfo) {
            console.error("Widget info not found for", result.request.captchaType, result.request.widgetId);
            return;
        }

        let processor = CaptchaProcessors.get(result.request.captchaType);
        if (!processor) {
            console.error("Processor not found for captcha type:", result.request.captchaType);
            return;
        }

        // Kiểm tra xem processor có hàm onFail không
        if (typeof processor.onFail === 'function') {
            processor.onFail(widgetInfo);
        } else {
            console.warn("onFail method not found for processor:", result.request.captchaType);
            // Thực hiện hành động mặc định nếu không có onFail
            resetCaptchaWidget(result.request.captchaType, result.request.widgetId);
        }
    } catch (error) {
        console.error("Error in doActionsOnFail:", error);
    }
}
function resetCaptchaWidget(captchaType, widgetId) {
    console.log("Resetting CAPTCHA widget:", captchaType, widgetId);
    // Thực hiện logic reset ở đây
    // Ví dụ: xóa button solver, reset trạng thái, etc.
}
function createSolverButton(captchaType, widgetId) {
    let buttonText = chrome.i18n.getMessage("solveWithAchiCaptcha");
    
    let button = $(`
        <div class="captcha-solver" data-state="ready" data-captcha-type="${captchaType}" data-widget-id="${widgetId}">
            <div class="captcha-solver-image" style="background-color: rgb(25, 28, 27);">
                <img src="${chrome.runtime.getURL("/assets/icon/16.png")}">
            </div>
            <div class="captcha-solver-info" style="font-size: initial;color: rgb(0, 0, 0);">${buttonText}</div>
        </div>
    `);

    button.click(function(e) {
        e.stopPropagation();
        let state = button.attr("data-state");
        if (["ready", "error"].includes(state)) {
            if (button.attr("data-count-errors") && button.attr("data-disposable")) {
                changeSolverButtonState(button, "error", captchaType, "EXPIRED");
                return;
            }
            changeSolverButtonState(button, "solving", captchaType, chrome.i18n.getMessage("solving"));
            let widgetInfo = getWidgetInfo(captchaType, widgetId);
            if (!widgetInfo) {
                console.error("Widget info not found");
                return;
            }
            getConfig().then(function(config) {
                let params = CaptchaProcessors.get(captchaType).getParams(widgetInfo, config);
                try {
                    chrome.runtime.sendMessage({
                        name: "content",
                        action: "solve",
                        captchaType: captchaType,
                        widgetId: widgetId,
                        params: params
                    }, function(response) {
                        let solverButton = getSolverButton(response.request.captchaType, response.request.widgetId);
                        if (!solverButton || solverButton.length === 0) {
                            console.error("Solver button not found", response.request);
                            return;
                        }
                        if (response.error === undefined) {
                            changeSolverButtonState(solverButton, "solved", response.request.captchaType, chrome.i18n.getMessage("solved"));
                            doActionsOnSuccess(response);
                        } else {
                            doActionsOnFail(response);
                            changeSolverButtonState(solverButton, "error", response.request.captchaType, response.error);
                        }
                    });
                } catch (error) {
                    console.error("Error sending message:", error);
                    resetCaptchaWidget(captchaType, widgetId);
                }
            });
        }
    });

    return button;
}
function changeSolverButtonState(button, state, captchaType, message) {
    if (!button || button.length === 0) {
        console.error("Button is undefined or empty in changeSolverButtonState", { captchaType, state, message });
        return;
    }

    getConfig().then(config => {
        button.attr("data-state", state);
        button.find(".captcha-solver-info").text(message);

        if (state === "error") {
            let countErrors = parseInt(button.attr("data-count-errors") || '0');
            button.attr("data-count-errors", (countErrors + 1).toString());
            
            button.find(".captcha-solver-image img").attr("src", chrome.runtime.getURL("assets/icon/16error.png"));
            
            if (config && config.refreshPage) {
                if (config.deleteCoockie) {
                    clearHOnlySessionCookie();
                }
                location.reload();
            }
        } else if (state === "solving") {
            button.find(".captcha-solver-image img").attr("src", chrome.runtime.getURL("assets/icon/loading.gif"));
        } else if (state === "solved") {
            button.find(".captcha-solver-image img").attr("src", chrome.runtime.getURL("assets/icon/success.gif"));
        }
    }).catch(error => {
        console.error("Error in getConfig:", error);
    });
}

function getSolverButton(captchaType, widgetId) {
    let button = $(`.captcha-solver[data-captcha-type="${captchaType}"][data-widget-id="${widgetId}"]`);
    if (button.length === 0) {
        console.warn(`Solver button not found for captchaType: ${captchaType}, widgetId: ${widgetId}`);
    }
    return button;
}

function getWidgetInfo(captchaType, widgetId) {
    if (!captchaType || !widgetId) {
        console.error("Invalid captchaType or widgetId in getWidgetInfo");
        return null;
    }

    let widget = $("head").find(`captcha-widget[data-captcha-type="${captchaType}"][data-widget-id="${widgetId}"]`);
    if (widget.length === 0) {
        console.warn(`Widget not found for captchaType: ${captchaType}, widgetId: ${widgetId}`);
        return null;
    }

    if (!widget[0] || !widget[0].dataset) {
        console.error("Widget or dataset is undefined");
        return null;
    }

    return prepareWidgetInfo(widget[0].dataset);
}

function prepareWidgetInfo(dataset) {
    if (!dataset) {
        console.error("Dataset is undefined in prepareWidgetInfo");
        return null;
    }
    
    let info = {};
    for (let key in dataset) {
        if (dataset.hasOwnProperty(key)) {
            info[key] = dataset[key];
            if (info[key] === "null") info[key] = null;
            if (info[key] === "false") info[key] = false;
            if (info[key] === "true") info[key] = true;
        }
    }
    return info;
}
function respondToWebPageMessage(result) {
    let message = $(`body > solver-ext-messages > solver-ext-message[data-message-id=${result.request.messageId}]`);
    if (message.length) {
        if (result.error) {
            setWebPageMessageResponse(message[0], { error: result.error });
        } else {
            setWebPageMessageResponse(message[0], { response: result.response });
        }
    }
}

function setWebPageMessageResponse(messageElement, response) {
    messageElement.dataset.response = encodeURIComponent(JSON.stringify(response));
}

CAPTCHA_WIDGETS_LOOP = setInterval(function() {
    getConfig().then(config => {
        if (config && config.isPluginEnabled && config.clientKey !== null && config.clientKey !== "") {
            $("head").find("captcha-widget").each(function() {
                let widget = $(this);
                let widgetInfo = prepareWidgetInfo(widget[0].dataset);
                if (widgetInfo.reset) {
                    let existingButton = getSolverButton(widgetInfo.captchaType, widgetInfo.widgetId);
                    if (existingButton.length > 0) {
                        existingButton.remove();
                    }
                    widget.remove();
                } else if (!widgetInfo.loaded) {
                    let processor = CaptchaProcessors.get(widgetInfo.captchaType);
                    if (processor && processor.canBeProcessed(widgetInfo, config)) {
                        let button = createSolverButton(widgetInfo.captchaType, widgetInfo.widgetId);
                        if (button && button.length > 0) {
                            processor.attachButton(widgetInfo, config, button);
                            widget[0].dataset.loaded = "true";
                        } else {
                            console.error("Failed to create solver button", widgetInfo);
                        }
                    }
                }
            });
        }
    });
}, 2000);
import {
    StatusCode
} from "./status_code.js";
class AchiCaptcha {
    constructor(t) {
        var e, a = {
            clientKey: "",
            service: "https://api.achicaptcha.com",
            defaultTimeout: 120,
            pollingInterval: 2
        };
        for (e in a) this[e] = (void 0 === t[e] ? a : t)[e];
        this.endpoints = {
            createTaskApi: this.service + "/createTask",
            getTaskResultApi: this.service + "/getTaskResult",
            checkClientKey: this.service + "/checkClientKey"
        }
    }
    async checkClientKey() {
        var e = {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            }
        };
        let t = {};
        t.clientKey = this.clientKey, t = JSON.stringify(t), e.body = t;
        let a;
        for (let t = 0; t < 10; t++) {
            try {
                (a = await (await fetch(this.endpoints.checkClientKey, e)).json()).errorId = parseInt(a.errorId);
                break
            } catch (t) {
                await new Promise(t => setTimeout(t, 1e3));
                continue
            }
            throw new Error("API_CONNECTION_ERROR")
        }
        if (0 !== a.errorId) throw new Error(a.errorDescription);
        return a
    }
    async toDataURL(t) {
        return fetch(t).then(t => t.blob()).then(i => new Promise((t, e) => {
            const a = new FileReader;
            a.onloadend = () => t(a.result), a.onerror = e, a.readAsDataURL(i)
        }))
    }
    async tiktok(t) {
        let e = [];
        for (const i of t.main.split("|")) {
            var a = await this.toDataURL(i);
            e.push(a)
        }
        t = {
            type: "TiktokCaptchaTask",
            image: e = e.join("|"),
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async xblast(t) {
        t = {
            type: "TiktokCaptchaTask",
            image: t.main,
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async geetest_captcha(t) {
        var e = t.main.split("|");
        let a = [];
        if (t.main.includes("base64")) a = t.main;
        else {
            for (const o of e) {
                var i = await this.toDataURL(o);
                a.push(i)
            }
            a = a.join("|")
        }
        let s;
        e = {
            type: s = t.isSlide ? "TiktokCaptchaTask" : "GeetestOneIcon",
            image: a,
            subType: t.subType
        };
        return (await this.solve(e, {
            timeout: 60
        })).solution
    }
    async geetest_icon(t) {
        var e = t.main.split("|");
        let a = [];
        if (t.main.includes("base64")) a = t.main;
        else {
            for (const s of e) {
                var i = await this.toDataURL(s);
                a.push(i)
            }
            a = a.join("|")
        }
        e = {
            type: "GeetestTask",
            image: a,
            subType: t.subType
        };
        return (await this.solve(e, {
            timeout: 60
        })).solution
    }
    async geetest_captcha_2(t) {
        var e = t.main.split("|");
        let a = [];
        if (t.main.includes("base64")) a = t.main;
        else {
            for (const o of e) {
                var i = await this.toDataURL(o);
                a.push(i)
            }
            a = a.join("|")
        }
        let s;
        t.isSlide ? (s = "TiktokCaptchaTask", "bingx" === t.site && (s = "SlideCaptchaTask")) : s = "GeetestOneIcon";
        e = {
            type: s,
            image: a,
            subType: t.subType
        };
        return (await this.solve(e, {
            timeout: 60
        })).solution
    }
    async yidun_captcha(t) {
        let e = [];
        for (const i of t.main.split("|")) {
            var a = await this.toDataURL(i);
            e.push(a)
        }
        t = {
            type: "SlideCaptchaTask",
            image: e = e.join("|"),
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async klook_captcha(t) {
        t = {
            type: "SlideCaptchaTask",
            image: t.main,
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async wave_captcha(t) {
        t = {
            type: "SlideCaptchaTask",
            image: t.main,
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async upsidedown(t) {
        t = {
            type: "UpsideDownCaptchaTask",
            image: t.main,
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async livechamp(t) {
        t = {
            type: "SliderTwoMark",
            image: t.main,
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async shopee(t) {
        t = {
            type: "ShopeeCaptchaTask",
            image: t.main,
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async bybit(t) {
        t = {
            type: "ByBitSlider",
            image: t.main,
            subType: t.subType
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async bybit_slider_v2(t) {
        let e = [];
        for (const i of t.main.split("|")) {
            var a = await this.toDataURL(i);
            e.push(a)
        }
        t = {
            type: "TiktokCaptchaTask",
            image: e = e.join("|"),
            subType: 1
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async mk_slider(t) {
        let e = [];
        for (const i of t.main.split("|")) {
            var a = await this.toDataURL(i);
            e.push(a)
        }
        t = {
            type: "TiktokCaptchaTask",
            image: e = e.join("|"),
            subType: 1
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async geetest_v3(t) {
        let e = [];
        for (const i of t.main.split("|")) {
            var a = await this.toDataURL(i);
            e.push(a)
        }
        t = {
            type: "SlideCaptchaTask",
            image: e = e.join("|"),
            subType: 1
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async vz684(t) {
        t = {
            type: "ImageToTextTask",
            image: t.main,
            subType: "11166"
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async funcaptcha(t) {
        t = {
            type: "FuncaptchaImageTask",
            image: t.main,
            subType: t.subType,
            other: t.other
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async temu_crawl(t) {
        t = {
            type: "ImageToTextTask",
            image: t.main,
            subType: "temu",
            other: t.other
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async shopee_text(t) {
        t = {
            type: "ImageToTextTask",
            image: t.main,
            subType: "shopee"
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async amazon_text(t) {
        t = await this.toDataURL(t.main);
        return (await this.solve({
            type: "ImageToTextTask",
            image: t,
            subType: "amazon"
        }, {
            timeout: 60
        })).solution
    }
    async apple_text(t) {
        t = await this.toDataURL(t.main);
        return (await this.solve({
            type: "ImageToTextTask",
            image: t,
            subType: "apple"
        }, {
            timeout: 60
        })).solution
    }
    async tele_text(t) {
        t = t.main;
        return (await this.solve({
            type: "ImageToTextTask",
            image: t,
            subType: "telegram"
        }, {
            timeout: 60
        })).solution
    }
    async google_text(t) {
        t = await this.toDataURL(t.main);
        return (await this.solve({
            type: "ImageToTextTask",
            image: t,
            subType: "google"
        }, {
            timeout: 60
        })).solution
    }
    async binance_geetest(t) {
        t = {
            type: "GeeTestTask",
            image: t.main,
            subType: t.subType,
            other: t.nGrid + "|" + t.typeObject
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async recaptcha_submit_token(t) {
        try {
            await fetch("http://localhost:8088/submitToken/" + t.token, {
                method: "GET"
            })
        } catch (t) {
            throw new Error("API_CONNECTION_ERROR")
        }
    }
    async recaptcha_image(t) {
        t = {
            type: "ReCaptchaImageTask",
            other: t.other
        };
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async HCaptchaImageTask(t) {
        return (await this.solve(t, {
            timeout: 60
        })).solution
    }
    async recaptcha(t) {
        t = {
            websiteURL: t.url,
            websiteKey: t.sitekey,
            type: "RecaptchaV2TaskProxyless"
        };
        return (await this.solve(t, {
            timeout: 120
        })).solution
    }
    async antibot(t) {
        var e, a = [],
            i = [];
        for (e in t) "main" !== e && (a.push(t[e]), i.push(e));
        var s = {
            type: "AntibotCaptchaTask",
            subType: "0",
            image: t.main + "|" + a.join("|")
        };
        let o = (await this.solve(s, {
            timeout: 60
        })).solution;
        o = o.split(",");
        for (let t = 0; t < o.length; t++) o[t] = i[parseInt(o[t])];
        return o.join(",")
    }
    async solve(t, e) {
        t = await this.createTask(t);
        return this.waitForResult(t, e)
    }
    async createTask(t) {
        var e = {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            }
        };
        let a = {};
        a.clientKey = this.clientKey, a.task = t, a = JSON.stringify(a), e.body = a;
        let i;
        for (let t = 0; t < 10; t++) {
            try {
                (i = await (await fetch(this.endpoints.createTaskApi, e)).json()).errorId = parseInt(i.errorId);
                break
            } catch (t) {
                await new Promise(t => setTimeout(t, 1e3));
                continue
            }
            throw new Error("API_CONNECTION_ERROR")
        }
        if (i.errorId !== StatusCode.SUCCESS.code) throw new Error(i.errorDescription);
        return i.taskId
    }
    async waitForResult(t, e) {
        e = e || {
            timeout: this.defaultTimeout,
            pollingInterval: this.pollingInterval
        };
        var a = this.getTime(),
            i = void 0 === e.timeout ? this.defaultTimeout : e.timeout;
        let s = (void 0 === e.pollingInterval ? this : e).pollingInterval;
        for (;;) {
            if (!(this.getTime() - a < i)) break;
            await new Promise(t => setTimeout(t, 1e3 * s));
            try {
                var o = await this.getTaskResult(t);
                if (o.errorId === StatusCode.SUCCESS.code) return o
            } catch (t) {
                throw t
            }
        }
        throw new Error("Timeout " + i + " seconds reached")
    }
    async getTaskResult(t) {
        var e = {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            }
        };
        let a = {};
        a.clientKey = this.clientKey, a.taskId = t, a = JSON.stringify(a), e.body = a;
        let i;
        for (let t = 0; t < 10; t++) {
            try {
                (i = await (await fetch(this.endpoints.getTaskResultApi, e)).json()).errorId = parseInt(i.errorId);
                break
            } catch (t) {
                await new Promise(t => setTimeout(t, 1e3));
                continue
            }
            throw new Error("API_CONNECTION_ERROR")
        }
        if (i.errorId !== StatusCode.SUCCESS.code && i.errorId !== StatusCode.PROCESSING.code) throw new Error(i.errorDescription);
        return i
    }
    getTime() {
        return parseInt(Date.now() / 1e3)
    }
}
export {
    AchiCaptcha
};
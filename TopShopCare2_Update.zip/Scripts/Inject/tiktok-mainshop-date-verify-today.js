                    (function() {
                        const inputs = Array.from(document.querySelectorAll('[data-tid="m4b_date_picker_range_picker"] input')).map(input => input.value);
                        const todayButton = document.querySelector('button[data-testid="time-selector-today"]');
                        const now = new Date();
                        const day = String(now.getDate()).padStart(2, '0');
                        const year = String(now.getFullYear());
                        return JSON.stringify({
                            currentUrl: location.href,
                            todayButtonFound: !!todayButton,
                            todayActive: !!todayButton && todayButton.className.indexOf('active') >= 0,
                            inputs: inputs,
                            inputsMatchToday: inputs.length >= 2
                                && inputs.every(value => value.indexOf(day) >= 0 && value.indexOf(year) >= 0)
                        });
                    })();

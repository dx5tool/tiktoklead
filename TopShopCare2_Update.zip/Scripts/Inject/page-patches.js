/**
 * Vá lỗi trang + probe hiệu năng cho trang Seller Shopee/TikTok (kiểu goseller):
 *   1. PROBE: đếm top callback requestAnimationFrame / setInterval theo "chữ ký" (fn.toString() rút gọn)
 *      + trạng thái ẩn/hiện của trang (document.hidden, số tick 1s) để biết Chromium có throttle khi shop bị ẩn không.
 *   2. GUARD (mặc định TẮT): chặn hẳn requestAnimationFrame theo danh sách chữ ký cấu hình —
 *      dùng để cắt vòng lặp rAF tự gọi lại (kiểu setupFixbugKenhNguoiBanLag của goseller).
 *   3. PATCH TikTok: bỏ beforeunload để trang không chặn reload/đóng (kiểu fixbugIssueGo107).
 *
 * Idempotent theo window.__tscPagePatchState: inject lại chỉ cập nhật cấu hình, không chồng hook.
 * AN TOÀN: probe chỉ chạy trong __PROBE_MS__ rồi TỰ KHÔI PHỤC requestAnimationFrame/setInterval gốc
 * (khi guard tắt), để không can thiệp lâu dài vào các trang khác của Shopee.
 * Placeholder: __PROBE_ENABLED__, __RAF_BLOCK_ENABLED__, __RAF_SIGNATURES__, __PATCH_TIKTOK__, __PROBE_MS__
 */
(function () {
    try {
        var PROBE = __PROBE_ENABLED__;
        var RAF_BLOCK = __RAF_BLOCK_ENABLED__;
        var SIGNATURES = __RAF_SIGNATURES__ || [];
        var PATCH_TIKTOK = __PATCH_TIKTOK__;
        var PROBE_MS = __PROBE_MS__;

        var MAX_TRACKED_SIGNATURES = 60;
        var SIGNATURE_LENGTH = 120;

        var state = window.__tscPagePatchState;
        if (!state) {
            state = window.__tscPagePatchState = {
                installedAt: Date.now(),
                rafCalls: {},
                intervalCreated: {},
                tickCount: 0,
                rafPatched: false,
                intervalPatched: false,
                tiktokPatched: false
            };
        }

        state.probeEnabled = !!PROBE;
        state.rafBlockEnabled = !!RAF_BLOCK;
        state.signatures = SIGNATURES;
        state.probeUntil = Date.now() + (PROBE_MS > 0 ? PROBE_MS : 30000);

        function signature(fn) {
            try {
                if (!fn) {
                    return 'none';
                }

                var text = Function.prototype.toString.call(fn).replace(/\s+/g, '');
                return text.length > SIGNATURE_LENGTH ? text.slice(0, SIGNATURE_LENGTH) : text;
            } catch (e) {
                return 'unknown';
            }
        }

        function bump(map, key) {
            if (!map[key] && Object.keys(map).length >= MAX_TRACKED_SIGNATURES) {
                return;
            }

            map[key] = (map[key] || 0) + 1;
        }

        function shouldBlock(sig) {
            if (!state.rafBlockEnabled || !state.signatures || !state.signatures.length) {
                return false;
            }

            for (var i = 0; i < state.signatures.length; i++) {
                var needle = state.signatures[i];
                if (needle && sig.indexOf(needle) >= 0) {
                    return true;
                }
            }

            return false;
        }

        // 1) Hook requestAnimationFrame (probe + guard).
        if (!state.rafPatched) {
            var originalRaf = window.requestAnimationFrame;
            state.originalRaf = originalRaf;
            if (typeof originalRaf === 'function') {
                window.requestAnimationFrame = function (callback) {
                    // Mọi việc ĐẾM bọc trong try/catch: lỗi đo lường không được ảnh hưởng trang.
                    if (state.probeEnabled && Date.now() < state.probeUntil) {
                        try {
                            bump(state.rafCalls, signature(callback));
                        } catch (e) { }
                    }

                    if (state.rafBlockEnabled && shouldBlock(signature(callback))) {
                        // Trả về id giả: vòng lặp tự gọi lại sẽ dừng vì callback không bao giờ chạy.
                        return 0;
                    }

                    return originalRaf.apply(window, arguments);
                };
                state.rafPatched = true;
            }
        }

        // 2) Hook setInterval chỉ để đếm (không chặn) — tìm vòng poll "nóng" của trang.
        if (!state.intervalPatched) {
            var originalSetInterval = window.setInterval;
            state.originalSetInterval = originalSetInterval;
            if (typeof originalSetInterval === 'function') {
                window.setInterval = function (fn, delay) {
                    if (state.probeEnabled && Date.now() < state.probeUntil) {
                        try {
                            bump(state.intervalCreated, signature(fn) + '@' + (delay | 0));
                        } catch (e) { }
                    }

                    return originalSetInterval.apply(window, arguments);
                };
                state.intervalPatched = true;
            }
        }

        // 2b) Hết cửa sổ đo và KHÔNG bật guard ⇒ khôi phục hàm gốc để trang về trạng thái nguyên bản
        //     (tránh mọi can thiệp lâu dài vào các trang khác của Shopee).
        if (state.probeEnabled && !state.rafBlockEnabled && !state.restoreTimer) {
            state.restoreTimer = setTimeout(function () {
                try {
                    if (state.originalRaf) {
                        window.requestAnimationFrame = state.originalRaf;
                    }

                    if (state.originalSetInterval) {
                        window.setInterval = state.originalSetInterval;
                    }

                    if (state.tickTimer) {
                        clearInterval(state.tickTimer);
                        state.tickTimer = null;
                    }

                    state.rafPatched = false;
                    state.intervalPatched = false;
                    state.probeEnabled = false;
                    state.restoredAt = Date.now();
                } catch (e) { }
            }, state.probeUntil - Date.now());
        }

        // 3) Tick 1 giây để đo mức độ bị throttle khi shop bị ẩn.
        if (state.probeEnabled && !state.tickTimer) {
            state.tickTimer = setInterval(function () {
                state.tickCount++;
                state.lastTickAt = Date.now();
            }, 1000);
        }

        // 4) Patch beforeunload cho TikTok (không cho trang chặn reload/đóng).
        if (PATCH_TIKTOK && !state.tiktokPatched && /seller-vn\.tiktok\.com$/i.test(location.host)) {
            try {
                var originalAdd = EventTarget.prototype.addEventListener;
                EventTarget.prototype.addEventListener = function (type, fn, opts) {
                    if (String(type).toLowerCase() === 'beforeunload') {
                        return;
                    }

                    return originalAdd.call(this, type, fn, opts);
                };

                Object.defineProperty(window, 'onbeforeunload', {
                    set: function () { },
                    get: function () { return null; },
                    configurable: false
                });

                state.tiktokPatched = true;
            } catch (e) { }
        }

        // 5) API đọc kết quả cho C#.
        window.__tscPagePatchReport = function () {
            var top = function (map) {
                return Object.keys(map).map(function (key) {
                    return { signature: key, count: map[key] };
                }).sort(function (a, b) {
                    return b.count - a.count;
                }).slice(0, 10);
            };

            return JSON.stringify({
                href: location.href,
                hidden: document.hidden,
                visibilityState: document.visibilityState,
                uptimeMs: Date.now() - state.installedAt,
                tickCount: state.tickCount,
                rafPatched: !!state.rafPatched,
                rafBlockEnabled: !!state.rafBlockEnabled,
                tiktokPatched: !!state.tiktokPatched,
                rafTop: top(state.rafCalls),
                intervalTop: top(state.intervalCreated)
            });
        };
    } catch (e) {
        // Vá lỗi/probe không được ảnh hưởng trang.
    }
})();

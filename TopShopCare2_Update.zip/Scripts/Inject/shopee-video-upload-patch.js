// Patch trang tải video lên của Shopee Seller Centre (creator-center/video-upload/upload).
// Nhiệm vụ: ghi lại taskId (từ /task/create), mmsVid (id video mms), ảnh bìa (từ /image/notify),
// cờ upload xong (từ /task/report step=uploadFile) và lỗi HTTP của quá trình upload lên mms,
// để C# đọc qua window.__tscVideoUploadState(). Không thay đổi hành vi của trang.
(function () {
    'use strict';
    if (window.__tscVideoUploadState) {
        return;
    }

    var state = {
        taskId: '',
        mmsVid: '',
        cover: '',
        uploadDone: false,
        uploadError: '',
        taskCreateStatus: 0,
        lastStatus: 0,
        updatedAt: 0
    };

    var MMS_RE = /mms\.shopee\.(vn|com)/i;
    var VID_RE = /"(?:vid|mmsVid|id)"\s*:\s*"([a-z]{2}-\d{8}-[a-z0-9]{2,12}-[a-z0-9]{6,32})"/i;
    var TASK_ID_RE = /"taskId"\s*:\s*"([^"]+)"/i;
    var TASK_CREATE_RE = /publish\/pc\/api\/task\/create/i;
    var TASK_REPORT_RE = /publish\/pc\/api\/task\/report/i;
    var IMAGE_NOTIFY_RE = /image\/notify/i;

    function isWatchedUrl(url) {
        return MMS_RE.test(url) || TASK_CREATE_RE.test(url) || TASK_REPORT_RE.test(url) || IMAGE_NOTIFY_RE.test(url);
    }

    function scanVid(text) {
        if (!text || state.mmsVid) {
            return;
        }
        var match = VID_RE.exec(text);
        if (match) {
            state.mmsVid = match[1];
        }
    }

    function scanTaskId(text) {
        if (!text || state.taskId) {
            return;
        }
        var match = TASK_ID_RE.exec(text);
        if (match) {
            state.taskId = match[1];
        }
    }

    function handleResponse(url, status, body) {
        state.lastStatus = status;
        try {
            if (TASK_CREATE_RE.test(url)) {
                state.taskCreateStatus = status;
                if (status >= 400) {
                    state.uploadError = state.uploadError || ('task/create HTTP ' + status);
                } else {
                    scanTaskId(body);
                }
            } else if (TASK_REPORT_RE.test(url)) {
                if (status < 400 && body && body.indexOf('uploadFile') >= 0) {
                    state.uploadDone = true;
                }
            } else if (IMAGE_NOTIFY_RE.test(url)) {
                if (status < 400 && body) {
                    var notify = JSON.parse(body);
                    if (notify && notify.url) {
                        state.cover = String(notify.url);
                    }
                }
            } else if (MMS_RE.test(url)) {
                if (status >= 400) {
                    state.uploadError = state.uploadError || ('Upload HTTP ' + status);
                }
            }
        } catch (e) {
            // JSON không đọc được: bỏ qua, chỉ quan tâm cờ/định danh.
        }

        scanVid(body);
        // taskId có thể nằm ở response khác task/create (task/detail khi chạy lại) — scan bổ sung.
        scanTaskId(body);
        state.updatedAt = Date.now();
    }

    // ── Patch fetch ──
    var originalFetch = window.fetch;
    if (originalFetch) {
        window.fetch = function () {
            var args = arguments;
            var url = typeof args[0] === 'string' ? args[0] : (args[0] && args[0].url) || '';
            url = String(url);
            if (!isWatchedUrl(url)) {
                return originalFetch.apply(this, args);
            }

            return originalFetch.apply(this, args).then(function (response) {
                try {
                    var clone = response.clone();
                    clone.text().then(function (body) {
                        handleResponse(url, response.status, body);
                    }).catch(function () { });
                } catch (e) { }
                return response;
            }, function (error) {
                if (MMS_RE.test(url)) {
                    state.uploadError = state.uploadError || ('Lỗi mạng khi upload: ' + ((error && error.message) || 'unknown'));
                }
                throw error;
            });
        };
    }

    // ── Patch XMLHttpRequest (Shopee dùng axios/XHR ở một số bước) ──
    var originalOpen = XMLHttpRequest.prototype.open;
    var originalSend = XMLHttpRequest.prototype.send;
    XMLHttpRequest.prototype.open = function (method, url) {
        this.__tscUrl = String(url || '');
        return originalOpen.apply(this, arguments);
    };
    XMLHttpRequest.prototype.send = function () {
        var xhr = this;
        if (!xhr.__tscHooked) {
            xhr.__tscHooked = true;
            xhr.addEventListener('load', function () {
                try {
                    var url = xhr.__tscUrl || '';
                    if (isWatchedUrl(url)) {
                        handleResponse(url, xhr.status, xhr.responseText || '');
                    }
                } catch (e) { }
            });
        }
        return originalSend.apply(this, arguments);
    };

    window.__tscVideoUploadState = function () {
        return JSON.stringify(state);
    };
})();

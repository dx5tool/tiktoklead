                    (function() {
                        const productDataJson = __PRODUCT_DATA_JSON__;
                        let productsData = {};
                        let itemsCountOnPage = 0;
                        let totalProductCount = 0;

                        try {
                             // ✅ BỔ SUNG: Parse payload thay vì mảng trực tiếp
                            const payload = JSON.parse(productDataJson);
                            const parsedProducts = payload.products || [];
                            totalProductCount = payload.totalCount || 0;

                            // Đếm số sản phẩm trong dữ liệu nhận được
                            itemsCountOnPage = parsedProducts.filter(p => p.itemId).length;

                            // Chuẩn bị dữ liệu cho từng sản phẩm như cũ
                            parsedProducts.forEach(p => {
                                productsData[p.itemId] = p;
                            });
                        } catch (e) {
                            console.error('Lỗi parse JSON dữ liệu sản phẩm:', e);
                            return false;
                        }

                        // ✅ BỔ SUNG: Chèn thanh thông tin tổng hợp
                        const sortBar = document.querySelector('fieldset.shopee-sort-bar');
                        if (sortBar) {
                            // Xóa thanh cũ nếu có để cập nhật
                            const oldSummaryBar = document.getElementById('topshopee_summary_bar');
                            if (oldSummaryBar) {
                                oldSummaryBar.remove();
                            }

                            const summaryHtml = `
                                <div id="topshopee_summary_bar" style="background: #1B5E20; color: white; padding: 8px 15px; font-size: 14px; font-weight: 500; text-align: center; margin-bottom: 10px; border-radius: 3px;">
                                    List: ${itemsCountOnPage} sản phẩm - Trong Tổng số: ${totalProductCount.toLocaleString('vi-VN')} sản phẩm của Shop.
                                </div>
                            `;
                            // Chèn thanh mới vào trước thanh sort
                            sortBar.insertAdjacentHTML('beforebegin', summaryHtml);
                        }


                        const productItems = document.querySelectorAll('.shop-search-result-view__item');
                        if (productItems.length === 0) {
                            console.log('Không tìm thấy sản phẩm nào trên trang tìm kiếm.');
                            return false; 
                        }

                        let injectedCount = 0;
                        productItems.forEach(item => {
                            if (item.querySelector('#topshopee_product_shop')) {
                                return;
                            }
                            
                            const contentContainer = item.querySelector('a > div > .p-2');
                            if (!contentContainer) { return; }

                            const href = item.querySelector('a')?.getAttribute('href');
                            if (!href) return;

                            const match = href.match(/-i\.(\d+)\.(\d+)/);
                            if (!match) { return; }
                            
                            const shopId = match[1];
                            const itemId = match[2];

                            const data = productsData[itemId];
                            if (!data) { return; }

                            const formatNumber = (num) => (num || 0).toLocaleString('vi-VN');
                            
                            const brandHtml = data.isNoBrand ? `<span style="color: rgb(34, 34, 34); font-size: 14px;">${data.brandName}</span>` : `<span style="color: rgb(255, 102, 0); font-size: 14px;">${data.brandName}</span>`;
                            const htmlToInject = `
                            <div id="topshopee_product_shop" style="padding: 12px; font-size: 14px; background: rgb(255, 255, 255); border-radius: 4px; box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 4px; margin-top: 4px;">
                                <div style="font-size: 12px; line-height: 1.6;">
                                    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 2px; font-weight: 600;">
                                        <span style="font-weight: 600; color: rgb(34, 34, 34); font-size: 13px;">
                                            <span>${data.date}</span>
                                            <span style="color: rgb(136, 136, 136); font-size: 12px; margin-left: 4px;"> - ${data.age}</span>
                                        </span>
                                    </div>
                                    <div style="border-bottom: 1px solid rgb(224, 224, 224); margin: 4px 0px;"></div>
                                    <div style="display: flex; justify-content: space-between;"><span style="color: rgb(136, 136, 136); font-size: 12px;">Bán trong tháng</span><span style="color: rgb(0, 153, 0); font-weight: 700; font-size: 14px;">${formatNumber(data.monthlySold)} </span></div>
                                    <div style="display: flex; justify-content: space-between;"><span style="color: rgb(136, 136, 136); font-size: 12px;">Doanh số</span><span style="color: rgb(0, 153, 0); font-weight: 700; font-size: 14px;">${formatNumber(data.monthlyRevenue)} </span></div>
                                    <div style="border-bottom: 1px solid rgb(224, 224, 224); margin: 4px 0px;"></div>
                                    <div style="display: flex; justify-content: space-between;"><span style="color: rgb(136, 136, 136); font-size: 12px;">Bán tổng</span><span style="color: rgb(0, 153, 0); font-weight: 700; font-size: 14px;">${formatNumber(data.totalSold)} </span></div>
                                    <div style="display: flex; justify-content: space-between;"><span style="color: rgb(136, 136, 136); font-size: 12px;">Doanh số</span><span style="color: rgb(0, 153, 0); font-weight: 700; font-size: 14px;">${formatNumber(data.totalRevenue)} </span></div>
                                    <div style="border-bottom: 1px solid rgb(224, 224, 224); margin: 4px 0px;"></div>
                                    <div style="display: flex; justify-content: space-between; margin-top: 2px;">${brandHtml}</div>
                                </div>
                            </div>`;

                            contentContainer.insertAdjacentHTML('beforeend', htmlToInject);
                            injectedCount++;
                        });
                        
                        console.log(`✅ Đã chèn dữ liệu cho ${injectedCount} / ${productItems.length} sản phẩm.`);
                        return injectedCount > 0;
                    })();

            (function(){
                var boundShopDbId = '__BOUND_SHOP_DB_ID__';
                var observerKey = '__topshopeeShopAnalysisObserver';
                var lastPathKey = '__topshopeeShopAnalysisLastPath';

                function getPageMode() {
                    if (!location.hostname.includes('banhang.shopee.vn')) return 'none';
                    var path = (location.pathname || '/').replace(/\/+$/, '') || '/';
                    if (path === '/') return 'home';
                    if (path.indexOf('/datacenter/overview') === 0) return 'overview';
                    if (path.indexOf('/portal/marketing/pas/index') === 0) return 'ads';
                    return 'none';
                }

                function wireAdsManageButton(btnAds) {
                    btnAds.id = 'topshopee-btn-manage-ads';
                    btnAds.textContent = 'Quản lý Phân tích Ads';
                    btnAds.style.cssText = 'background-color: #0066cc; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-weight: bold; font-size:12px;';
                    btnAds.onmouseenter = function(){ this.style.backgroundColor = '#0052a3'; };
                    btnAds.onmouseleave = function(){ this.style.backgroundColor = '#0066cc'; };
                    btnAds.onclick = function(ev){
                        if (ev) { ev.preventDefault(); ev.stopPropagation(); }
                        if (typeof openAdsManager === 'function') {
                            openAdsManager(boundShopDbId);
                        } else {
                            console.warn('openAdsManager is not defined');
                        }
                    };
                }

                function wireShopOverviewButton(btn) {
                    btn.id = 'topshopee-btn-shop-overview';
                    btn.textContent = 'PT Tổng Quan';
                    btn.style.cssText = 'background-color: #7c3aed; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-weight: bold; font-size:12px;';
                    btn.onmouseenter = function(){ this.style.backgroundColor = '#6d28d9'; };
                    btn.onmouseleave = function(){ this.style.backgroundColor = '#7c3aed'; };
                    btn.onclick = function(ev){
                        if (ev) { ev.preventDefault(); ev.stopPropagation(); }
                        if (typeof openShopOverview === 'function') {
                            openShopOverview(boundShopDbId);
                        } else {
                            console.warn('openShopOverview is not defined');
                        }
                    };
                }

                function createShopOverviewButton() {
                    var btn = document.createElement('button');
                    wireShopOverviewButton(btn);
                    return btn;
                }

                function createPtShopButtons(container) {
                    var configs = [
                        { text: 'PT Shop (Hôm nay)', period: 'real_time' },
                        { text: 'PT Shop (Hôm qua)', period: 'yesterday' },
                        { text: 'PT Shop 7D', period: 'past7days' },
                        { text: 'PT Shop 30D', period: 'past30days' }
                    ];
                    configs.forEach(function(cfg){
                        var btn = document.createElement('button');
                        btn.textContent = cfg.text;
                        btn.style.cssText = 'background-color: #cc0000; color: white; border: none; padding: 6px 12px; border-radius: 4px; cursor: pointer; font-weight: bold; font-size:12px;';
                        btn.addEventListener('mouseenter', function(){ this.style.backgroundColor = '#b30000'; });
                        btn.addEventListener('mouseleave', function(){ this.style.backgroundColor = '#cc0000'; });
                        btn.addEventListener('click', function(){
                            if (typeof analyzeShop === 'function') {
                                analyzeShop(cfg.period);
                            } else {
                                console.warn('analyzeShop is not defined');
                            }
                        });
                        container.appendChild(btn);
                    });
                }

                function renameLegacyPtButtons(container) {
                    Array.from(container.querySelectorAll('button')).forEach(function(btn){
                        var text = (btn.textContent || '').replace(/\s+/g, ' ').trim();
                        if (text === 'PT Shop (7 ngày)') btn.textContent = 'PT Shop 7D';
                        else if (text === 'PT Shop (30 ngày)') btn.textContent = 'PT Shop 30D';
                    });
                }

                function removeContainer() {
                    var existing = document.getElementById('shop_analysis_container');
                    if (existing && existing.parentNode) {
                        existing.parentNode.removeChild(existing);
                    }
                }

                function buildContainer(mode) {
                    var container = document.createElement('div');
                    container.id = 'shop_analysis_container';
                    container.dataset.mode = mode;

                    if (mode === 'home' || mode === 'overview') {
                        createPtShopButtons(container);
                        container.appendChild(createShopOverviewButton());
                    }
                    if (mode === 'home' || mode === 'ads') {
                        var btnAds = document.createElement('button');
                        wireAdsManageButton(btnAds);
                        container.appendChild(btnAds);
                    }
                    return container;
                }

                function insertContainer(container) {
                    var breadcrumb = document.querySelector('div.breadcrumb.eds-breadcrumb.eds-breadcrumb--light');
                    if (breadcrumb) {
                        var items = breadcrumb.querySelectorAll('div.breadcrumb-item.eds-breadcrumb-item');
                        var ref = items.length ? items[items.length - 1] : breadcrumb;
                        container.style.cssText = 'display:flex; gap:6px; margin-left:12px; align-items:center;';
                        ref.insertAdjacentElement('afterend', container);
                        return true;
                    }

                    var span = document.querySelector('span.breadcrumb-text');
                    if (!span) return false;
                    var blank = span.nextElementSibling;
                    if (blank && blank.classList.contains('blank-block')) {
                        blank.style.display = 'none';
                    }
                    container.style.cssText = 'display:inline-flex; gap:6px; margin-left:8px; align-items:center;';
                    span.appendChild(container);
                    return true;
                }

                function rewireExisting(container, mode) {
                    renameLegacyPtButtons(container);
                    Array.from(container.querySelectorAll('button')).forEach(function(btn){
                        var text = (btn.textContent || '').replace(/\s+/g, ' ').trim();
                        if (/Tổng Quan/i.test(text) || btn.id === 'topshopee-btn-shop-overview') {
                            wireShopOverviewButton(btn);
                        } else if (/Ads/i.test(text) || btn.id === 'topshopee-btn-manage-ads') {
                            wireAdsManageButton(btn);
                        }
                    });
                    container.dataset.mode = mode;
                }

                function syncButtons() {
                    var mode = getPageMode();
                    var existing = document.getElementById('shop_analysis_container');

                    if (mode === 'none') {
                        removeContainer();
                        return;
                    }

                    if (existing) {
                        if (existing.dataset.mode === mode) {
                            rewireExisting(existing, mode);
                            return;
                        }
                        removeContainer();
                    }

                    var container = buildContainer(mode);
                    if (!insertContainer(container)) {
                        if (container.parentNode) container.parentNode.removeChild(container);
                    }
                }

                syncButtons();

                if (!window[observerKey]) {
                    var pending = false;
                    window[observerKey] = new MutationObserver(function() {
                        if (pending) return;
                        pending = true;
                        setTimeout(function() {
                            pending = false;
                            var path = location.pathname || '/';
                            if (window[lastPathKey] !== path) {
                                window[lastPathKey] = path;
                            }
                            syncButtons();
                        }, 250);
                    });
                    window[observerKey].observe(document.body, { childList: true, subtree: true });
                    window[lastPathKey] = location.pathname || '/';
                }
            })();

                    try {
                        if (window._elementObserver) {
                            if (window._elementObserver.observer) {
                                window._elementObserver.observer.disconnect();
                            }
                            window._elementObserver = null;
                        }
                        if (window.dotNetCallback) {
                            window.dotNetCallback = null;
                        }
                        console.log('Cleanup completed');
                    } catch(e) {
                        console.error('Cleanup error:', e);
                    }

                    (function() {
                        console.log('🔧 Bắt đầu inject chi tiết sản phẩm...');
    
                        // ─────────────────────────────────────────────────────────
                        // 1. TÌM ELEMENT ĐÍCH VÀ INJECT HTML
                        // ─────────────────────────────────────────────────────────
                        var target = document.querySelector('div.flex.flex-column.IFdRIb');
                        if (!target) {
                            console.error('❌ Không tìm thấy element đích để inject');
                            return false;
                        }

                        // Inject HTML vào DOM (chèn sau element đích)
                        target.insertAdjacentHTML('afterend', __HTML_SNIPPET__);
                        console.log('✅ HTML đã được inject thành công');

                        // Lấy container vừa inject
                        var container = document.querySelector('div.custom-shopee-data');
                        if (!container) {
                            console.error('❌ Không tìm thấy container sau khi inject');
                            return false;
                        }

                        // ─────────────────────────────────────────────────────────
                        // 2. THÊM CSS CHO ICON SORT ACTIVE (MÀU CAM)
                        // ─────────────────────────────────────────────────────────
                        var style = document.createElement('style');
                        style.innerHTML = `
                            .custom-shopee-data .sort-asc.active,
                            .custom-shopee-data .sort-desc.active {
                                color: orange !important;
                            }
                        `;
                        container.appendChild(style);

                        // ─────────────────────────────────────────────────────────
                        // 3. LẤY CÁC ELEMENT CẦN THIẾT CHO VIỆC SẮP XẾP
                        // ─────────────────────────────────────────────────────────
                        var table = container.querySelector('table');
                        var tbody = table.querySelector('tbody');
                        var headers = table.querySelectorAll('th');

                        // ─────────────────────────────────────────────────────────
                        // 4. HÀM SẮP XẾP BẢNG THEO CỘT
                        // ─────────────────────────────────────────────────────────
                        /**
                         * Hàm sắp xếp cột
                         * @param {number} colIndex - Index của cột cần sắp xếp (0-4)
                         * @param {boolean} asc - true: tăng dần, false: giảm dần
                         * @param {Element} clickedEl - Element icon được click
                         */
                        function sortByColumn(colIndex, asc, clickedEl) {
                            // 4.1) Xóa trạng thái active của tất cả icon
                            table.querySelectorAll('.sort-asc, .sort-desc').forEach(function(ic) {
                                ic.classList.remove('active');
                            });
        
                            // 4.2) Đánh dấu icon hiện tại là active (màu cam)
                            clickedEl.classList.add('active');

                            // 4.3) Lấy tất cả rows trừ dòng tổng kết (summary-row)
                            var allRows = Array.from(tbody.querySelectorAll('tr'));
                            var summaryRow = tbody.querySelector('.summary-row');
                            var dataRows = allRows.filter(function(row) { 
                                return !row.classList.contains('summary-row'); 
                            });
        
                            // 4.4) Thực hiện sắp xếp các dòng dữ liệu
                            dataRows.sort(function(r1, r2) {
                                var a = r1.cells[colIndex].innerText.trim();
                                var b = r2.cells[colIndex].innerText.trim();
            
                                // Thử parse thành số (loại bỏ ký tự đặc biệt như %, dấu phẩy)
                                var na = parseFloat(a.replace(/[^0-9.-]/g, ''));
                                var nb = parseFloat(b.replace(/[^0-9.-]/g, ''));
            
                                // Nếu cả hai đều là số → so sánh số
                                // Ngược lại → so sánh chuỗi
                                if (!isNaN(na) && !isNaN(nb)) {
                                    return asc ? na - nb : nb - na;
                                }
                                return asc ? a.localeCompare(b) : b.localeCompare(a);
                            });
        
                            // 4.5) Xóa tất cả rows trong tbody
                            tbody.innerHTML = '';
        
                            // 4.6) Thêm lại các dòng đã sắp xếp
                            dataRows.forEach(function(r) { 
                                tbody.appendChild(r); 
                            });
        
                            // 4.7) Thêm lại dòng tổng kết ở cuối cùng
                            if (summaryRow) {
                                tbody.appendChild(summaryRow);
                            }
        
                            console.log('✅ Đã sắp xếp cột ' + colIndex + ' ' + (asc ? 'tăng dần' : 'giảm dần'));
                        }

                        // ─────────────────────────────────────────────────────────
                        // 5. GẮN EVENT LISTENER CHO CÁC ICON SORT
                        // ─────────────────────────────────────────────────────────
                        headers.forEach(function(th, idx) {
                            var ascEl = th.querySelector('.sort-asc');   // Icon ⇧
                            var descEl = th.querySelector('.sort-desc');  // Icon ⇩
        
                            // Gắn sự kiện click cho icon tăng dần
                            if (ascEl) {
                                ascEl.addEventListener('click', function() { 
                                    sortByColumn(idx, true, this); 
                                });
                            }
        
                            // Gắn sự kiện click cho icon giảm dần
                            if (descEl) {
                                descEl.addEventListener('click', function() { 
                                    sortByColumn(idx, false, this); 
                                });
                            }
                        });

                        // ─────────────────────────────────────────────────────────
                        // 6. SẮP XẾP MẶC ĐỊNH: TỶ LỆ BÁN (CỘT 3) GIẢM DẦN
                        // ─────────────────────────────────────────────────────────
                        var defaultSortColumn = 3;  // Index cột 'Tỷ lệ bán' (0=SKU, 1=Giá, 2=Đã bán, 3=Tỷ lệ bán, 4=Tồn kho)
                        var defaultSortDesc = headers[defaultSortColumn].querySelector('.sort-desc');
    
                        if (defaultSortDesc) {
                            // Trigger sắp xếp giảm dần cho cột 'Tỷ lệ bán'
                            sortByColumn(defaultSortColumn, false, defaultSortDesc);
                            console.log('✅ Đã áp dụng sắp xếp mặc định: Tỷ lệ bán (giảm dần)');
                        }

                        // ─────────────────────────────────────────────────────────
                        // 7. ĐÁNH DÁU ĐÃ KHỞI TẠO XONG
                        // ─────────────────────────────────────────────────────────
                        container.classList.add('sortable-initialized');
                        console.log('✅ Chức năng sắp xếp đã được thiết lập hoàn tất');
                        return true;
                    })();

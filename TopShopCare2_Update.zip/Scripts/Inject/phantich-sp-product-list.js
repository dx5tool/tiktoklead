(function () {
    var boundShopDbId = '__BOUND_SHOP_DB_ID__';
    var observerKey = '__topshopeeProductListButtonsObserver';
    var containerClass = 'control-buttons-container';
    var containerMarker = 'data-topshopee-product-controls';

    function normalizeText(value) {
        return (value || '').replace(/\s+/g, ' ').trim();
    }

    function isProductListPage() {
        return location.hostname.indexOf('banhang.shopee.vn') >= 0
            && (location.pathname || '').indexOf('/portal/product/list/') === 0;
    }

    function getProductId(item) {
        var idElement = item.querySelector('.item-id');
        if (!idElement) {
            return '';
        }

        var match = normalizeText(idElement.textContent || idElement.innerText).match(/ID Sản phẩm:\s*(\d+)/);
        return match ? match[1] : '';
    }

    function getProductTitle(item) {
        var nameElement = item.querySelector('.product-name-wrap');
        return nameElement ? normalizeText(nameElement.textContent || nameElement.innerText) : '';
    }

    function createButton(config) {
        var button = document.createElement('button');
        button.type = 'button';
        button.textContent = config.text;
        button.style.cssText = [
            'background-color:' + config.bg,
            'color:#fff',
            'border:none',
            'padding:8px 16px',
            'border-radius:4px',
            'cursor:pointer',
            'font-weight:bold',
            'font-size:12px',
            'line-height:1.2',
            'transition:background-color 0.3s'
        ].join(';');
        button.addEventListener('mouseenter', function () { this.style.backgroundColor = config.hover; });
        button.addEventListener('mouseleave', function () { this.style.backgroundColor = config.bg; });
        button.addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            config.click();
        });
        return button;
    }

    function createControlContainer(productId, productTitle) {
        var container = document.createElement('div');
        container.className = containerClass;
        container.setAttribute(containerMarker, '1');
        if (productId) {
            container.setAttribute('data-topshopee-product-id', productId);
        }
        container.style.cssText = [
            'display:flex',
            'gap:8px',
            'margin-bottom:8px',
            'padding:8px',
            'background-color:#f5f5f5',
            'border-radius:5px'
        ].join(';');

        container.appendChild(createButton({
            text: 'Hiệu suất Bán hàng',
            bg: '#ff6600',
            hover: '#e55a00',
            click: function () {
                if (typeof analyzeProduct === 'function') {
                    analyzeProduct(productId, productTitle, boundShopDbId);
                } else {
                    console.warn('analyzeProduct is not defined');
                }
            }
        }));

        container.appendChild(createButton({
            text: 'Quản lý Đẩy',
            bg: '#059669',
            hover: '#047857',
            click: function () {
                if (typeof openDaySanPham === 'function') {
                    openDaySanPham(boundShopDbId);
                } else {
                    console.warn('openDaySanPham is not defined');
                }
            }
        }));

        return container;
    }

    function isProductVariationItem(element) {
        return !!element
            && typeof element.className === 'string'
            && element.className.indexOf('product-variation-item') >= 0;
    }

    function removeOrphanContainers() {
        var containers = document.querySelectorAll('div.' + containerClass + '[' + containerMarker + ']');
        for (var i = 0; i < containers.length; i++) {
            var container = containers[i];
            var next = container.nextElementSibling;
            if (!isProductVariationItem(next)) {
                if (container.parentNode) {
                    container.parentNode.removeChild(container);
                }
            }
        }
    }

    function injectButtons() {
        if (!isProductListPage()) {
            return;
        }

        removeOrphanContainers();

        var items = document.querySelectorAll('div[class*="product-variation-item"]');
        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            var productId = getProductId(item);
            var previous = item.previousElementSibling;
            if (previous
                && previous.classList
                && previous.classList.contains(containerClass)
                && previous.hasAttribute(containerMarker)) {
                if ((previous.getAttribute('data-topshopee-product-id') || '') === productId) {
                    continue;
                }

                previous.parentNode.removeChild(previous);
            }

            var container = createControlContainer(productId, getProductTitle(item));
            item.parentNode.insertBefore(container, item);
        }
    }

    injectButtons();

    if (!window[observerKey]) {
        var pending = false;
        window[observerKey] = new MutationObserver(function () {
            if (pending) return;
            pending = true;
            setTimeout(function () {
                pending = false;
                injectButtons();
            }, 300);
        });
        window[observerKey].observe(document.body, { childList: true, subtree: true });
    }
})();

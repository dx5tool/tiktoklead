            (function(){
                var boundShopDbId = '__BOUND_SHOP_DB_ID__';
                // Tìm tất cả các phần tử product-variation-item
                var productItems = document.querySelectorAll('div[class="product-variation-item"]');
        
                productItems.forEach(function(item, index) {
                    // Kiểm tra xem đã có nút điều khiển chưa
                    var existingControls = item.previousElementSibling;
                    if (existingControls && existingControls.classList.contains('control-buttons-container')) {
                        return; // Đã có rồi, bỏ qua
                    }
            
                    // Lấy ID sản phẩm từ phần tử
                    var productIdElement = item.querySelector('.item-id');
                    var productId = '';
                    if (productIdElement) {
                        var idText = productIdElement.textContent || productIdElement.innerText;
                        var match = idText.match(/ID Sản phẩm:\s*(\d+)/);
                        if (match) {
                            productId = match[1];
                        }
                    }
                    // Lấy tiêu đề sản phẩm
                    var productNameElement = item.querySelector('.product-name-wrap');
                    var productTitle = '';
                    if (productNameElement) {
                        productTitle = productNameElement.textContent || productNameElement.innerText;
                        productTitle = productTitle.trim();
                    }
                    // Tạo container cho các nút điều khiển
                    var controlContainer = document.createElement('div');
                    controlContainer.className = 'control-buttons-container';
                    controlContainer.style.cssText = `
                        display: flex;
                        gap: 8px;
                        margin-bottom: 8px;
                        padding: 8px;
                        background-color: #f5f5f5;
                        border-radius: 5px;
                    `;
            
                    // Tạo nút điều khiển
                    var buttons = [
                        {
                            text: 'Hiệu suất Bán hàng',
                            bg: '#ff6600',
                            hover: '#e55a00',
                            click: function() { analyzeProduct(productId, productTitle); }
                        },
                        {
                            text: 'Quản lý Đẩy',
                            bg: '#059669',
                            hover: '#047857',
                            click: function() {
                                if (typeof openDaySanPham === 'function') {
                                    openDaySanPham(boundShopDbId);
                                }
                            }
                        }
                    ];
                    buttons.forEach(function(cfg, btnIndex) {
                        var button = document.createElement('button');
                        button.textContent = cfg.text;
                        button.id = 'btn_' + (btnIndex + 1) + '_product_' + (productId || index);
                        button.style.cssText = `
                            background-color: ${cfg.bg};
                            color: white;
                            border: none;
                            padding: 8px 16px;
                            border-radius: 4px;
                            cursor: pointer;
                            font-weight: bold;
                            font-size: 12px;
                            transition: background-color 0.3s;
                        `;

                        button.addEventListener('mouseenter', function() {
                            this.style.backgroundColor = cfg.hover;
                        });
                        button.addEventListener('mouseleave', function() {
                            this.style.backgroundColor = cfg.bg;
                        });
                        button.addEventListener('click', cfg.click);

                        controlContainer.appendChild(button);
                    });
            
                    // Chèn container nút điều khiển ngay phía trên product-variation-item
                    item.parentNode.insertBefore(controlContainer, item);
                });
            })();

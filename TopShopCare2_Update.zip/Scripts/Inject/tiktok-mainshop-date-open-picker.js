                    (function() {
                        const picker = document.querySelector('[data-tid="m4b_date_picker_range_picker"]');
                        const input = picker && picker.querySelector('input[placeholder="Ngày bắt đầu"], input');
                        if (!picker || !input) {
                            return JSON.stringify({ opened: false, reason: 'picker_input_not_found' });
                        }

                        const clickElement = (element) => {
                            element.scrollIntoView({ block: 'center', inline: 'center' });
                            element.focus && element.focus();
                            element.click && element.click();
                            for (const type of ['pointerdown', 'mousedown', 'mouseup', 'click']) {
                                element.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
                            }
                        };

                        clickElement(input);
                        return JSON.stringify({
                            opened: true,
                            inputs: Array.from(picker.querySelectorAll('input')).map(inputElement => inputElement.value)
                        });
                    })();

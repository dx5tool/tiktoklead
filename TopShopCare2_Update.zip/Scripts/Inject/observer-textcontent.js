                (function() {
                    var spanElement = document.querySelector('__CSS_SELECTOR__');
                    if (!spanElement) {
                        console.error('Element not found');
                        return;
                    }

                    // Lưu giá trị hiện tại
                    var lastValue = spanElement.textContent;
                    console.log('Initial value:', lastValue);

                    // Gọi callback cho giá trị ban đầu
                    if (window.dotNetCallback && lastValue) {
                        window.dotNetCallback('', lastValue, true);
                    }

                    // Tạo debounce function để tránh gọi nhiều lần
                    function debounce(func, wait) {
                        let timeout;
                        return function executedFunction(...args) {
                            const later = () => {
                                clearTimeout(timeout);
                                func(...args);
                            };
                            clearTimeout(timeout);
                            timeout = setTimeout(later, wait);
                        };
                    }

                    function notifyValueChanged(oldVal, newVal) {
                        try {
                            if (window.dotNetCallback) {
                                window.dotNetCallback(oldVal, newVal, false);
                            }
                        } catch(error) {
                            console.error('Error calling callback:', error);
                        }
                    }

                    // Tạo debounced version của notifyValueChanged
                    const debouncedNotify = debounce(notifyValueChanged, 100);

                    // Tạo observer mới
                    var observer = new MutationObserver(
                        function(mutations) {
                            var currentValue = spanElement.textContent;
            
                            if (currentValue !== lastValue) {
                                const oldValue = lastValue;
                                lastValue = currentValue;
                                debouncedNotify(oldValue, currentValue);
                            }
                        }
                    );

                    // Cấu hình cho observer
                    var config = { 
                        childList: true,
                        characterData: true,
                        subtree: true,
                        characterDataOldValue: true
                    };

                    // Bắt đầu theo dõi
                    observer.observe(spanElement, config);
                    window._currentObserver = observer;
                  //  console.log('Observer setup complete for:', '__CSS_SELECTOR__');

                    // Lưu trữ tham chiếu để cleanup
                    window._elementObserver = {
                        observer: observer,
                        element: spanElement,
                        lastValue: lastValue
                    };
                })();

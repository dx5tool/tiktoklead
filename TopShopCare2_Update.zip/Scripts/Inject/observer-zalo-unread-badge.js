                (function() {
                    var targetElement = document.querySelector('__CSS_SELECTOR__');
                    if (!targetElement) {
                        console.error('Element not found');
                        return;
                    }

                    function getValueFromClass(element) {
                        if (!element) return '0';
                
                        // Tìm phần tử con có class leftbar-unread-badge
                        const container = element.querySelector('.leftbar-unread-badge');
                        if (!container) return '0';

                        // Tìm phần tử i trong container
                        const iconElement = container.querySelector('i[class*="fa-"]');
                        if (!iconElement) return '0';

                        const classList = iconElement.className;
                
                        if (classList.includes('fa-1_24_Line')) return '1';
                        if (classList.includes('fa-2_24_Line')) return '2';
                        if (classList.includes('fa-3_24_Line')) return '3';
                        if (classList.includes('fa-4_24_Line')) return '4';
                        if (classList.includes('fa-5_24_Line')) return '5';
                        if (classList.includes('fa-5_Plus_24_Line')) return '6';
                        return '0';
                    }

                    // Lưu giá trị hiện tại
                    var lastValue = getValueFromClass(targetElement);
                    console.log('Initial value:', lastValue);

                    // Gọi callback cho giá trị ban đầu
                    if (window.dotNetCallback && lastValue) {
                        window.dotNetCallback('', lastValue, true);
                    }

                    function debounce(func, wait) {
                        let timeout;
                        return function executedFunction(...args) {
                            const later = () => {
                                clearTimeout(timeout);
                                func(...args);
                            };
                            clearTimeout(timeout);
                            timeout = setTimeout(later, wait);
                        };
                    }

                    function notifyValueChanged(oldVal, newVal) {
                        try {
                            if (window.dotNetCallback) {
                                window.dotNetCallback(oldVal, newVal, false);
                            }
                        } catch(error) {
                            console.error('Error calling callback:', error);
                        }
                    }

                    const debouncedNotify = debounce(notifyValueChanged, 100);

                    var observer = new MutationObserver(
                        function(mutations) {
                            mutations.forEach(function(mutation) {
                                if (mutation.type === 'childList' || 
                                    (mutation.type === 'attributes' && mutation.attributeName === 'class')) {
                                    var currentValue = getValueFromClass(targetElement);
        
                                    if (currentValue !== lastValue) {
                                        const oldValue = lastValue;
                                        lastValue = currentValue;
                                        debouncedNotify(oldValue, currentValue);
                                    }
                                }
                            });
                        }
                    );

                    var config = { 
                        attributes: true,
                        childList: true,
                        subtree: true,
                        attributeFilter: ['class']
                    };

                    observer.observe(targetElement, config);
                    window._currentObserver = observer;

                    window._elementObserver = {
                        observer: observer,
                        element: targetElement,
                        lastValue: lastValue
                    };

                    console.log('Observer setup complete for:', '__CSS_SELECTOR__');
                })();

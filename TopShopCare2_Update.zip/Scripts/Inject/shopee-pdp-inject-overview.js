            (function(){
                console.log('🔧 Bắt đầu inject tổng quan sản phẩm...');

                // Tìm element đích để chèn HTML: ưu tiên cột chi tiết bên trái,
                // dự phòng chèn ngay dưới card sản phẩm khi khu chi tiết chưa render (Shopee render lazy theo scroll)
                var candidates = [
                    ['div.page-product__content--left', 'afterbegin'],
                    ['div.product-detail.page-product__detail', 'beforebegin'],
                    ['section.flex.card', 'afterend']
                ];
                var target = null;
                var position = null;
                for (var i = 0; i < candidates.length; i++) {
                    var el = document.querySelector(candidates[i][0]);
                    if (el) {
                        target = el;
                        position = candidates[i][1];
                        break;
                    }
                }
                if (!target) {
                    console.error('❌ Không tìm thấy element đích để inject tổng quan');
                    return false;
                }

                // Inject HTML vào vị trí tương ứng của target
                target.insertAdjacentHTML(position, __HTML_SNIPPET__);
                console.log('✅ HTML tổng quan đã được inject thành công (' + position + ')');

                var container = document.querySelector('div.custom2-shopee-overview');
                if (!container) {
                    console.error('❌ Không tìm thấy container sau khi inject');
                    return false;
                }

                console.log('✅ Tổng quan sản phẩm đã được thiết lập');
                return true;
            })();

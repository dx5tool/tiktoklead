            (function(){
                console.log('🔧 Bắt đầu inject tổng quan sản phẩm...');
                
                // Tìm element đích để chèn HTML (div.page-product__content--left)
                var target = document.querySelector('div.page-product__content--left');
                if (!target) {
                    console.error('❌ Không tìm thấy div.page-product__content--left');
                    return false;
                }

                // Inject HTML vào đầu tiên của target (afterbegin)
                target.insertAdjacentHTML('afterbegin', __HTML_SNIPPET__);
                console.log('✅ HTML tổng quan đã được inject thành công');

                var container = document.querySelector('div.custom2-shopee-overview');
                if (!container) {
                    console.error('❌ Không tìm thấy container sau khi inject');
                    return false;
                }

                console.log('✅ Tổng quan sản phẩm đã được thiết lập');
                return true;
            })();

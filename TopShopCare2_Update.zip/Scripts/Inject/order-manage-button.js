(function () {
    var boundShopDbId = '__BOUND_SHOP_DB_ID__';
    var buttonId = 'topshopee-btn-manage-order';
    var observerKey = '__topshopeeOrderManageObserver';
    var orderPathPrefix = '/portal/sale/order';

    function normalizeText(value) {
        return (value || '').replace(/\s+/g, ' ').trim();
    }

    function isOrderPage() {
        return location.hostname.indexOf('banhang.shopee.vn') >= 0
            && (location.pathname || '').indexOf(orderPathPrefix) === 0;
    }

    function isCandidate(element) {
        if (!element || element.id === buttonId) {
            return false;
        }

        if (element.closest && element.closest('table, tr, [class*="modal"], [class*="dialog"], [class*="popup"], [class*="drawer"]')) {
            return false;
        }

        return element.getClientRects().length > 0;
    }

    function findHeaderAnchor() {
        var elements = document.querySelectorAll('button, a, [role="button"]');
        var anchor = null;
        var bestTop = Number.MAX_VALUE;
        var fallback = null;
        var fallbackTop = Number.MAX_VALUE;

        for (var i = 0; i < elements.length; i++) {
            var element = elements[i];
            if (!isCandidate(element)) {
                continue;
            }

            var text = normalizeText(element.textContent);
            if (text !== 'Xuất' && text !== 'Lịch sử Xuất Báo cáo') {
                continue;
            }

            var top = element.getBoundingClientRect().top;
            if (text === 'Xuất' && top < bestTop) {
                anchor = element;
                bestTop = top;
            } else if (text === 'Lịch sử Xuất Báo cáo' && top < fallbackTop) {
                fallback = element;
                fallbackTop = top;
            }
        }

        return anchor || fallback;
    }

    function createManageButton() {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.id = buttonId;
        btn.title = 'Mở Quản lý Đơn hàng (TopShopee Care)';
        btn.style.cssText = [
            'display:inline-flex',
            'align-items:center',
            'justify-content:center',
            'gap:6px',
            'background-color:#059669',
            'color:#fff',
            'border:none',
            'padding:0 14px',
            'border-radius:4px',
            'cursor:pointer',
            'font-weight:600',
            'font-size:13px',
            'line-height:1.2',
            'height:36px',
            'margin-right:8px',
            'white-space:nowrap',
            'box-shadow:0 1px 2px rgba(0,0,0,0.08)',
            'transition:background-color 0.2s'
        ].join(';');
        btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"></path><rect x="9" y="3" width="6" height="4" rx="1" ry="1"></rect><path d="M9 12h6"></path><path d="M9 16h4"></path></svg><span>Quản lý Đơn hàng</span>';
        btn.addEventListener('mouseenter', function () { this.style.backgroundColor = '#047857'; });
        btn.addEventListener('mouseleave', function () { this.style.backgroundColor = '#059669'; });
        btn.addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            if (typeof openOrderManager === 'function') {
                openOrderManager(boundShopDbId);
            } else {
                console.warn('openOrderManager is not defined');
            }
        });
        return btn;
    }

    function removeButton() {
        var stale = document.getElementById(buttonId);
        if (stale && stale.parentNode) {
            stale.parentNode.removeChild(stale);
        }
    }

    function injectButton() {
        if (!isOrderPage()) {
            removeButton();
            return;
        }

        var existing = document.getElementById(buttonId);
        if (existing && existing.isConnected && existing.parentNode) {
            var next = existing.nextElementSibling;
            var nextText = next ? normalizeText(next.textContent) : '';
            if (nextText === 'Xuất' || nextText === 'Lịch sử Xuất Báo cáo') {
                return;
            }
            existing.parentNode.removeChild(existing);
        }

        var anchor = findHeaderAnchor();
        if (!anchor || !anchor.parentNode) {
            return;
        }

        anchor.parentNode.insertBefore(createManageButton(), anchor);
    }

    injectButton();

    if (!window[observerKey]) {
        var pending = false;
        window[observerKey] = new MutationObserver(function () {
            if (pending) return;
            pending = true;
            setTimeout(function () {
                pending = false;
                injectButton();
            }, 250);
        });
        window[observerKey].observe(document.body, { childList: true, subtree: true });
    }
})();

(function () {
    var boundShopDbId = '__BOUND_SHOP_DB_ID__';
    var buttonId = 'topshopee-btn-manage-flashsale';
    var observerKey = '__topshopeeFlashSaleManageObserver';

    function normalizeText(value) {
        return (value || '').replace(/\s+/g, ' ').trim();
    }

    function isFlashSalePage() {
        return location.hostname.indexOf('banhang.shopee.vn') >= 0
            && (location.pathname || '').indexOf('/portal/marketing/shop-flash-sale/list') === 0;
    }

    function isCreateButton(btn) {
        if (!btn || btn.id === buttonId) {
            return false;
        }

        if (btn.id && (String(btn.id).indexOf('autoshopee') === 0 || String(btn.id).indexOf('topshopee') === 0)) {
            return false;
        }

        var text = normalizeText(btn.textContent);
        return text === 'Tạo' || text === '+ Tạo';
    }

    function findNativeCreateButton(root) {
        if (!root) {
            return null;
        }

        var buttons = root.querySelectorAll('button.landing-page-btn, button.eds-button--primary');
        for (var i = 0; i < buttons.length; i++) {
            if (isCreateButton(buttons[i])) {
                return buttons[i];
            }
        }

        return null;
    }

    function findAnyCreateButton() {
        var buttons = document.querySelectorAll('button');
        for (var i = 0; i < buttons.length; i++) {
            var btn = buttons[i];
            if (isCreateButton(btn) && btn.getClientRects().length > 0) {
                return btn;
            }
        }

        return null;
    }

    function createManageButton() {
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.id = buttonId;
        btn.title = 'Mở Quản lý FlashSale (TopShopee Care)';
        btn.style.cssText = [
            'display:inline-flex',
            'align-items:center',
            'gap:6px',
            'background-color:#059669',
            'color:#fff',
            'border:none',
            'padding:8px 14px',
            'border-radius:4px',
            'cursor:pointer',
            'font-weight:600',
            'font-size:13px',
            'line-height:1.2',
            'height:40px',
            'margin-right:8px',
            'transition:background-color 0.2s'
        ].join(';');
        btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" width="14" height="14" fill="currentColor" aria-hidden="true"><path d="M9.2 1.2L3.5 9.1c-.2.3 0 .7.4.7h3.2l-.8 5c-.1.4.5.6.7.3l5.7-7.9c.2-.3 0-.7-.4-.7H8.9l.8-5c.1-.4-.5-.6-.7-.3z"/></svg><span>Quản lý FlashSale</span>';
        btn.addEventListener('mouseenter', function () { this.style.backgroundColor = '#047857'; });
        btn.addEventListener('mouseleave', function () { this.style.backgroundColor = '#059669'; });
        btn.addEventListener('click', function (ev) {
            ev.preventDefault();
            ev.stopPropagation();
            if (typeof openFlashSale === 'function') {
                openFlashSale(boundShopDbId);
            } else {
                console.warn('openFlashSale is not defined');
            }
        });
        return btn;
    }

    function removeButton() {
        var stale = document.getElementById(buttonId);
        if (stale && stale.parentNode) {
            stale.parentNode.removeChild(stale);
        }
    }

    function injectButton() {
        if (!isFlashSalePage()) {
            removeButton();
            return;
        }

        var actionRoot = document.querySelector('div.landing-page-action');
        var createBtn = findNativeCreateButton(actionRoot) || findAnyCreateButton();
        if (!actionRoot && createBtn) {
            actionRoot = createBtn.parentElement;
        }

        if (!actionRoot) {
            return;
        }

        var existing = document.getElementById(buttonId);
        if (existing) {
            var sameRoot = existing.parentNode === actionRoot;
            var beforeCreate = !createBtn
                || createBtn.parentNode !== actionRoot
                || existing.nextElementSibling === createBtn;
            if (sameRoot && beforeCreate) {
                return;
            }
            if (existing.parentNode) {
                existing.parentNode.removeChild(existing);
            }
        }

        var manageBtn = createManageButton();
        if (createBtn && createBtn.parentNode === actionRoot) {
            actionRoot.insertBefore(manageBtn, createBtn);
        } else {
            actionRoot.appendChild(manageBtn);
        }
    }

    injectButton();

    if (!window[observerKey]) {
        var pending = false;
        window[observerKey] = new MutationObserver(function () {
            if (pending) return;
            pending = true;
            setTimeout(function () {
                pending = false;
                injectButton();
            }, 250);
        });
        window[observerKey].observe(document.body, { childList: true, subtree: true });
    }
})();

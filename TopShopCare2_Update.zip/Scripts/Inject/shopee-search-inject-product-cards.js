                    (function() {
                        const productDataJson = __PRODUCT_DATA_JSON__;
                        let productsData = {};
                        let adCountOnPage = 0;
                        let totalProductCount = 0;

                        try {
                             // ✅ BỔ SUNG: Parse payload thay vì mảng trực tiếp
                            const payload = JSON.parse(productDataJson);
                            const parsedProducts = payload.products || [];
                            totalProductCount = payload.totalCount || 0;

                            // Đếm số sản phẩm quảng cáo trong dữ liệu nhận được
                            adCountOnPage = parsedProducts.filter(p => p.isAd).length;

                            // Chuẩn bị dữ liệu cho từng sản phẩm như cũ
                            parsedProducts.forEach(p => {
                                productsData[p.itemId] = p;
                            });
                        } catch (e) {
                            console.error('Lỗi parse JSON dữ liệu sản phẩm:', e);
                            return false;
                        }

                        // ✅ BỔ SUNG: Chèn thanh thông tin tổng hợp
                        const sortBar = document.querySelector('fieldset.shopee-sort-bar');
                        if (sortBar) {
                            // Xóa thanh cũ nếu có để cập nhật
                            const oldSummaryBar = document.getElementById('topshopee_summary_bar');
                            if (oldSummaryBar) {
                                oldSummaryBar.remove();
                            }

                            const summaryHtml = `
                                <div id="topshopee_summary_bar" style="background: #1B5E20; color: white; padding: 8px 15px; font-size: 14px; font-weight: 500; text-align: center; margin-bottom: 10px; border-radius: 3px;">
                                    Chạy Quảng cáo: ${adCountOnPage} sản phẩm - Tổng số: ${totalProductCount.toLocaleString('vi-VN')} sản phẩm.
                                </div>
                            `;
                            // Chèn thanh mới vào trước thanh sort
                            sortBar.insertAdjacentHTML('beforebegin', summaryHtml);
                        }


                        const productItems = document.querySelectorAll('li.shopee-search-item-result__item');
                        if (productItems.length === 0) {
                            console.log('Không tìm thấy sản phẩm nào trên trang tìm kiếm.');
                            return false; 
                        }

                        let injectedCount = 0;
                        productItems.forEach(item => {
                            if (item.querySelector('#topshopee_product_search')) {
                                return;
                            }
                            
                            const contentContainer = item.querySelector('a > div > .p-2');
                            if (!contentContainer) { return; }

                            const href = item.querySelector('a')?.getAttribute('href');
                            if (!href) return;

                            const match = href.match(/-i\.(\d+)\.(\d+)/);
                            if (!match) { return; }
                            
                            const shopId = match[1];
                            const itemId = match[2];

                            const data = productsData[itemId];
                            if (!data) { return; }

                            const formatNumber = (num) => (num || 0).toLocaleString('vi-VN');
                            
                            if (data.isAd) {
                                const imageContainer = item.querySelector('a > div > div.pt-full');
                                if (imageContainer) {
                                    let adHtml = '';

                                    if (data.adKeyword) {
                                        adHtml += `<button title="Từ khóa chạy: ${data.adKeyword}" style="position: absolute; top: 6px; left: 6px; z-index: 10; background: linear-gradient(45deg, rgb(60, 0, 177), rgb(106, 0, 255)); color: white; border: none; border-radius: 4px; padding: 2px 8px; font-size: 13px; cursor: pointer; box-shadow: rgba(0, 0, 0, 0.15) 0px 2px 4px; max-width: 120px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">${data.adKeyword}</button>`;
                                    }
                                    
                                    if (data.adBidPrice > 0) {
                                        adHtml += `<button title="Giá thầu" style="position: absolute; top: 30px; left: 6px; z-index: 10; background: linear-gradient(45deg, rgb(255, 102, 0), rgb(255, 153, 0)); color: white; border: none; border-radius: 4px; padding: 2px 8px; font-size: 12px; cursor: pointer; box-shadow: rgba(0, 0, 0, 0.15) 0px 2px 4px;">Thầu: ${formatNumber(data.adBidPrice)} đ</button>`;
                                    }

                                   
                                    
                                    imageContainer.insertAdjacentHTML('beforeend', adHtml);
                                }
                            }

                            const brandHtml = data.isNoBrand ? `<span style="color: rgb(34, 34, 34); font-size: 14px;">${data.brandName}</span>` : `<span style="color: rgb(255, 102, 0); font-size: 14px;">${data.brandName}</span>`;
                            const htmlToInject = `
                            <div id="topshopee_product_search" style="padding: 12px; font-size: 14px; background: rgb(255, 255, 255); border-radius: 4px; box-shadow: rgba(0, 0, 0, 0.1) 0px 2px 4px; margin-top: 4px;">
                                <div style="font-size: 12px; line-height: 1.6;">
                                    <div style="display: flex; justify-content: space-between; align-items: flex-end; margin-bottom: 2px; font-weight: 600;">
                                        <span style="font-weight: 600; color: rgb(34, 34, 34); font-size: 13px;">
                                            <span>${data.date}</span>
                                            <span style="color: rgb(136, 136, 136); font-size: 12px; margin-left: 4px;"> - ${data.age}</span>
                                        </span>
                                    </div>
                                    <div style="border-bottom: 1px solid rgb(224, 224, 224); margin: 4px 0px;"></div>
                                    <div style="display: flex; justify-content: space-between;"><span style="color: rgb(136, 136, 136); font-size: 12px;">Bán trong tháng</span><span style="color: rgb(0, 153, 0); font-weight: 700; font-size: 14px;">${formatNumber(data.monthlySold)} </span></div>
                                    <div style="display: flex; justify-content: space-between;"><span style="color: rgb(136, 136, 136); font-size: 12px;">Doanh số</span><span style="color: rgb(0, 153, 0); font-weight: 700; font-size: 14px;">${formatNumber(data.monthlyRevenue)} </span></div>
                                    <div style="border-bottom: 1px solid rgb(224, 224, 224); margin: 4px 0px;"></div>
                                    <div style="display: flex; justify-content: space-between;"><span style="color: rgb(136, 136, 136); font-size: 12px;">Bán tổng</span><span style="color: rgb(0, 153, 0); font-weight: 700; font-size: 14px;">${formatNumber(data.totalSold)} </span></div>
                                    <div style="display: flex; justify-content: space-between;"><span style="color: rgb(136, 136, 136); font-size: 12px;">Doanh số</span><span style="color: rgb(0, 153, 0); font-weight: 700; font-size: 14px;">${formatNumber(data.totalRevenue)} </span></div>
                                    <div style="border-bottom: 1px solid rgb(224, 224, 224); margin: 4px 0px;"></div>
                                    <div style="display: flex; justify-content: space-between; margin-top: 2px;">${brandHtml}</div>
                                </div>
                            </div>`;

                            contentContainer.insertAdjacentHTML('beforeend', htmlToInject);
                            injectedCount++;
                        });
                        
                        console.log(`✅ Đã chèn dữ liệu cho ${injectedCount} / ${productItems.length} sản phẩm.`);
                        return injectedCount > 0;
                    })();

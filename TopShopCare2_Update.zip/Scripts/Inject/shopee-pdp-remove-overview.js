                        var oldOverview = document.querySelector('div.custom2-shopee-overview');
                        if (oldOverview) {
                            console.log('🧹 Đã tìm thấy và xóa bảng tổng quan cũ.');
                            oldOverview.remove();
                        }

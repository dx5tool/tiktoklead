                    (function() {
                        const todayButton = document.querySelector('button[data-testid="time-selector-today"]')
                            || Array.from(document.querySelectorAll('button')).find(button => (button.innerText || '').trim() === 'Hôm nay');
                        if (!todayButton) {
                            return JSON.stringify({
                                selected: false,
                                reason: 'today_button_not_found',
                                buttonTexts: Array.from(document.querySelectorAll('button')).map(button => (button.innerText || '').trim()).filter(Boolean).slice(0, 20),
                                inputs: Array.from(document.querySelectorAll('[data-tid="m4b_date_picker_range_picker"] input')).map(inputElement => inputElement.value)
                            });
                        }

                        const clickElement = (element) => {
                            element.scrollIntoView({ block: 'center', inline: 'center' });
                            element.focus && element.focus();
                            element.click && element.click();
                            for (const type of ['pointerdown', 'mousedown', 'mouseup', 'click']) {
                                element.dispatchEvent(new MouseEvent(type, { bubbles: true, cancelable: true, view: window }));
                            }
                        };

                        clickElement(todayButton);
                        return JSON.stringify({
                            selected: true,
                            buttonText: (todayButton.innerText || '').trim(),
                            todayActive: todayButton.className.indexOf('active') >= 0,
                            inputs: Array.from(document.querySelectorAll('[data-tid="m4b_date_picker_range_picker"] input')).map(inputElement => inputElement.value)
                        });
                    })();

                    (function() {
                        const selector = 'button.TUXButton[aria-haspopup="dialog"] .TUXButton-content .TUXButton-iconContainer div[class*="DivAvatarContainer"] img[class*="ImgAvatar"]';
                        const fallbackSelector = 'button[aria-haspopup="dialog"] div[class*="DivAvatarContainer"] img[class*="ImgAvatar"]';
                        const strictImages = Array.from(document.querySelectorAll(selector));
                        const fallbackImages = Array.from(document.querySelectorAll(fallbackSelector));
                        const images = strictImages.length > 0 ? strictImages : fallbackImages;

                        const result = {
                            href: location.href,
                            title: document.title,
                            readyState: document.readyState,
                            bodyLength: document.body ? document.body.innerText.length : -1,
                            imgCount: document.images ? document.images.length : -1,
                            matchedSelector: '',
                            src: '',
                            candidates: [selector + '=' + strictImages.length, fallbackSelector + '=' + fallbackImages.length]
                        };

                        for (const image of images) {
                            const src = image.currentSrc || image.src || image.getAttribute('src');
                            if (!src || src.indexOf('http') !== 0) {
                                continue;
                            }

                            if (src.indexOf('/tos-alisg-avt-') < 0 && src.indexOf('-avt-') < 0) {
                                continue;
                            }

                            if (src.indexOf('photomode') >= 0 || src.indexOf('/tos-alisg-i-') >= 0) {
                                continue;
                            }

                            result.matchedSelector = strictImages.length > 0 ? selector : fallbackSelector;
                            result.src = src;
                            return JSON.stringify(result);
                        }

                        return JSON.stringify(result);
                    })();

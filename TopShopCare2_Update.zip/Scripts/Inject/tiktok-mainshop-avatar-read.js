                    (function() {
                        const selectors = [
                            'div[data-tid="m4b_avatar"] .p-avatar-image img',
                            'div[data-tid="m4b_avatar"] img'
                        ];

                        for (const selector of selectors) {
                            const image = document.querySelector(selector);
                            if (!image) {
                                continue;
                            }

                            const src = image.currentSrc || image.src || image.getAttribute('src');
                            if (src && src.indexOf('http') === 0) {
                                return src;
                            }
                        }

                        return '';
                    })();

            (function(){
                if (document.getElementById('shop_analysis_container')) return;

                var configs = [
                    { text: 'PT Shop TikTok (Hôm nay)', period: 'real_time' }
                ];

                var createContainer = function() {
                    var container = document.createElement('div');
                    container.id = 'shop_analysis_container';
                    container.style.cssText = 'display:flex; gap:6px; margin-left:12px; align-items:center; flex-shrink:0;';

                    configs.forEach(function(cfg){
                        var btn = document.createElement('button');
                        btn.textContent = cfg.text;
                        btn.style.cssText = 'background-color:#cc0000;color:white;border:none;padding:6px 12px;border-radius:4px;cursor:pointer;font-weight:bold;font-size:12px;white-space:nowrap;height:32px;';
                        btn.addEventListener('mouseenter', function(){ this.style.backgroundColor = '#b30000'; });
                        btn.addEventListener('mouseleave', function(){ this.style.backgroundColor = '#cc0000'; });
                        btn.addEventListener('click', function(){
                            if (typeof analyzeShopTiktok === 'function') {
                                analyzeShopTiktok(cfg.period);
                            } else {
                                console.warn('analyzeShopTiktok is not defined');
                            }
                        });
                        container.appendChild(btn);
                    });
                    return container;
                };

                var insertButton = function() {
                    if (document.getElementById('shop_analysis_container')) return true;

                    var searchRoot = Array.from(document.querySelectorAll('div[id^="@seller/global-search"]'))[0];
                    var searchWrapper = searchRoot && searchRoot.parentElement;
                    if (searchWrapper) {
                        searchWrapper.insertAdjacentElement('afterend', createContainer());
                        return true;
                    }

                    var searchInput = document.querySelector('input[data-tid="m4b_input"]');
                    var inputGroup = searchInput && searchInput.closest('.core-input-group-wrapper');
                    var widthWrapper = inputGroup && inputGroup.parentElement;
                    var rootFromInput = widthWrapper && widthWrapper.parentElement;
                    var wrapperFromInput = rootFromInput && rootFromInput.parentElement;
                    if (wrapperFromInput) {
                        wrapperFromInput.insertAdjacentElement('afterend', createContainer());
                        return true;
                    }

                    return false;
                };

                if (insertButton()) return;
                var attempts = 0;
                var timer = setInterval(function() {
                    attempts++;
                    if (insertButton() || attempts >= 20) {
                        clearInterval(timer);
                    }
                }, 500);
            })();

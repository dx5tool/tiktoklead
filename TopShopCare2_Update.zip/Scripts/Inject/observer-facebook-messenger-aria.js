                (function() {
                    var spanElement = document.querySelector('__CSS_SELECTOR__');
               
                    if (!spanElement) {
                        console.error('Messenger element not found');
                        return;
                    }

                    // Lưu giá trị hiện tại từ aria-label
                    var lastValue = spanElement.getAttribute('aria-label');
                    console.log('Initial value:', lastValue);

                    // Gọi callback cho giá trị ban đầu
                    if (window.dotNetCallback && lastValue) {
                        window.dotNetCallback('', lastValue, true);
                    }

                    // Tạo debounce function để tránh gọi nhiều lần
                    function debounce(func, wait) {
                        let timeout;
                        return function executedFunction(...args) {
                            const later = () => {
                                clearTimeout(timeout);
                                func(...args);
                            };
                            clearTimeout(timeout);
                            timeout = setTimeout(later, wait);
                        };
                    }

                    function notifyValueChanged(oldVal, newVal) {
                        try {
                            if (window.dotNetCallback) {
                                window.dotNetCallback(oldVal, newVal, false);
                            }
                        } catch(error) {
                            console.error('Error calling callback:', error);
                        }
                    }

                    // Tạo debounced version của notifyValueChanged
                    const debouncedNotify = debounce(notifyValueChanged, 100);

                    // Tạo observer mới
                    var observer = new MutationObserver(
                        function(mutations) {
                            var currentValue = spanElement.getAttribute('aria-label');

                            if (currentValue !== lastValue) {
                                const oldValue = lastValue;
                                lastValue = currentValue;
                                debouncedNotify(oldValue, currentValue);
                            }
                        }
                    );

                    // Cấu hình cho observer
                    var config = { 
                        attributes: true,
                        childList: true,
                        subtree: true,
                        characterData: true,
                        attributeFilter: ['aria-label']
                    };

                    // Bắt đầu theo dõi
                    observer.observe(spanElement, config);
                    window._currentObserver = observer;

                    // Lưu trữ tham chiếu để cleanup
                    window._elementObserver = {
                        observer: observer,
                        element: spanElement,
                        lastValue: lastValue
                    };
                })();

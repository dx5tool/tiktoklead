                    (function(){
                        // Tìm và ẩn nút mua hàng
                        var buyButtons = document.querySelectorAll('button.shopee-button-solid.shopee-button-solid--primary');
                        buyButtons.forEach(function(button) {
                            var spanElement = button.querySelector('span');
                            if (spanElement) {
                                // Kiểm tra cả class SHq91i và text 'Mua hàng'
                                var hasTargetClass = spanElement.classList.contains('SHq91i');
                                var hasTargetText = spanElement.innerText.trim() === 'Mua hàng';
                                var hasTargetTextUp = spanElement.innerText.trim() === 'Mua Hàng';
            
                                // Ẩn nút nếu có ít nhất 1 trong 2 điều kiện
                                if (hasTargetClass || hasTargetText || hasTargetTextUp) {
                                    button.style.display = 'none';
                                }
                            }
                        });
                    })();

/**
 * Dọn trang chủ Seller Shopee trong "cửa sổ tải nhanh" (bản nhẹ - không quét toàn bộ DOM):
 *   1. ẩn overlay popup/modal (unified-popup, khảo sát, chatbot/ChasingMessage, giới thiệu, popup thưởng),
 *   2. ẩn khối "Tin Nổi Bật",
 *   3. ẩn card widget không tải được ("Không thể tải được / Tải lại").
 * Không hủy request nào -> layout trang giữ nguyên.
 *
 * Hiệu năng: chỉ truy vấn theo selector hẹp, chạy tối đa 45 giây, bỏ qua khi tab ẩn.
 * Script được inject lại mỗi lần nạp document nên phải IDEMPOTENT: lần inject sau hủy timer +
 * observer của lần trước, chỉ giữ đúng 1 vòng quét (trước đây chồng 10-17 vòng → nghẽn CPU trang).
 * Danh sách đã ẩn ghi vào window.__tscFastLoadCleanupHidden.
 * Placeholder: __HIDE_POPUPS__, __HIDE_NEWS__, __HIDE_FAILED__, __HIDE_WIDGETS__, __RUN_MS__, __POPUP_RUN_MS__
 */
(function () {
    try {
        var hidePopups = __HIDE_POPUPS__;
        var hideNews = __HIDE_NEWS__;
        var hideFailed = __HIDE_FAILED__;
        var hideWidgets = __HIDE_WIDGETS__;

        // RUN_MS = cửa sổ tải nhanh (ẩn card nặng rồi TRẢ LẠI khi hết).
        // POPUP_RUN_MS = thời gian ẩn popup — phải dài hơn hẳn vì popup quảng cáo của Shopee hiện muộn
        // (sau khi trang đã ổn định) nên nếu chỉ chạy bằng cửa sổ tải nhanh thì popup sẽ hiện trở lại.
        var RUN_MS = __RUN_MS__;
        var POPUP_RUN_MS = __POPUP_RUN_MS__;
        var SCAN_INTERVAL_MS = 2000;
        var OBSERVER_DEBOUNCE_MS = 300;
        var MAX_NODES_PER_PASS = 300;

        var state = window.__tscFastLoadCleanup;
        if (state) {
            // Chống chồng lặp: hủy vòng quét cũ trước khi tạo vòng quét mới.
            if (state.timer) {
                try { clearInterval(state.timer); } catch (e) { }
                state.timer = null;
            }
            if (state.observer) {
                try { state.observer.disconnect(); } catch (e) { }
                state.observer = null;
            }
        }

        if (!state) {
            state = {
                until: Date.now() + RUN_MS,
                popupUntil: Date.now() + Math.max(RUN_MS, POPUP_RUN_MS),
                hidden: [],
                timer: null,
                observer: null,
                scanBudgetUsed: 0
            };
            window.__tscFastLoadCleanup = state;
            window.__tscFastLoadCleanupHidden = state.hidden;
        } else {
            state.until = Date.now() + RUN_MS;
            state.popupUntil = Date.now() + Math.max(RUN_MS, POPUP_RUN_MS);
            if (!state.hidden) {
                state.hidden = [];
                window.__tscFastLoadCleanupHidden = state.hidden;
            }
        }

        // Selector hẹp: chỉ các phần tử có khả năng là popup/modal.
        var POPUP_SELECTOR = [
            '[class*="unified-popup"]',
            '[id*="unified-popup"]',
            '[class*="unifiedPopup"]',
            '[class*="ChatbotUI-"][class*="modal"]',
            '[class*="ChatbotUI-"][class*="popup"]',
            '[class*="ChatbotUI-announcements"]',
            '[class*="ChasingMessage_"][class*="modal"]',
            '[class*="eds-modal"]',
            '[class*="eds-dialog"]',
            '[class*="modal-mask"]',
            '[class*="modalMask"]',
            '[class*="popup-mask"]',
            '[class*="popup-container"]',
            '[class*="popup-wrapper"]',
            '[class*="reward-popup"]',
            '[class*="guide-modal"]',
            '[class*="onboarding-modal"]',
            '[class*="topup-modal"]',
            '[class*="ads-popup"]',
            '[role="dialog"]',
            '[aria-modal="true"]'
        ].join(',');

        // Card/widget: vài chục node mỗi trang -> quét chữ "Tin Nổi Bật"/"Không thể tải được" vẫn rẻ.
        var CARD_SELECTOR = '.page-card,.remote-card,.narrow-card-box,[class*="remote-component"],[class*="announcement-title"]';

        function describe(el) {
            var cls = (el.className && typeof el.className === 'string') ? el.className.split(/\s+/)[0] : '';
            return (el.tagName || '?').toLowerCase() + (el.id ? '#' + el.id : '') + (cls ? '.' + cls : '');
        }

        function hide(el, reason) {
            if (!el || el.__tscFastLoadHidden) {
                return;
            }

            el.__tscFastLoadHidden = true;
            el.__tscFastLoadReason = reason;
            try {
                el.setAttribute('data-tsc-fl-hidden', reason);
            } catch (e) { }
            try {
                el.style.setProperty('display', 'none', 'important');
            } catch (e) { }

            try {
                if (state.hidden.length < 20) {
                    state.hidden.push(reason + ':' + describe(el));
                }
            } catch (e) { }
        }

        function isBigOverlay(el) {
            try {
                var cs = window.getComputedStyle(el);
                if (cs.position !== 'fixed' && cs.position !== 'absolute') {
                    return false;
                }
                if (cs.display === 'none' || cs.visibility === 'hidden') {
                    return false;
                }

                var z = parseInt(cs.zIndex, 10);
                if (isNaN(z) || z < 400) {
                    return false;
                }

                var vw = window.innerWidth || 1;
                var vh = window.innerHeight || 1;
                return el.offsetWidth >= vw * 0.6 && el.offsetHeight >= vh * 0.6;
            } catch (e) {
                return false;
            }
        }

        function scanPopups(root, budget) {
            if (!hidePopups || !root || !root.querySelectorAll) {
                return budget;
            }

            var nodes = root.querySelectorAll(POPUP_SELECTOR);
            for (var i = 0; i < nodes.length && budget > 0; i++, budget--) {
                var el = nodes[i];
                if (el.__tscFastLoadHidden) {
                    continue;
                }

                var parent = el.parentElement;
                if (parent && parent !== document.body && isBigOverlay(parent)) {
                    hide(parent, 'popup');
                }

                hide(el, 'popup');
            }

            return budget;
        }

        // Card bị coi là "ẩn được" chỉ khi nội dung của nó NGẮN (đúng là card, không phải cả khu vực).
        // Trước đây khớp theo textContent nên một .page-card bọc cả hàng widget cũng bị ẩn ⇒ mất dữ liệu.
        var CARD_TEXT_LIMIT = 600;

        // Widget nặng người dùng không muốn thấy trên trang chủ. Ẩn ở tầng DOM (KHÔNG hủy request, vì hủy
        // manifest làm SPA Shopee kẹt ở màn hình chờ). Card chỉ bị ẩn khi TIÊU ĐỀ nằm ở ĐẦU nội dung card
        // và card ngắn ⇒ không ẩn nhầm khu vực lớn.
        var WIDGET_TITLES = [
            'Rẻ Vô Địch',
            'Tăng đơn cùng KOL',
            'Livestream',
            'Chiến dịch',
            'Nhiệm vụ người bán'
        ];

        function matchWidgetTitle(text) {
            if (!text) {
                return null;
            }

            var head = text.replace(/^\s+/, '').substring(0, 40);
            for (var i = 0; i < WIDGET_TITLES.length; i++) {
                if (head.indexOf(WIDGET_TITLES[i]) === 0) {
                    return WIDGET_TITLES[i];
                }
            }

            return null;
        }

        function scanCards(root) {
            if ((!hideNews && !hideFailed && !hideWidgets) || !root || !root.querySelectorAll) {
                return;
            }

            var cards = root.querySelectorAll(CARD_SELECTOR);
            // Duyệt XUÔI (phần tử bao ngoài trước) nhưng bỏ qua phần tử có nội dung dài: nhờ đó phần tử được ẩn
            // là card cụ thể ("Tin Nổi Bật"/card lỗi/widget), không phải khu vực chứa nhiều card dữ liệu.
            for (var i = 0; i < cards.length; i++) {
                var card = cards[i];
                if (card.__tscFastLoadHidden) {
                    continue;
                }

                var text = card.textContent || '';
                if (text.length > CARD_TEXT_LIMIT) {
                    // Khu vực lớn: chỉ xử lý con của nó ở các vòng lặp sau (con nằm trong danh sách cards).
                    continue;
                }

                if (hideWidgets && matchWidgetTitle(text) !== null) {
                    hide(card, 'widget');
                    continue;
                }

                if (hideNews && text.indexOf('Tin Nổi Bật') >= 0) {
                    hide(card, 'news');
                    continue;
                }

                if (hideFailed && (text.indexOf('Không thể tải được') >= 0 || text.trim() === 'Tải lại')) {
                    hide(card, 'failed');
                }
            }
        }

        function runOnce(root, budget, scanCardsToo) {
            var left = scanPopups(root, budget);
            if (scanCardsToo) {
                scanCards(root);
            }

            return left;
        }

        function run() {
            var now = Date.now();

            // Hết cả thời gian ẩn popup thì mới dừng vòng quét (popup Shopee hiện muộn hơn cửa sổ tải nhanh).
            if (now > state.popupUntil) {
                if (state.timer) {
                    clearInterval(state.timer);
                    state.timer = null;
                }
                if (state.observer) {
                    try { state.observer.disconnect(); } catch (e) { }
                    state.observer = null;
                }
                return;
            }

            // Tab ẩn (shop khác đang xem) thì bỏ qua để không tốn CPU.
            if (document.hidden) {
                return;
            }

            try {
                // Quét card trong suốt vòng đời script: widget nặng có thể render muộn, và card đã ẩn thì
                // GIỮ ẩn (không trả lại), nên cần bắt được cả những card xuất hiện sau cửa sổ tải nhanh.
                var left = runOnce(document, MAX_NODES_PER_PASS, true);
                // Nếu còn node chưa xử lý thì lần sau quét tiếp ngân sách mới.
                state.scanBudgetUsed = MAX_NODES_PER_PASS - left;
            } catch (e) { }
        }

        // Popup hiện muộn: DOM có thêm node thì hẹn đúng MỘT lần quét (gộp nhiều bản ghi lại),
        // không quét từng node mới như trước — trên trang React nặng đây là chi phí lớn nhất.
        var scanScheduled = false;
        function scheduleScan() {
            if (scanScheduled) {
                return;
            }

            scanScheduled = true;
            setTimeout(function () {
                scanScheduled = false;
                run();
            }, OBSERVER_DEBOUNCE_MS);
        }

        try {
            if (!state.observer && window.MutationObserver && document.body) {
                state.observer = new MutationObserver(function (records) {
                    if (Date.now() > state.popupUntil || document.hidden) {
                        return;
                    }

                    for (var i = 0; i < records.length; i++) {
                        if (records[i].addedNodes && records[i].addedNodes.length) {
                            scheduleScan();
                            return;
                        }
                    }
                });
                state.observer.observe(document.body, { childList: true, subtree: true });
            }
        } catch (e) { }

        state.timer = setInterval(run, SCAN_INTERVAL_MS);
        run();
    } catch (e) {
        // Lỗi dọn trang không được ảnh hưởng trang chủ.
    }
})();

                    (function() {
                        const picker = document.querySelector('[data-tid="m4b_date_picker_range_picker"]');
                        const inputs = picker ? Array.from(picker.querySelectorAll('input')).map(input => input.value) : [];
                        const bodyText = document.body ? document.body.innerText : '';
                        const ready = location.href.indexOf('/compass/data-overview') >= 0
                            && document.readyState !== 'loading'
                            && !!picker
                            && inputs.length >= 2
                            && inputs.every(value => !!value)
                            && bodyText.indexOf('Số liệu chính') >= 0;
                        return JSON.stringify({
                            ready: ready,
                            attemptUrl: location.href,
                            readyState: document.readyState,
                            pickerFound: !!picker,
                            inputs: inputs,
                            hasMainMetrics: bodyText.indexOf('Số liệu chính') >= 0
                        });
                    })();

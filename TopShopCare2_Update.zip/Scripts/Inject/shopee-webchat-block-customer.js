            (function(){
                var buttonId = 'topshopee_block_customer_button';
                var copyUserButtonId = 'topshopee_copy_user_id_button';
                var observerKey = '__topshopeeBlockCustomerObserver';
                var contextKey = '__topshopeeWebchatBlockContext';
                var pendingReselectKey = '__topshopeeBlockCustomerPendingReselect';
                var pageToken = String(Date.now()) + '_' + Math.random().toString(36).slice(2);
                var context = window[contextKey] = window[contextKey] || {
                    fetchHooked: false,
                    buyerUserId: '',
                    shopId: '',
                    buyerShopId: '',
                    fromUserName: '',
                    conversationId: '',
                    reselecting: false,
                    blockedOverride: null
                };

                function parseJsonSafe(value) {
                    if (!value || typeof value !== 'string') return null;
                    try { return JSON.parse(value); } catch (_) { return null; }
                }

                function normalizeText(value) {
                    return (value || '').replace(/\s+/g, ' ').trim();
                }

                function setContextValue(key, value) {
                    if (value === null || value === undefined || value === '') return;
                    var newValue = String(value);
                    if (key === 'buyerUserId' && context.buyerUserId && context.buyerUserId !== newValue) {
                        context.blockedOverride = null;
                    }
                    context[key] = newValue;
                }

                function refreshContextFromStorage() {
                    var chatShop = parseJsonSafe(localStorage.getItem('chat-session.shop'));
                    if (chatShop && chatShop.id) setContextValue('shopId', chatShop.id);

                    var chatUser = parseJsonSafe(localStorage.getItem('chat-session.user'));
                    if (chatUser && chatUser.shop_id) setContextValue('shopId', chatUser.shop_id);
                }

                function applyContextFromRequest(urlValue, bodyValue) {
                    refreshContextFromStorage();

                    var url;
                    try { url = new URL(urlValue, location.origin); } catch (_) { url = null; }

                    if (url) {
                        var buyerFromQuery = url.searchParams.get('buyer_user_id') || url.searchParams.get('buyer_id');
                        var shopFromQuery = url.searchParams.get('shop_id');
                        var buyerShopFromQuery = url.searchParams.get('buyer_shop_id');
                        var fromUserNameFromQuery = url.searchParams.get('from_user_name');
                        var conversationFromQuery = url.searchParams.get('conversation_id');

                        if (buyerFromQuery) setContextValue('buyerUserId', buyerFromQuery);
                        if (shopFromQuery) setContextValue('shopId', shopFromQuery);
                        if (buyerShopFromQuery) setContextValue('buyerShopId', buyerShopFromQuery);
                        if (fromUserNameFromQuery) setContextValue('fromUserName', fromUserNameFromQuery);
                        if (conversationFromQuery) setContextValue('conversationId', conversationFromQuery);

                        var userPathMatch = url.pathname.match(/\/webchat\/api\/v1\.2\/users\/(\d+)/i);
                        if (userPathMatch && userPathMatch[1]) setContextValue('buyerUserId', userPathMatch[1]);
                    }

                    var body = bodyValue;
                    if (typeof bodyValue === 'string') {
                        body = parseJsonSafe(bodyValue);
                    }

                    if (body && typeof body === 'object') {
                        setContextValue('buyerUserId', body.oppside_user_id || body.to_user_id || body.to_id || body.buyer_user_id || body.buyer_id);
                        setContextValue('shopId', body.shop_id);
                        setContextValue('buyerShopId', body.to_shop_id || body.other_shop_id || body.buyer_shop_id);
                        setContextValue('fromUserName', body.from_user_name || body.fromUserName || body.from_username || body.username);
                        setContextValue('conversationId', body.conversation_id);
                    }
                }

                function applyContextFromResponse(urlValue, json) {
                    if (!json) return;
                    var url;
                    try { url = new URL(urlValue, location.origin); } catch (_) { url = null; }

                    if (url && /\/webchat\/api\/coreapi\/v1\.2\/login/i.test(url.pathname)) {
                        if (json.shop && json.shop.id) setContextValue('shopId', json.shop.id);
                        if (json.user && json.user.shop_id) setContextValue('shopId', json.user.shop_id);
                    }

                    if (url && /\/webchat\/api\/v1\.2\/users\/\d+/i.test(url.pathname)) {
                        if (json.id) setContextValue('buyerUserId', json.id);
                        if (json.shop_id) setContextValue('buyerShopId', json.shop_id);
                        setContextValue('fromUserName', json.from_user_name || json.fromUserName || json.username || json.user_name || json.name);
                    }
                }

                function installContextTracker() {
                    refreshContextFromStorage();
                    if (context.fetchHooked || typeof window.fetch !== 'function') return;

                    var originalFetch = window.fetch;
                    context.fetchHooked = true;
                    window.fetch = function(input, init) {
                        var requestUrl = typeof input === 'string' ? input : (input && input.url) || '';
                        var requestBody = init && init.body;

                        try {
                            applyContextFromRequest(requestUrl, requestBody);
                        } catch (_) { }

                        return originalFetch.apply(this, arguments).then(function(response) {
                            try {
                                var responseUrl = response.url || requestUrl;
                                if (/banhang\.shopee\.vn/i.test(responseUrl) && /webchat\/api/i.test(responseUrl)) {
                                    response.clone().json().then(function(json) {
                                        applyContextFromResponse(responseUrl, json);
                                    }).catch(function(){});
                                }
                            } catch (_) { }
                            return response;
                        });
                    };
                }

                function getBlockContext() {
                    refreshContextFromStorage();
                    return {
                        buyerUserId: context.buyerUserId || '',
                        shopId: context.shopId || '',
                        buyerShopId: context.buyerShopId || '',
                        fromUserName: context.fromUserName || '',
                        conversationId: context.conversationId || ''
                    };
                }

                function getStoredPendingReselect() {
                    var pending = parseJsonSafe(sessionStorage.getItem(pendingReselectKey));
                    if (!pending || !pending.createdAt || Date.now() - pending.createdAt > 120000) {
                        sessionStorage.removeItem(pendingReselectKey);
                        return null;
                    }
                    return pending;
                }

                function savePendingReselect(blockContext, blockedAfter) {
                    var pending = {
                        buyerUserId: blockContext.buyerUserId || '',
                        shopId: blockContext.shopId || '',
                        buyerShopId: blockContext.buyerShopId || '',
                        conversationId: blockContext.conversationId || '',
                        buyerName: getCurrentBuyerName(),
                        blockedAfter: !!blockedAfter,
                        pageToken: pageToken,
                        createdAt: Date.now()
                    };
                    sessionStorage.setItem(pendingReselectKey, JSON.stringify(pending));
                }

                function clearPendingReselect() {
                    sessionStorage.removeItem(pendingReselectKey);
                    context.reselecting = false;
                }

                function getEffectiveBlocked() {
                    if (context.blockedOverride && context.blockedOverride.buyerUserId === context.buyerUserId) {
                        return !!context.blockedOverride.blocked;
                    }

                    return isCustomerBlocked();
                }

                function setLoadingState(btn, loading, blockedBefore) {
                    btn.disabled = loading;
                    btn.style.opacity = loading ? '0.75' : '1';
                    btn.style.cursor = loading ? 'wait' : 'pointer';

                    if (!loading) {
                        applyButtonState(btn, blockedBefore);
                    }
                }

                function setReloadingState(btn) {
                    btn.disabled = true;
                    btn.style.opacity = '0.75';
                    btn.style.cursor = 'wait';
                }

                function isVisible(element) {
                    if (!element) return false;
                    var rect = element.getBoundingClientRect();
                    return rect.width > 0 && rect.height > 0;
                }

                function isOrderCountText(text) {
                    text = (text || '').replace(/\s+/g, ' ').trim();
                    return /^\(?\d+\s*đơn\)?$/i.test(text);
                }

                function hasNearbyMoneyText(element) {
                    var container = element;
                    for (var depth = 0; depth < 4 && container; depth++) {
                        var text = normalizeText(container.textContent || '');
                        if (/[0-9.,]+₫/.test(text) && isOrderCountText(element.textContent)) {
                            return container;
                        }
                        container = container.parentElement;
                    }
                    return null;
                }

                function findOrderCountElement() {
                    var nodes = Array.prototype.slice.call(document.querySelectorAll('div, span'));
                    var candidates = nodes.filter(function(node) {
                        return node.children.length === 0 && isVisible(node) && isOrderCountText(node.textContent);
                    });

                    var matches = [];
                    for (var i = 0; i < candidates.length; i++) {
                        var metricContainer = hasNearbyMoneyText(candidates[i]);
                        if (metricContainer) {
                            matches.push({ element: candidates[i], metricContainer: metricContainer });
                        }
                    }

                    if (matches.length === 0 && candidates.length > 0) {
                        matches = candidates.map(function(candidate) {
                            return { element: candidate, metricContainer: candidate.parentElement || candidate };
                        });
                    }

                    if (matches.length === 0) return null;

                    matches.sort(function(a, b) {
                        var rectA = (a.metricContainer || a.element).getBoundingClientRect();
                        var rectB = (b.metricContainer || b.element).getBoundingClientRect();
                        if (Math.abs(rectA.top - rectB.top) > 12) {
                            return rectA.top - rectB.top;
                        }
                        return rectB.right - rectA.right;
                    });

                    var firstRowTop = (matches[0].metricContainer || matches[0].element).getBoundingClientRect().top;
                    var sameRowMatches = matches.filter(function(match) {
                        var rect = (match.metricContainer || match.element).getBoundingClientRect();
                        return Math.abs(rect.top - firstRowTop) <= 12;
                    });

                    return sameRowMatches[0] || matches[0];
                }

                function getCurrentBuyerName() {
                    var target = findOrderCountElement();
                    var root = target && (target.metricContainer || target.element);
                    for (var depth = 0; depth < 6 && root && root.parentElement; depth++) {
                        var rect = root.getBoundingClientRect();
                        if (rect.width > 250 && rect.height > 28 && rect.height < 180) break;
                        root = root.parentElement;
                    }

                    var candidates = root
                        ? Array.prototype.slice.call(root.querySelectorAll('div, span'))
                        : Array.prototype.slice.call(document.querySelectorAll('div, span')).slice(0, 250);

                    for (var i = 0; i < candidates.length; i++) {
                        var text = normalizeText(candidates[i].textContent || '');
                        if (!text || text.length < 2 || text.length > 80) continue;
                        if (isOrderCountText(text) || /₫|đơn|Chặn|Bỏ Chặn|Đang xử lý|Không thể gửi/i.test(text)) continue;
                        if (!isVisible(candidates[i])) continue;
                        return text;
                    }

                    return '';
                }

                function isCustomerBlocked() {
                    var bodyText = normalizeText(document.body && document.body.textContent || '');
                    return /Không thể gửi tin nhắn vì bạn đã chặn|Cuộc trò chuyện đã được tự động đóng/i.test(bodyText);
                }

                function getBlockIcon() {
                    return ''
                        + '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
                        + '<path d="M12 2L4.5 5.2v5.9c0 4.7 3.2 9.1 7.5 10.4 4.3-1.3 7.5-5.7 7.5-10.4V5.2L12 2Z" fill="currentColor" opacity="0.22"/>'
                        + '<path d="M8.25 12h7.5" stroke="currentColor" stroke-width="2.1" stroke-linecap="round"/>'
                        + '<path d="M12 3.35L5.75 6v5.1c0 3.95 2.58 7.62 6.25 8.96 3.67-1.34 6.25-5.01 6.25-8.96V6L12 3.35Z" stroke="currentColor" stroke-width="1.6"/>'
                        + '</svg>';
                }

                function getUnblockIcon() {
                    return ''
                        + '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
                        + '<path d="M12 2L4.5 5.2v5.9c0 4.7 3.2 9.1 7.5 10.4 4.3-1.3 7.5-5.7 7.5-10.4V5.2L12 2Z" fill="currentColor" opacity="0.18"/>'
                        + '<path d="M8 12.4l2.45 2.45L16.4 8.9" stroke="currentColor" stroke-width="2.1" stroke-linecap="round" stroke-linejoin="round"/>'
                        + '<path d="M12 3.35L5.75 6v5.1c0 3.95 2.58 7.62 6.25 8.96 3.67-1.34 6.25-5.01 6.25-8.96V6L12 3.35Z" stroke="currentColor" stroke-width="1.6"/>'
                        + '</svg>';
                }

                function getCopyUserIcon() {
                    return ''
                        + '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">'
                        + '<path d="M8 7.5C8 5.57 9.57 4 11.5 4H17c1.66 0 3 1.34 3 3v5.5c0 1.93-1.57 3.5-3.5 3.5H11c-1.66 0-3-1.34-3-3V7.5Z" fill="currentColor" opacity="0.22"/>'
                        + '<path d="M7 8H6.5C5.12 8 4 9.12 4 10.5V17c0 1.66 1.34 3 3 3h6.5c1.38 0 2.5-1.12 2.5-2.5V17" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"/>'
                        + '<path d="M11.5 4H17c1.66 0 3 1.34 3 3v5.5c0 1.93-1.57 3.5-3.5 3.5H11c-1.66 0-3-1.34-3-3V7.5C8 5.57 9.57 4 11.5 4Z" stroke="currentColor" stroke-width="1.8"/>'
                        + '</svg>';
                }

                function applyButtonState(btn, blocked) {
                    btn.dataset.blocked = blocked ? 'true' : 'false';
                    btn.title = blocked ? 'Bỏ Chặn Khách này' : 'Chặn Khách này';
                    btn.innerHTML = (blocked ? getUnblockIcon() : getBlockIcon())
                        + '<span>' + (blocked ? 'Bỏ Chặn Khách này' : 'Chặn Khách này') + '</span>';
                    btn.style.borderColor = blocked ? '#12805c' : '#d73211';
                    btn.style.background = blocked ? '#16a76f' : '#ee4d2d';
                    btn.style.boxShadow = blocked
                        ? '0 2px 6px rgba(22,167,111,.24)'
                        : '0 2px 6px rgba(238,77,45,.28)';
                }

                function getCurrentBuyerShopId() {
                    var blockContext = getBlockContext();
                    if (blockContext.buyerShopId) return blockContext.buyerShopId;

                    var match = String(location.href || '').match(/[?&]shop_id=(\d+)/i);
                    return match && match[1] ? match[1] : '';
                }

                function getClipboardText(shopId) {
                    return 'https://shopee.vn/shop/' + String(shopId || '').replace(/^\/+/, '');
                }

                function copyUserIdToClipboard(shopId, feedbackButton) {
                    var finalUrl = getClipboardText(shopId);
                    var done = function(success) {
                        if (feedbackButton) {
                            var previousText = feedbackButton.getAttribute('data-original-text') || feedbackButton.innerText || 'Copy ID Khách';
                            var previousTitle = feedbackButton.title || 'Copy ID Khách';
                            feedbackButton.title = success ? ('Đã copy: ' + finalUrl) : 'Không thể copy link khách';
                            feedbackButton.innerHTML = getCopyUserIcon()
                                + '<span>' + (success ? 'Đã copy' : previousText) + '</span>';
                            feedbackButton.style.background = success ? '#7c3aed' : '#8b5cf6';
                            feedbackButton.style.borderColor = success ? '#6d28d9' : '#7c3aed';
                            setTimeout(function() {
                                feedbackButton.title = previousTitle;
                                feedbackButton.innerHTML = getCopyUserIcon() + '<span>' + previousText + '</span>';
                                feedbackButton.style.background = '#8b5cf6';
                                feedbackButton.style.borderColor = '#7c3aed';
                            }, 1200);
                        }
                    };

                    try {
                        if (navigator.clipboard && navigator.clipboard.writeText) {
                            navigator.clipboard.writeText(finalUrl).then(function() {
                                done(true);
                            }).catch(function() {
                                var ta = document.createElement('textarea');
                                ta.value = finalUrl;
                                ta.style.position = 'fixed';
                                ta.style.opacity = '0';
                                document.body.appendChild(ta);
                                ta.focus();
                                ta.select();
                                var success = false;
                                try { success = document.execCommand('copy'); } catch (_) { success = false; }
                                document.body.removeChild(ta);
                                done(success);
                            });
                        } else {
                            var ta2 = document.createElement('textarea');
                            ta2.value = finalUrl;
                            ta2.style.position = 'fixed';
                            ta2.style.opacity = '0';
                            document.body.appendChild(ta2);
                            ta2.focus();
                            ta2.select();
                            var success2 = false;
                            try { success2 = document.execCommand('copy'); } catch (_) { success2 = false; }
                            document.body.removeChild(ta2);
                            done(success2);
                        }
                    } catch (error) {
                        done(false);
                    }
                }

                function findUserDropdownElement() {
                    var dropdowns = Array.prototype.slice.call(document.querySelectorAll('div.shopee-react-dropdown'));
                    for (var i = 0; i < dropdowns.length; i++) {
                        var dropdown = dropdowns[i];
                        if (!isVisible(dropdown)) continue;

                        var nameNode = dropdown.querySelector('.fFASPdSfTs .UcYjICexD_, .UcYjICexD_');
                        var iconNode = dropdown.querySelector('i.GHUxSkxNuJ.Of2Lw04eKG svg, i.GHUxSkxNuJ, svg');
                        var text = normalizeText(nameNode ? (nameNode.innerText || nameNode.textContent || '') : dropdown.innerText || dropdown.textContent || '');
                        var rect = dropdown.getBoundingClientRect ? dropdown.getBoundingClientRect() : null;
                        var nameRect = nameNode && nameNode.getBoundingClientRect ? nameNode.getBoundingClientRect() : null;
                        if (!nameNode || !iconNode || !text) continue;
                        if (text.length < 2 || text.length > 80) continue;
                        if (!rect || rect.width < 60 || rect.height < 20 || rect.height > 60) continue;
                        if (nameRect && nameRect.width > rect.width * 0.92) continue;
                        return dropdown;
                    }

                    var nameNode = document.querySelector('.fFASPdSfTs .UcYjICexD_, .UcYjICexD_');
                    if (nameNode && isVisible(nameNode)) {
                        var current = nameNode;
                        for (var depth = 0; depth < 4 && current && current !== document.body; depth++) {
                            if (current.classList && current.classList.contains('shopee-react-dropdown')) return current;
                            current = current.parentElement;
                        }
                        return nameNode.parentElement || nameNode;
                    }

                    return null;
                }

                function createCopyUserButton() {
                    var btn = document.createElement('button');
                    btn.id = copyUserButtonId;
                    btn.type = 'button';
                    btn.style.cssText = ''
                        + 'display:inline-flex;'
                        + 'align-items:center;'
                        + 'justify-content:center;'
                        + 'gap:5px;'
                        + 'height:24px;'
                        + 'margin-left:8px;'
                        + 'padding:0 10px;'
                        + 'border:1px solid #7c3aed;'
                        + 'border-radius:999px;'
                        + 'background:#8b5cf6;'
                        + 'color:#fff;'
                        + 'font-size:11px;'
                        + 'font-weight:700;'
                        + 'line-height:1;'
                        + 'box-shadow:0 2px 6px rgba(124,58,237,.28);'
                        + 'cursor:pointer;'
                        + 'white-space:nowrap;'
                        + 'vertical-align:middle;';
                    btn.title = 'Copy link ID khách';
                    btn.innerHTML = getCopyUserIcon() + '<span>Copy ID Khách</span>';
                    btn.addEventListener('mouseenter', function(){
                        btn.style.background = '#7c3aed';
                    });
                    btn.addEventListener('mouseleave', function(){
                        btn.style.background = '#8b5cf6';
                    });
                    btn.addEventListener('click', function(event) {
                        event.preventDefault();
                        event.stopPropagation();

                        var shopId = getCurrentBuyerShopId();
                        if (!shopId) {
                            alert('Không xác định được shop_id của khách để copy.');
                            return;
                        }

                        copyUserIdToClipboard(shopId, btn);
                    });
                    return btn;
                }

                function clickElement(element) {
                    if (!element) return false;
                    try {
                        element.scrollIntoView({ block: 'center', inline: 'nearest' });
                        var rect = element.getBoundingClientRect ? element.getBoundingClientRect() : null;
                        var x = rect ? Math.floor(rect.left + rect.width / 2) : 0;
                        var y = rect ? Math.floor(rect.top + rect.height / 2) : 0;
                        var target = rect ? (document.elementFromPoint(x, y) || element) : element;
                        var options = { bubbles: true, cancelable: true, view: window, clientX: x, clientY: y };
                        try {
                            target.dispatchEvent(new PointerEvent('pointerover', options));
                            target.dispatchEvent(new PointerEvent('pointerenter', options));
                            target.dispatchEvent(new PointerEvent('pointerdown', options));
                            target.dispatchEvent(new PointerEvent('pointerup', options));
                        } catch (_) { }
                        target.dispatchEvent(new MouseEvent('mouseover', options));
                        target.dispatchEvent(new MouseEvent('mousemove', options));
                        target.dispatchEvent(new MouseEvent('mousedown', options));
                        target.dispatchEvent(new MouseEvent('mouseup', options));
                        target.dispatchEvent(new MouseEvent('click', options));
                        element.click();
                        return true;
                    } catch (_) {
                        try {
                            element.click();
                            return true;
                        } catch (__) {
                            return false;
                        }
                    }
                }

                function findClickableAncestor(element) {
                    var current = element;
                    for (var depth = 0; depth < 8 && current && current !== document.body; depth++) {
                        var role = current.getAttribute && current.getAttribute('role');
                        var className = String(current.className || '');
                        var style = window.getComputedStyle ? window.getComputedStyle(current) : null;
                        var rect = current.getBoundingClientRect ? current.getBoundingClientRect() : null;
                        if ((role === 'button' || role === 'option' || role === 'listitem' ||
                            current.tagName === 'BUTTON' || current.tagName === 'LI' ||
                            current.onclick || /item|conversation|session|list|filter|tab|active/i.test(className) ||
                            (style && style.cursor === 'pointer')) &&
                            (!rect || (rect.width > 20 && rect.height > 10))) {
                            return current;
                        }
                        current = current.parentElement;
                    }
                    return element;
                }

                function selectAllConversationsFilter() {
                    var nodes = Array.prototype.slice.call(document.querySelectorAll('button, [role="button"], [role="option"], div, span, li'));
                    var exactMatches = [];
                    var partialMatches = [];
                    for (var i = 0; i < nodes.length; i++) {
                        if (!isVisible(nodes[i])) continue;
                        var text = normalizeText(nodes[i].innerText || nodes[i].textContent || '');
                        if (!text) continue;
                        var rect = nodes[i].getBoundingClientRect();
                        if (text.length > 80 || rect.height > 90) continue;
                        if (/^Tất cả cuộc trò chuyện$/i.test(text)) {
                            exactMatches.push(nodes[i]);
                        } else if (/Tất cả cuộc trò chuyện/i.test(text) || /^Tất cả$/i.test(text)) {
                            partialMatches.push(nodes[i]);
                        }
                    }

                    var target = (exactMatches[0] || partialMatches[0]);
                    return target ? clickElement(findClickableAncestor(target)) : false;
                }

                function findConversationSearchInput() {
                    var inputs = Array.prototype.slice.call(document.querySelectorAll('input'));
                    for (var i = 0; i < inputs.length; i++) {
                        var placeholder = normalizeText(inputs[i].getAttribute('placeholder') || '');
                        var className = String(inputs[i].className || '');
                        if (/Tìm kiếm/i.test(placeholder) || /shopee-react-input__input/i.test(className)) {
                            return inputs[i];
                        }
                    }
                    return null;
                }

                function setInputValue(input, value) {
                    var setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value');
                    if (setter && setter.set) {
                        setter.set.call(input, value);
                    } else {
                        input.value = value;
                    }
                }

                function applyConversationSearch(buyerName) {
                    buyerName = normalizeText(buyerName || '');
                    if (!buyerName) return false;

                    var input = findConversationSearchInput();
                    if (!input || !isVisible(input)) return false;

                    input.focus();
                    setInputValue(input, buyerName);
                    input.dispatchEvent(new Event('input', { bubbles: true }));
                    input.dispatchEvent(new Event('change', { bubbles: true }));
                    return true;
                }

                function attributeContains(element, value) {
                    if (!element || !value || !element.attributes) return false;
                    for (var i = 0; i < element.attributes.length; i++) {
                        var attrValue = String(element.attributes[i].value || '');
                        if (attrValue.indexOf(value) >= 0) return true;
                    }
                    return false;
                }

                function getConversationClickTarget(element) {
                    var current = element;
                    var best = null;
                    for (var depth = 0; depth < 10 && current && current !== document.body; depth++) {
                        var rect = current.getBoundingClientRect ? current.getBoundingClientRect() : null;
                        var text = normalizeText(current.innerText || current.textContent || '');
                        var className = String(current.className || '');
                        if (/Tất cả Người mua|Bộ lọc|Tính năng phân bổ Chat/i.test(text)) {
                            current = current.parentElement;
                            continue;
                        }

                        if (rect && rect.width >= 160 && rect.height >= 36 && rect.height <= 180 && text.length > 0 && text.length <= 260) {
                            best = current;
                            if (/item|conversation|session|thread|chat/i.test(className) ||
                                current.getAttribute('role') === 'button' ||
                                current.getAttribute('role') === 'listitem' ||
                                current.onclick) {
                                break;
                            }
                        }
                        current = current.parentElement;
                    }
                    return findClickableAncestor(best || element);
                }

                function isSafeConversationMatchElement(element, expectedText) {
                    if (!element || !isVisible(element)) return false;
                    var text = normalizeText(element.innerText || element.textContent || '');
                    if (!text || text.indexOf(expectedText) < 0) return false;
                    if (/Tất cả Người mua|Bộ lọc|Tính năng phân bổ Chat/i.test(text)) return false;
                    var rect = element.getBoundingClientRect ? element.getBoundingClientRect() : null;
                    if (!rect || rect.width < 80 || rect.height < 12 || rect.height > 140) return false;
                    return text.length <= 260;
                }

                function findConversationElement(pending) {
                    var nodes = Array.prototype.slice.call(document.querySelectorAll('div, li, a, button, span'));
                    var ids = [pending.conversationId, pending.buyerUserId, pending.buyerShopId].filter(Boolean);

                    for (var idIndex = 0; idIndex < ids.length; idIndex++) {
                        for (var i = 0; i < nodes.length; i++) {
                            var idText = normalizeText(nodes[i].innerText || nodes[i].textContent || '');
                            if (attributeContains(nodes[i], ids[idIndex]) &&
                                !/Tất cả Người mua|Bộ lọc|Tính năng phân bổ Chat/i.test(idText)) {
                                return getConversationClickTarget(nodes[i]);
                            }
                        }
                    }

                    var buyerName = normalizeText(pending.buyerName || '');
                    if (buyerName && buyerName.length >= 2) {
                        for (var j = 0; j < nodes.length; j++) {
                            if (isSafeConversationMatchElement(nodes[j], buyerName)) {
                                return getConversationClickTarget(nodes[j]);
                            }
                        }
                    }

                    return null;
                }

                function findFirstSearchResultElement(pending) {
                    var buyerName = normalizeText(pending && pending.buyerName || '');
                    if (!buyerName) return null;

                    var titled = Array.prototype.slice.call(document.querySelectorAll('[title]'));
                    for (var i = 0; i < titled.length; i++) {
                        if (normalizeText(titled[i].getAttribute('title') || '') !== buyerName || !isVisible(titled[i])) continue;

                        var current = titled[i];
                        var best = null;
                        for (var depth = 0; depth < 8 && current && current !== document.body; depth++) {
                            var text = normalizeText(current.innerText || current.textContent || '');
                            var rect = current.getBoundingClientRect ? current.getBoundingClientRect() : null;
                            var className = String(current.className || '');
                            if (rect && text.indexOf(buyerName) >= 0 &&
                                !/Khách Hàng|Tất cả Người mua|Bộ lọc|Tính năng phân bổ Chat/i.test(text) &&
                                rect.width >= 120 && rect.height >= 24 && rect.height <= 140) {
                                best = current;
                                if (/SW7LUhQFDH|item|conversation|session|thread|chat/i.test(className)) {
                                    break;
                                }
                            }
                            current = current.parentElement;
                        }

                        if (best) {
                            return best;
                        }
                    }

                    return null;
                }

                function restorePendingConversation() {
                    var pending = getStoredPendingReselect();
                    if (!pending || context.reselecting) return;
                    if (pending.pageToken === pageToken) return;
                    if (!location.hostname.includes('banhang.shopee.vn') ||
                        !location.pathname.includes('/new-webchat/conversations')) {
                        return;
                    }

                    context.reselecting = true;
                    var startedAt = Date.now();
                    var selectedFilter = false;
                    var searchApplied = false;
                    var clickedResult = false;
                    var attemptCount = 0;
                    var readySignature = '';
                    var readySince = 0;
                    var resultSignature = '';
                    var resultStableSince = 0;

                    function attempt() {
                        attemptCount++;
                        pending = getStoredPendingReselect();
                        if (!pending) {
                            context.reselecting = false;
                            return;
                        }

                        if (!selectedFilter) {
                            selectedFilter = selectAllConversationsFilter();
                        }

                        var searchInput = findConversationSearchInput();
                        var bodyTextLength = (document.body && document.body.innerText || '').length;
                        var visibleNodeCount = Array.prototype.slice.call(document.querySelectorAll('div, li, a, button, span')).filter(isVisible).length;
                        var signature = [
                            !!searchInput,
                            bodyTextLength,
                            visibleNodeCount,
                            selectedFilter
                        ].join('|');
                        if (signature !== readySignature) {
                            readySignature = signature;
                            readySince = Date.now();
                        }

                        var isRestoreReady = !!searchInput && isVisible(searchInput) && bodyTextLength >= 250 && visibleNodeCount >= 20 && Date.now() - readySince >= 1200;
                        if (!searchApplied && !isRestoreReady) {
                            if (Date.now() - startedAt > 25000) {
                                context.reselecting = false;
                                return;
                            }
                            requestAnimationFrame(attempt);
                            return;
                        }

                        if (!searchApplied && pending.buyerName) {
                            searchApplied = applyConversationSearch(pending.buyerName);
                        }

                        if (pending.buyerName && !searchApplied) {
                            if (Date.now() - startedAt > 15000) {
                                context.reselecting = false;
                                return;
                            }
                            requestAnimationFrame(attempt);
                            return;
                        }

                        if (clickedResult) {
                            if (context.buyerUserId === pending.buyerUserId) {
                                clearPendingReselect();
                                return;
                            }
                            requestAnimationFrame(attempt);
                            return;
                        }

                        var chatElement = searchApplied
                            ? (findFirstSearchResultElement(pending) || findConversationElement(pending))
                            : findConversationElement(pending);
                        var chatText = chatElement ? normalizeText(chatElement.innerText || chatElement.textContent || '').slice(0, 180) : '';
                        if (searchApplied && chatElement) {
                            if (chatText !== resultSignature) {
                                resultSignature = chatText;
                                resultStableSince = Date.now();
                            }

                            if (Date.now() - resultStableSince < 1000) {
                                requestAnimationFrame(attempt);
                                return;
                            }
                        }
                        if (chatElement && clickElement(chatElement)) {
                            clickedResult = true;
                            if (context.buyerUserId === pending.buyerUserId) {
                                clearPendingReselect();
                                return;
                            }
                        }

                        if (Date.now() - startedAt > 25000) {
                            context.reselecting = false;
                            return;
                        }

                        requestAnimationFrame(attempt);
                    }

                    requestAnimationFrame(attempt);
                }

                function createButton() {
                    var btn = document.createElement('button');
                    btn.id = buttonId;
                    btn.type = 'button';
                    btn.style.cssText = ''
                        + 'display:inline-flex;'
                        + 'align-items:center;'
                        + 'justify-content:center;'
                        + 'gap:6px;'
                        + 'height:28px;'
                        + 'margin-left:10px;'
                        + 'padding:0 12px;'
                        + 'border:1px solid #d73211;'
                        + 'border-radius:999px;'
                        + 'background:#ee4d2d;'
                        + 'color:#fff;'
                        + 'font-size:12px;'
                        + 'font-weight:700;'
                        + 'line-height:1;'
                        + 'box-shadow:0 2px 6px rgba(238,77,45,.28);'
                        + 'cursor:pointer;'
                        + 'white-space:nowrap;'
                        + 'vertical-align:middle;';

                    btn.addEventListener('mouseenter', function(){
                        btn.style.background = btn.dataset.blocked === 'true' ? '#0f8f5f' : '#d73211';
                    });
                    btn.addEventListener('mouseleave', function(){
                        btn.style.background = btn.dataset.blocked === 'true' ? '#16a76f' : '#ee4d2d';
                    });
                    btn.addEventListener('click', async function(event) {
                        event.preventDefault();
                        event.stopPropagation();

                        if (btn.disabled) return;

                        var blockedBefore = btn.dataset.blocked === 'true';
                        var blockContext = getBlockContext();
                        if (!blockContext.buyerUserId || !blockContext.shopId) {
                            alert('Không xác định được khách hoặc shop để thao tác.');
                            applyButtonState(btn, blockedBefore);
                            return;
                        }

                        setLoadingState(btn, true, blockedBefore);

                        var shouldReload = false;
                        try {
                            if (blockedBefore) {
                                var endpoint = '/webchat/api/workbenchapi/v1.2/sc/user/blocks/'
                                    + encodeURIComponent(blockContext.buyerUserId)
                                    + '?shop_id=' + encodeURIComponent(blockContext.shopId);

                                var response = await fetch(endpoint, {
                                    method: 'DELETE',
                                    credentials: 'include',
                                    headers: {
                                        'accept': 'application/json, text/plain, */*'
                                    }
                                });

                                if (!response.ok) {
                                    throw new Error('HTTP ' + response.status);
                                }
                            } else {
                                var blockRaw = window.topshopeeWebchatBlock(blockContext.buyerUserId, blockContext.shopId);
                                var blockResult = null;
                                try {
                                    blockResult = typeof blockRaw === 'string' ? JSON.parse(blockRaw) : blockRaw;
                                } catch (_) {
                                    blockResult = { success: false, message: 'Hệ thống trả về dữ liệu không hợp lệ' };
                                }
                                if (!blockResult || !blockResult.success) {
                                    throw new Error((blockResult && blockResult.message) ? blockResult.message : 'Hệ thống thất bại');
                                }
                            }

                            savePendingReselect(blockContext, !blockedBefore);
                            setReloadingState(btn);
                            shouldReload = true;
                            location.reload();
                        } catch (error) {
                            sessionStorage.removeItem(pendingReselectKey);
                            context.blockedOverride = null;
                            applyButtonState(btn, blockedBefore);
                            alert((blockedBefore ? 'Bỏ chặn' : 'Chặn') + ' khách không thành công. Vui lòng thử lại.');
                        } finally {
                            if (!shouldReload) {
                                btn.disabled = false;
                                btn.style.opacity = '1';
                                btn.style.cursor = 'pointer';
                            }
                        }
                    });

                    return btn;
                }

                function injectButton() {
                    if (!location.hostname.includes('banhang.shopee.vn') ||
                        !location.pathname.includes('/new-webchat/conversations')) {
                        return;
                    }

                    var currentButton = document.getElementById(buttonId);
                    var currentCopyButton = document.getElementById(copyUserButtonId);
                    var target = findOrderCountElement();
                    var blockContext = getBlockContext();
                    if (!target || !target.element || !blockContext.buyerUserId || !blockContext.shopId) {
                        if (currentButton && currentButton.parentNode) {
                            currentButton.parentNode.removeChild(currentButton);
                        }
                        if (currentCopyButton && currentCopyButton.parentNode) {
                            currentCopyButton.parentNode.removeChild(currentCopyButton);
                        }
                        return;
                    }

                    var userDropdown = findUserDropdownElement();
                    if (userDropdown) {
                        var copyBtn = currentCopyButton || createCopyUserButton();
                        copyBtn.setAttribute('data-original-text', 'Copy ID Khách');
                        copyBtn.title = 'Copy link ID khách: https://shopee.vn/shop/' + blockContext.buyerShopId;
                        if (copyBtn.previousElementSibling !== userDropdown) {
                            userDropdown.insertAdjacentElement('afterend', copyBtn);
                        }
                    } else if (currentCopyButton && currentCopyButton.parentNode) {
                        currentCopyButton.parentNode.removeChild(currentCopyButton);
                    }

                    var insertAfter = target.element;
                    var metricContainer = target.metricContainer || target.element.parentElement;
                    if (metricContainer && metricContainer.contains(target.element)) {
                        insertAfter = metricContainer;
                    }

                    var blocked = getEffectiveBlocked();
                    if (currentButton && currentButton.previousElementSibling === insertAfter) {
                        applyButtonState(currentButton, blocked);
                        return;
                    }

                    var btn = currentButton || createButton();
                    applyButtonState(btn, blocked);
                    insertAfter.insertAdjacentElement('afterend', btn);
                }

                installContextTracker();
                injectButton();
                restorePendingConversation();

                if (!window[observerKey]) {
                    var pending = false;
                    window[observerKey] = new MutationObserver(function() {
                        if (pending) return;
                        pending = true;
                        setTimeout(function() {
                            pending = false;
                            injectButton();
                            restorePendingConversation();
                        }, 250);
                    });
                    window[observerKey].observe(document.body, { childList: true, subtree: true, characterData: true });
                }
            })();

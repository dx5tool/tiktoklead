(() => {
  window.ShopeeAutomationBridge = {
    log(level, message, data) {
      return browser.runtime.sendMessage({
        type: "LOG",
        payload: {
          level: level || "info",
          message: String(message || ""),
          href: location.href,
          data: data || null,
          ts: Date.now()
        }
      }).catch(() => null);
    },
    result(payload) {
      const body = Object.assign({ href: location.href, ts: Date.now() }, payload || {});
      return browser.runtime.sendMessage({ type: "RESULT", payload: body }).catch(() => null);
    },
    importCookies(cookieText) {
      return browser.runtime.sendMessage({ type: "IMPORT_COOKIES", cookieText: cookieText || "" }).catch(() => null);
    },
    navigate(url) {
      return browser.runtime.sendMessage({ type: "NAVIGATE", url: url || "" }).catch(() => null);
    },
    setPendingFbProduct(payload) {
      return browser.runtime.sendMessage({ type: "SET_PENDING_FB_PRODUCT", payload: payload || {} }).catch(() => null);
    },
    getPendingFbProduct() {
      return browser.runtime.sendMessage({ type: "GET_PENDING_FB_PRODUCT" }).catch(() => null);
    },
    clearPendingFbProduct() {
      return browser.runtime.sendMessage({ type: "CLEAR_PENDING_FB_PRODUCT" }).catch(() => null);
    }
  };
})();

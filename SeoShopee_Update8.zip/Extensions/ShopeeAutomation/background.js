(() => {
  const config = window.SHOPEE_AUTOMATION_CONFIG || {};
  const port = Number(config.port || 0);
  const token = String(config.token || "");
  const sessionId = String(config.sessionId || "");
  const baseUrl = port > 0 ? `http://127.0.0.1:${port}` : "";

  function headers() {
    return {
      "Content-Type": "application/json",
      "X-Shopee-Automation-Token": token,
      "X-Shopee-Automation-Session": sessionId
    };
  }

  async function post(path, payload) {
    if (!baseUrl || !token) {
      return null;
    }
    try {
      const response = await fetch(`${baseUrl}${path}`, {
        method: "POST",
        headers: headers(),
        body: JSON.stringify(payload || {})
      });
      if (!response.ok) {
        return null;
      }
      return await response.json().catch(() => null);
    } catch (error) {
      return null;
    }
  }

  function normalizeCookieText(cookieText) {
    let text = String(cookieText || "").trim();
    if (!text) {
      return "";
    }
    text = text.replace(/(?:^|[;]\s*)\.shopee\.vn\s*=\s*/gi, "");
    return text.trim();
  }

  function extractSpcF(cookieText) {
    const normalized = normalizeCookieText(cookieText);
    const match = normalized.match(/SPC_F\s*=\s*["']?([^;"'\s]+)/i);
    return match ? match[1] : "";
  }

  function parseCookiePairs(cookieText) {
    const normalized = normalizeCookieText(cookieText);
    if (!normalized) {
      return [];
    }
    const pairs = [];
    const re = /(?:^|;)\s*([A-Za-z0-9_]+)\s*=\s*([^;]*)/g;
    let m;
    while ((m = re.exec(normalized)) !== null) {
      const name = (m[1] || "").trim();
      const value = (m[2] || "").trim();
      if (name) {
        pairs.push({ name, value });
      }
    }
    return pairs;
  }

  async function readBrowserSpcF() {
    try {
      const cookie = await browser.cookies.get({ url: "https://shopee.vn/", name: "SPC_F" });
      return cookie && cookie.value ? String(cookie.value) : "";
    } catch (error) {
      return "";
    }
  }

  async function importCookies(cookieText) {
    const text = normalizeCookieText(cookieText);
    const spcFExpected = extractSpcF(text);
    if (!text) {
      const spcFActual = await readBrowserSpcF();
      return { imported: 0, skipped: 0, spcFExpected, spcFActual, spcFMatched: !spcFExpected };
    }
    const pairs = parseCookiePairs(text);
    let imported = 0;
    let skipped = 0;
    for (const pair of pairs) {
      const name = pair.name;
      const value = pair.value;
      if (!name) {
        skipped += 1;
        continue;
      }
      try {
        await browser.cookies.set({
          url: "https://shopee.vn/",
          name,
          value,
          domain: ".shopee.vn",
          path: "/",
          secure: true,
          sameSite: "no_restriction",
          expirationDate: Math.floor(Date.now() / 1000) + 86400 * 30
        });
        imported += 1;
      } catch (error) {
        try {
          await browser.cookies.set({
            url: "https://shopee.vn/",
            name,
            value,
            path: "/",
            secure: true,
            expirationDate: Math.floor(Date.now() / 1000) + 86400 * 30
          });
          imported += 1;
        } catch (innerError) {
          skipped += 1;
        }
      }
    }
    const spcFActual = await readBrowserSpcF();
    return { imported, skipped, spcFExpected, spcFActual, spcFMatched: !!spcFExpected && spcFActual === spcFExpected };
  }

  const PENDING_FB_STORAGE_KEY = "pendingFbProductOpen";

  async function setPendingFbProduct(payload) {
    const body = payload && typeof payload === "object" ? payload : {};
    await browser.storage.local.set({
      [PENDING_FB_STORAGE_KEY]: {
        productUrl: String(body.productUrl || ""),
        idHint: String(body.idHint || ""),
        ts: Number(body.ts || Date.now())
      }
    });
    return { ok: true };
  }

  async function getPendingFbProduct() {
    const data = await browser.storage.local.get(PENDING_FB_STORAGE_KEY);
    const pending = data[PENDING_FB_STORAGE_KEY];
    if (!pending || !pending.productUrl) {
      return { pending: null };
    }
    if (Date.now() - Number(pending.ts || 0) > 180000) {
      await browser.storage.local.remove(PENDING_FB_STORAGE_KEY);
      return { pending: null };
    }
    return { pending };
  }

  async function clearPendingFbProduct() {
    await browser.storage.local.remove(PENDING_FB_STORAGE_KEY);
    return { ok: true };
  }

  async function navigate(sender, url) {
    const targetUrl = String(url || "").trim();
    if (!targetUrl || !sender || !sender.tab || !sender.tab.id) {
      return { ok: false };
    }
    await browser.tabs.update(sender.tab.id, { url: targetUrl });
    return { ok: true, url: targetUrl };
  }

  browser.runtime.onMessage.addListener((message, sender) => {
    const type = message && message.type;
    if (type === "IMPORT_COOKIES") {
      return importCookies(message.cookieText).then(result => {
        post("/log", { level: "info", message: `IMPORT_COOKIES imported=${result.imported} skipped=${result.skipped}` });
        return result;
      });
    }
    if (type === "RESULT") {
      return post("/result", message.payload || {}).then(result => result || { ok: true });
    }
    if (type === "LOG") {
      return post("/log", message.payload || {}).then(result => result || { ok: true });
    }
    if (type === "NAVIGATE") {
      return navigate(sender, message.url).then(result => result || { ok: false });
    }
    if (type === "SET_PENDING_FB_PRODUCT") {
      return setPendingFbProduct(message.payload);
    }
    if (type === "GET_PENDING_FB_PRODUCT") {
      return getPendingFbProduct();
    }
    if (type === "CLEAR_PENDING_FB_PRODUCT") {
      return clearPendingFbProduct();
    }
    return false;
  });

  post("/log", { level: "info", message: "BACKGROUND_READY" });
})();

window.SHOPEE_AUTOMATION_CONFIG = {
  port: 0,
  token: "",
  sessionId: "",
  pollIntervalMs: 400
};

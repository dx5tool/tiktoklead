(() => {
  const config = window.SHOPEE_AUTOMATION_CONFIG || {};
  const port = Number(config.port || 0);
  const token = String(config.token || "");
  const sessionId = String(config.sessionId || "");
  const pollIntervalMs = Number(config.pollIntervalMs || 800);
  const baseUrl = port > 0 ? `http://127.0.0.1:${port}` : "";
  let runningTaskId = "";

  function requestHeaders() {
    return {
      "Content-Type": "application/json",
      "X-Shopee-Automation-Token": token,
      "X-Shopee-Automation-Session": sessionId
    };
  }

  function sleep(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }

  function visible(element) {
    if (!element) return false;
    const style = getComputedStyle(element);
    const rect = element.getBoundingClientRect();
    return style.visibility !== "hidden" && style.display !== "none" && rect.width > 0 && rect.height > 0;
  }

  function findFirst(selectors) {
    for (const selector of selectors) {
      const found = Array.from(document.querySelectorAll(selector)).find(visible);
      if (found) return found;
    }
    return null;
  }

  function summarizeElement(element) {
    if (!element) return null;
    const rect = element.getBoundingClientRect();
    const centerX = Math.max(0, Math.floor(rect.left + rect.width / 2));
    const centerY = Math.max(0, Math.floor(rect.top + rect.height / 2));
    const center = document.elementFromPoint(centerX, centerY);
    return {
      tag: element.tagName,
      className: String(element.className || ""),
      text: (element.textContent || "").trim().slice(0, 80),
      rect: { left: Math.round(rect.left), top: Math.round(rect.top), width: Math.round(rect.width), height: Math.round(rect.height) },
      centerX,
      centerY,
      centerTag: center ? center.tagName : "",
      centerClass: center ? String(center.className || "") : "",
      src: element.getAttribute("src") || element.querySelector("img")?.getAttribute("src") || "",
      closestUbg: !!element.closest(".UBG7wZ"),
      closestJA: !!element.closest(".jA1mTx"),
      closestAir: !!element.closest(".airUhU")
    };
  }

  function findMainProductMediaTarget() {
    const mediaCandidates = Array.from(document.querySelectorAll("video, img"))
      .filter(element => visible(element) && !element.closest(".airUhU") && !element.closest("header") && !element.closest("footer"))
      .map(element => ({ element, rect: element.getBoundingClientRect(), src: element.getAttribute("src") || "" }))
      .filter(item => item.rect.width >= 180 && item.rect.height >= 180 && (item.element.tagName === "VIDEO" || item.src.includes("susercontent")))
      .sort((a, b) => (b.rect.width * b.rect.height) - (a.rect.width * a.rect.height));
    if (mediaCandidates[0]) return mediaCandidates[0].element;

    const containerCandidates = Array.from(document.querySelectorAll("section, div, picture"))
      .filter(element => visible(element) && !element.closest(".airUhU") && !element.closest("header") && !element.closest("footer") && !(element.textContent || "").toLowerCase().includes("skip to main content"))
      .map(element => ({ element, rect: element.getBoundingClientRect(), src: element.querySelector("img")?.getAttribute("src") || "" }))
      .filter(item => item.rect.width >= 180 && item.rect.height >= 180 && (item.src.includes("susercontent") || item.element.querySelector("video")))
      .sort((a, b) => (b.rect.width * b.rect.height) - (a.rect.width * a.rect.height));
    return containerCandidates[0]?.element || null;
  }

  function findButtonByText(texts) {
    const normalized = texts.map(text => text.toLowerCase());
    const candidates = Array.from(document.querySelectorAll("button, [role='button'], a"));
    return candidates.find(element => {
      if (!visible(element)) return false;
      const text = (element.textContent || "").trim().toLowerCase();
      return normalized.some(item => text === item || text.includes(item));
    }) || null;
  }

  function findLoginLink() {
    return Array.from(document.querySelectorAll("a[href*='/buyer/login']")).find(element => {
      if (!visible(element)) return false;
      const text = (element.textContent || "").trim().toLowerCase();
      return text === "login" || text === "đăng nhập" || text.includes("login") || text.includes("đăng nhập");
    }) || null;
  }

  function isOnBuyerLoginPage() {
    return (location.href || "").toLowerCase().includes("/buyer/login");
  }

  const LOGIN_KEY_INPUT_SELECTORS = [
    "input[name='loginKey']",
    "input[type='text'][name='loginKey']",
    "form input[name='loginKey']",
    "input[autocomplete='username'][name='loginKey']",
    "input[autocomplete='username']",
    "input[placeholder*='Phone number']",
    "input[placeholder*='Username']",
    "input[placeholder*='Email']",
    "input[placeholder*='Số điện thoại']",
    "input[placeholder*='Tên đăng nhập']",
    "input[placeholder*='Email/Số điện thoại/Tên đăng nhập']",
    "input[name='username']",
    "form input[type='text']",
    "form input:not([type])"
  ];
  const LOGIN_PASSWORD_SELECTORS = [
    "input[name='password']",
    "input[type='password'][name='password']",
    "form input[name='password']",
    "input[autocomplete='current-password'][name='password']",
    "input[autocomplete='current-password']",
    "input[placeholder*='Password']",
    "input[placeholder*='Mật khẩu']",
    "input[type='password']"
  ];
  const LOGIN_SUBMIT_SELECTORS = [
    "form button.b5aVaf",
    "button.b5aVaf.PVSuiZ",
    "button.b5aVaf",
    "form button[type='submit']",
    "button[type='submit']",
    "button[aria-label*='Log in']",
    "button[aria-label*='Đăng nhập']"
  ];

  function loginFieldUsable(element) {
    if (!element || !element.isConnected) return false;
    const tag = String(element.tagName || "").toLowerCase();
    if (tag === "input" || tag === "button" || tag === "textarea" || tag === "select") {
      return true;
    }
    if (visible(element)) return true;
    const rect = element.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) return true;
    return element.offsetParent !== null;
  }

  function findShopeeAuthLoginForm(root) {
    const host = root || document;
    const keyInput = host.querySelector("input[name='loginKey'], input[name='username'], input[autocomplete='username']");
    if (keyInput && keyInput.closest) {
      const form = keyInput.closest("form");
      if (form) return form;
    }
    const passInput = host.querySelector("input[name='password'], input[type='password']");
    if (passInput && passInput.closest) {
      const form = passInput.closest("form");
      if (form) return form;
    }
    const shell = host.querySelector("div.VAy83y form, div.iXeFvH form, form");
    return shell || null;
  }

  function loginFormSearchRoots() {
    const roots = [document];
    const iframes = Array.from(document.querySelectorAll("iframe"));
    for (const frame of iframes) {
      try {
        const doc = frame.contentDocument;
        if (doc && doc.body) roots.push(doc);
      } catch (e) {
        /* cross-origin */
      }
    }
    return roots;
  }

  function probeLoginFormFields() {
    const userSelectors = LOGIN_KEY_INPUT_SELECTORS.concat([
      "input[autocomplete='username']",
      "input[type='text'][name='loginKey']",
      "input[placeholder*='Phone']",
      "input[placeholder*='Email']",
      "input[placeholder*='Số điện thoại']",
      "input[placeholder*='Tên đăng nhập']"
    ]);
    const passSelectors = LOGIN_PASSWORD_SELECTORS.concat([
      "input[type='password']",
      "input[autocomplete='current-password']"
    ]);
    let userEl = null;
    let passEl = null;
    let submitEl = null;
    let iframeCount = 0;
    let domKeyCount = 0;
    for (const root of loginFormSearchRoots()) {
      if (root !== document) iframeCount++;
      domKeyCount += root.querySelectorAll("input[name='loginKey']").length;
      if (!userEl) userEl = findLoginInputByName("loginKey", root) || firstUsableIn(userSelectors, root);
      if (!passEl) passEl = findLoginInputByName("password", root) || firstUsableIn(passSelectors, root);
      if (!submitEl) submitEl = firstUsableIn(LOGIN_SUBMIT_SELECTORS, root);
      if (userEl && passEl) break;
    }
    return {
      hasUser: !!userEl,
      hasPass: !!passEl,
      ready: !!(userEl && passEl),
      submitPresent: !!submitEl,
      iframeCount,
      domKeyCount
    };
  }

  function hasInlineLoginForm() {
    return probeLoginFormFields().ready;
  }

  function hasPartialLoginForm() {
    const p = probeLoginFormFields();
    return p.hasUser || p.hasPass;
  }

  function isOnLoginFormSurface() {
    return isOnBuyerLoginPage() || hasInlineLoginForm();
  }

  /** /verify/traffic/error with "Log in to continue" — click Log In, not OTP nick stop. */
  function isVerifyTrafficLoginGatePage() {
    if (hasInlineLoginForm()) return false;
    const href = (location.href || "").toLowerCase();
    if (!href.includes("/verify/traffic/error")) return false;
    const text = pageText();
    if (text.includes("log in to continue") || text.includes("đăng nhập để tiếp tục")) {
      return true;
    }
    return !!findVerifyTrafficContinueLoginButton();
  }

  function findVerifyTrafficContinueLoginButton() {
    const classButtons = Array.from(document.querySelectorAll("button.O1y698"));
    const fromClass = classButtons.find(element => {
      if (!visible(element)) return false;
      const t = (element.textContent || "").trim().toLowerCase();
      return t === "log in" || t === "đăng nhập" || t === "login" || t.includes("log in");
    });
    if (fromClass) return fromClass;
    return findButtonByText(["log in", "đăng nhập", "login"]);
  }

  const DEFAULT_BUYER_LOGIN_URL = "https://shopee.vn/buyer/login?next=https%3A%2F%2Fshopee.vn%2F";

  async function waitForInlineLoginForm(timeoutMs, pollMs, source) {
    const cap = Math.min(timeoutMs || 15000, 30000);
    const deadline = Date.now() + cap;
    const step = pollMs || 300;
    let lastHeartbeat = Date.now();
    while (Date.now() < deadline) {
      const probe = probeLoginFormFields();
      if (probe.ready) {
        return true;
      }
      const now = Date.now();
      if (now - lastHeartbeat >= 8000) {
        lastHeartbeat = now;
      }
      await sleep(step);
    }
    const finalProbe = probeLoginFormFields();
    return finalProbe.ready;
  }

  async function maybeRecoverVerifyTrafficLoginGate(source, options) {
    if (hasInlineLoginForm() || hasLoggedInProof() || isOnBuyerLoginPage()) {
      return hasInlineLoginForm() || isOnBuyerLoginPage();
    }
    const captchaGate = isCaptchaRiskHref(location.href);
    if (!isVerifyTrafficLoginGatePage() && !isTrafficErrorUrl() && !captchaGate) return false;
    await window.ShopeeAutomationBridge.log("info", `TRAFFIC_LOGIN_RECOVER source=${source || ""} captcha=${captchaGate ? 1 : 0} href=${location.href}`).catch(() => {});
    await navigate(DEFAULT_BUYER_LOGIN_URL);
    const waitMsRaw = options && options.waitFormMs != null ? options.waitFormMs : (options && options.waitMs != null ? options.waitMs : 12000);
    const waitMs = Math.max(0, Number(waitMsRaw) || 0);
    if (waitMs > 0) {
      await waitForInlineLoginForm(waitMs, 300, `traffic_${source || ""}`);
    }
    return true;
  }

  function isTrafficErrorUrl(hrefRaw) {
    const h = String(hrefRaw || location.href || "").toLowerCase();
    if (h.includes("/verify/captcha")) return false;
    return h.includes("/verify/traffic");
  }

  async function ensureBuyerLoginPageReady(source) {
    if (!isOnLoginFormSurface() && !isVerifyTrafficLoginGatePage() && !isTrafficErrorUrl() && !isCaptchaRiskHref(location.href)) return false;
    if (isVerifyTrafficLoginGatePage() || isTrafficErrorUrl() || (isCaptchaRiskHref(location.href) && !hasLoggedInProof())) {
      await maybeRecoverVerifyTrafficLoginGate(source || "ensure_ready", { waitMs: 15000 });
    }
    const loginInputSelectors = LOGIN_KEY_INPUT_SELECTORS.concat(["input[autocomplete='username']", "form input[type='text']"]);
    const formDeadline = Date.now() + 8000;
    while (Date.now() < formDeadline && !findFirst(loginInputSelectors) && !hasInlineLoginForm()) {
      await sleep(250);
    }
    await closeLoginPagePopupsQuick();
    const hasForm = hasInlineLoginForm() || !!findFirst(loginInputSelectors);
    await window.ShopeeAutomationBridge.log(
      "info",
      `BUYER_LOGIN_PAGE_READY source=${source || ""} hasForm=${hasForm} href=${location.href}`
    );
    return true;
  }

  function needLoginTaskResult(extra) {
    const ex = extra || {};
    if (ex.loginFormReady == null) {
      ex.loginFormReady = hasInlineLoginForm() || hasPartialLoginForm() || isOnBuyerLoginPage();
    }
    return Object.assign({
      status: "NEED_LOGIN",
      state: "NEED_LOGIN",
      loginProof: false,
      message: "TRAFFIC_VERIFY_GATE_TO_LOGIN",
      href: location.href,
      hasLoginLink: !!findLoginLink(),
      hasNavbarUsername: !!findNavbarUsername()
    }, ex);
  }

  async function reportNeedLoginThenNavigateToBuyerLogin(task, extra) {
    const out = needLoginTaskResult(extra);
    await reportThenNavigate(task, out, DEFAULT_BUYER_LOGIN_URL);
    return Object.assign({ alreadyReported: true }, out);
  }

  let lastContentReadyHref = "";
  let postLoginRiskWatchTimer = 0;
  let lastPostedLoginBlockedHref = "";

  function stopPostLoginRiskWatch() {
    if (postLoginRiskWatchTimer) {
      clearInterval(postLoginRiskWatchTimer);
      postLoginRiskWatchTimer = 0;
    }
  }

  async function reportLoginBlockedIfRisk(source) {
    if (await maybeRecoverVerifyTrafficLoginGate(source || "report_blocked")) {
      return false;
    }
    const risk = inspectLoginPageRisk();
    if (risk && !hasLoggedInProof() && (risk.status === "NEED_CAPTCHA" || risk.status === "ACCOUNT_LOCKED")) {
      await navigate(DEFAULT_BUYER_LOGIN_URL);
      return false;
    }
    if (risk) {
      const key = `${risk.status}|${risk.href}`;
      if (key !== lastPostedLoginBlockedHref) {
        lastPostedLoginBlockedHref = key;
        await window.ShopeeAutomationBridge.log("info", `LOGIN_BLOCKED status=${risk.status} href=${risk.href} source=${source}`);
      }
      stopPostLoginRiskWatch();
      return true;
    }
    const state = detectState();
    if (!hasLoggedInProof() && (state === "NEED_CAPTCHA" || state === "ACCOUNT_LOCKED")) {
      await navigate(DEFAULT_BUYER_LOGIN_URL);
      return false;
    }
    if (state === "NEED_OTP" || state === "NEED_VERIFY" || state === "NEED_CAPTCHA" || state === "ACCOUNT_LOCKED") {
      const key = `${state}|${location.href}`;
      if (key !== lastPostedLoginBlockedHref) {
        lastPostedLoginBlockedHref = key;
        await window.ShopeeAutomationBridge.log("info", `LOGIN_BLOCKED status=${state} href=${location.href} source=${source}`);
      }
      stopPostLoginRiskWatch();
      return true;
    }
    return false;
  }

  function startPostLoginRiskWatch() {
    stopPostLoginRiskWatch();
    const deadline = Date.now() + 120000;
    postLoginRiskWatchTimer = setInterval(() => {
      if (Date.now() > deadline) {
        stopPostLoginRiskWatch();
        return;
      }
      if (hasLoggedInProof()) {
        stopPostLoginRiskWatch();
        return;
      }
      reportLoginBlockedIfRisk("post_login_poll").catch(() => {});
    }, 300);
  }

  async function emitContentReadyIfStable() {
    const href = location.href;
    if (!href || href === lastContentReadyHref) return;
    const hl = href.toLowerCase();
    const stableMs = hl.includes("/verify/") ? 150 : 900;
    await sleep(stableMs);
    if (location.href !== href) return;
    lastContentReadyHref = href;
    await maybeRecoverVerifyTrafficLoginGate("content_ready");
    const risk = inspectLoginPageRisk();
    if (risk && hasLoggedInProof()) {
      await window.ShopeeAutomationBridge.log("info", `LOGIN_BLOCKED status=${risk.status} href=${risk.href} reason=${risk.reason || ""}`);
    }
    await window.ShopeeAutomationBridge.log("info", "CONTENT_READY");
    applyLoggedInCartBadgePrivacy();
  }

  async function navigate(url) {
    const targetUrl = String(url || "").trim();
    if (!targetUrl) return { ok: false, reason: "EMPTY_URL" };
    const res = await window.ShopeeAutomationBridge.navigate(targetUrl);
    return res && res.ok !== false ? res : { ok: false, reason: "BRIDGE_NAV_FAIL" };
  }

  function findLoginSubmitButton(anchorInput) {
    const anchorForm = anchorInput && anchorInput.closest ? anchorInput.closest("form") : null;
    const authForm = anchorForm || findShopeeAuthLoginForm();
    const hosts = [authForm, document].filter((item, index, arr) => item && arr.indexOf(item) === index);
    for (const host of hosts) {
      for (const sel of LOGIN_SUBMIT_SELECTORS) {
        const btn = host.querySelector(sel);
        if (btn && loginFieldUsable(btn)) return btn;
      }
      const buttons = Array.from(host.querySelectorAll("button, [role='button']"));
      const byText = buttons.find(button => {
        if (!loginFieldUsable(button)) return false;
        const text = (button.textContent || "").trim().toLowerCase();
        return text === "log in" || text === "login" || text === "đăng nhập" || text.includes("đăng nhập") || text.includes("log in");
      });
      if (byText) return byText;
    }
    return findButtonByText(["log in", "login", "đăng nhập"]);
  }

  function firstUsableIn(selectorList, root) {
    const host = root || document;
    for (const selector of selectorList) {
      const found = Array.from(host.querySelectorAll(selector)).find(loginFieldUsable);
      if (found) return found;
    }
    return null;
  }

  function findLoginInputByName(fieldName, root) {
    const host = root || document;
    const el = host.querySelector(`input[name='${fieldName}']`);
    return el && loginFieldUsable(el) ? el : null;
  }

  function findLoginInputsByName() {
    for (const root of loginFormSearchRoots()) {
      const userEl = findLoginInputByName("loginKey", root) || findLoginInputByName("username", root) || firstUsableIn(LOGIN_KEY_INPUT_SELECTORS, root);
      const passEl = findLoginInputByName("password", root) || firstUsableIn(LOGIN_PASSWORD_SELECTORS, root);
      if (userEl && passEl) {
        return { userEl, passEl, rootTag: root === document ? "document" : "iframe" };
      }
    }
    let userEl = null;
    let passEl = null;
    for (const root of loginFormSearchRoots()) {
      if (!userEl) userEl = findLoginInputByName("loginKey", root) || findLoginInputByName("username", root) || firstUsableIn(LOGIN_KEY_INPUT_SELECTORS, root);
      if (!passEl) passEl = findLoginInputByName("password", root) || firstUsableIn(LOGIN_PASSWORD_SELECTORS, root);
    }
    return { userEl, passEl, rootTag: userEl || passEl ? "partial" : "none" };
  }


  async function waitForUsableLoginFields(timeoutMs) {
    const deadline = Date.now() + (timeoutMs || 12000);
    let lastProbe = null;
    while (Date.now() < deadline) {
      const byName = findLoginInputsByName();
      lastProbe = probeLoginFormFields();
      if (byName.userEl && byName.passEl) {
        return { userEl: byName.userEl, passEl: byName.passEl, probe: lastProbe, byName: true };
      }
      if (lastProbe.ready) {
        const u = firstUsableIn(LOGIN_KEY_INPUT_SELECTORS);
        const p = firstUsableIn(LOGIN_PASSWORD_SELECTORS);
        if (u && p) return { userEl: u, passEl: p, probe: lastProbe, byName: false };
      }
      await sleep(250);
    }
    const byName = findLoginInputsByName();
    lastProbe = probeLoginFormFields();
    return {
      userEl: byName.userEl,
      passEl: byName.passEl,
      probe: lastProbe,
      byName: !!(byName.userEl && byName.passEl),
      timedOut: true
    };
  }

  function isHomePopupVisible() {
    const popup = document.querySelector("#HomePagePopupBannerSection") || document.querySelector("section[id*='HomePagePopup']");
    if (!popup || !visible(popup)) return false;
    const rect = popup.getBoundingClientRect();
    return rect.width > 40 && rect.height > 40;
  }

  function findAnyPopupCloseButton() {
    const inBanner = findHomePopupCloseButton();
    if (inBanner) return inBanner;
    const globalSelectors = [
      "div.e_KtkD.Xg_fY5",
      "div.qGCNW3.f8dS_D",
      "div.e_KtkD",
      "div.qGCNW3"
    ];
    for (const selector of globalSelectors) {
      const element = Array.from(document.querySelectorAll(selector)).find(el => visible(el));
      if (element) return element;
    }
    return null;
  }

  function findHomePopupCloseButton() {
    const popup = document.querySelector("#HomePagePopupBannerSection") || document.querySelector("section[id*='HomePagePopup']");
    if (!popup || !visible(popup)) return null;
    const ordered = [
      () => popup.querySelector("div.e_KtkD.Xg_fY5"),
      () => popup.querySelector("div.qGCNW3.f8dS_D"),
      () => popup.querySelector("div.e_KtkD"),
      () => popup.querySelector("div.qGCNW3"),
      () => {
        const svg = popup.querySelector("svg.KQjk2l");
        return svg ? (svg.closest("div.e_KtkD") || svg.closest("div.qGCNW3") || svg.parentElement) : null;
      }
    ];
    for (const pick of ordered) {
      const element = pick();
      if (element && visible(element)) return element;
    }
    return null;
  }

  async function waitForHomePopupCloseButton(timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const button = findHomePopupCloseButton();
      if (button) return button;
      await sleep(350);
    }
    return null;
  }

  async function closeLoginPagePopupsQuick() {
    if (!isOnBuyerLoginPage()) return 0;
    return closeHomePopup(1, { popupWaitMs: 400, useGlobalClose: true });
  }

  const POST_LOGIN_POPUP_CLOSE_ROUNDS = 2;
  const POST_LOGIN_POPUP_WAIT_MS = 5000;
  const POST_LOGIN_POPUP_TOTAL_BUDGET_MS = 12000;

  async function closePostLoginPopupsTwoRounds(options) {
    const opts = options || {};
    const waitMs = Number.isFinite(Number(opts.popupWaitMs)) ? Number(opts.popupWaitMs) : POST_LOGIN_POPUP_WAIT_MS;
    if (!opts.skipBeginLog) {
      await window.ShopeeAutomationBridge.log("info", "POST_LOGIN_POPUP_CLOSE_BEGIN");
    }
    const budgetDeadline = Date.now() + POST_LOGIN_POPUP_TOTAL_BUDGET_MS;
    let totalClosed = 0;
    for (let round = 1; round <= POST_LOGIN_POPUP_CLOSE_ROUNDS; round += 1) {
      if (Date.now() >= budgetDeadline) break;
      const closed = await closeHomePopup(2, {
        popupWaitMs: waitMs,
        useGlobalClose: true,
        forceHomePopupWait: true,
        exactMaxAttempts: 2
      });
      totalClosed += closed;
      if (round < POST_LOGIN_POPUP_CLOSE_ROUNDS && Date.now() < budgetDeadline) {
        await sleep(200);
      }
    }
    return totalClosed;
  }

  async function closeHomePopup(maxAttempts, options) {
    const opts = options || {};
    if (isOnBuyerLoginPage() && !opts.forceHomePopupWait) {
      const quickMs = Number.isFinite(Number(opts.popupWaitMs)) ? Math.min(800, Number(opts.popupWaitMs)) : 400;
      return closeHomePopup(Math.min(2, Number(maxAttempts) || 1), { ...opts, popupWaitMs: quickMs, forceHomePopupWait: true });
    }
    const popupWaitMs = Number(opts.popupWaitMs);
    const waitFirstMs = Number.isFinite(popupWaitMs) ? popupWaitMs : 12000;
    let closed = 0;
    const rawMax = Number(maxAttempts) || 2;
    const attempts =
      opts.exactMaxAttempts != null
        ? Math.max(1, Number(opts.exactMaxAttempts))
        : Math.max(2, rawMax);
    const findClose = opts.useGlobalClose ? findAnyPopupCloseButton : findHomePopupCloseButton;
    for (let i = 0; i < attempts; i += 1) {
      let target = findClose();
      if (!target && i === 0 && waitFirstMs > 0) {
        target = await waitForHomePopupCloseButton(waitFirstMs);
      } else if (!target) {
        await sleep(500);
        target = findClose();
      }
      if (!target) break;
      await safeScrollIntoView(target);
      clickElementWithPointer(target, true);
      closed += 1;
      await sleep(1100);
      if (!isHomePopupVisible()) continue;
    }
    if (closed > 0) {
      await window.ShopeeAutomationBridge.log("info", `POPUP_CLOSED count=${closed} visibleAfter=${isHomePopupVisible()}`);
    }
    return closed;
  }

  function normalizeRiskText(value) {
    return String(value || "")
      .toLowerCase()
      .replace(/[\u00a0\u200b\u200c\u200d]+/g, " ")
      .replace(/\s+/g, " ")
      .trim();
  }

  function pageText() {
    const body = document.body;
    if (!body) return "";
    const chunks = [body.innerText || ""];
    const selector = "[role='alert'], [role='dialog'], [aria-live]";
    for (const element of Array.from(document.querySelectorAll(selector))) {
      chunks.push(element.innerText || element.textContent || "");
      chunks.push(element.getAttribute("aria-label") || "");
    }
    return normalizeRiskText(chunks.join(" "));
  }

  function isShopeeHomeUrl(hrefRaw) {
    const href = String(hrefRaw || location.href).toLowerCase();
    if (!href.includes("shopee.vn")) return false;
    if (href.includes("/buyer/login") || href.includes("/login?")) return false;
    try {
      const path = new URL(href).pathname || "/";
      return path === "/" || path === "";
    } catch (e) {
      return /shopee\.vn\/?(\?|$)/i.test(href);
    }
  }

  function findNavbarUsername() {
    const el = document.querySelector("div.navbar__username");
    if (el && visible(el)) {
      const text = (el.textContent || "").trim();
      if (text.length > 0) return el;
    }
    const fuzzy = findFirst(["div.navbar__username", "[class*='navbar__username']"]);
    if (!fuzzy || !visible(fuzzy)) return null;
    const text = (fuzzy.textContent || "").trim();
    if (!text || /^(đăng nhập|login|sign up|đăng ký)$/i.test(text)) return null;
    return fuzzy;
  }

  function hasLoggedInProof() {
    const href = location.href.toLowerCase();
    if (href.includes("/buyer/login")) return false;
    if (findLoginLink()) return false;
    return !!findNavbarUsername();
  }

  const CART_BADGE_HIDE_STYLE_ID = "shopee-automation-hide-cart-badge";
  let cartBadgeHideObserver = null;

  function isShopeeAutomationHost() {
    const host = (location.hostname || "").toLowerCase();
    return host === "shopee.vn" || host.endsWith(".shopee.vn");
  }

  function ensureCartBadgeHideStyles() {
    if (!document || document.getElementById(CART_BADGE_HIDE_STYLE_ID)) {
      return;
    }
    const style = document.createElement("style");
    style.id = CART_BADGE_HIDE_STYLE_ID;
    style.textContent = [
      ".shopee-cart-number-badge,",
      "[class*='shopee-cart-number-badge'] {",
      "  display: none !important;",
      "  visibility: hidden !important;",
      "  opacity: 0 !important;",
      "  pointer-events: none !important;",
      "}"
    ].join("\n");
    (document.head || document.documentElement).appendChild(style);
  }

  function hideLoggedInCartCountBadges() {
    if (!isShopeeAutomationHost() || !hasLoggedInProof()) {
      return;
    }
    ensureCartBadgeHideStyles();
    const badges = document.querySelectorAll(".shopee-cart-number-badge, [class*='shopee-cart-number-badge']");
    for (const badge of badges) {
      badge.setAttribute("aria-hidden", "true");
      badge.style.setProperty("display", "none", "important");
      badge.style.setProperty("visibility", "hidden", "important");
    }
  }

  function stopLoggedInCartBadgeHideWatcher() {
    if (cartBadgeHideObserver) {
      cartBadgeHideObserver.disconnect();
      cartBadgeHideObserver = null;
    }
  }

  function startLoggedInCartBadgeHideWatcher() {
    if (!isShopeeAutomationHost() || cartBadgeHideObserver) {
      return;
    }
    hideLoggedInCartCountBadges();
    if (!document.body) {
      return;
    }
    cartBadgeHideObserver = new MutationObserver(() => {
      hideLoggedInCartCountBadges();
    });
    cartBadgeHideObserver.observe(document.body, { childList: true, subtree: true, characterData: true });
  }

  function applyLoggedInCartBadgePrivacy() {
    if (!isShopeeAutomationHost() || !hasLoggedInProof()) {
      return;
    }
    hideLoggedInCartCountBadges();
    startLoggedInCartBadgeHideWatcher();
  }

  async function waitForNavbarUsername(timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (findNavbarUsername()) return true;
      await sleep(400);
    }
    return !!findNavbarUsername();
  }

  function isCaptchaRiskHref(href) {
    const raw = String(href || "");
    if (!raw) return false;
    let path = raw.toLowerCase();
    try {
      path = (new URL(raw).pathname || "").toLowerCase();
    } catch (e) {
      const q = path.indexOf("?");
      if (q >= 0) path = path.slice(0, q);
    }
    if (path.includes("/verify/traffic")) {
      return false;
    }
    return path.includes("/verify/captcha")
      || path.includes("/captcha")
      || /(?:^|\/)anti[-_]?bot(?:\/|$)/.test(path);
  }

  function isTrafficLoginFlowSurface() {
    if (isOnBuyerLoginPage()) return true;
    if (hasInlineLoginForm()) return true;
    if (isTrafficErrorUrl()) return true;
    return isVerifyTrafficLoginGatePage();
  }

  async function ensureTrafficLoginFormReady(source, options) {
    const opts = options || {};
    const totalMs = Math.min(opts.timeoutMs != null ? opts.timeoutMs : 12000, 12000);
    const started = Date.now();
    let gateClicked = false;
    const probe0 = probeLoginFormFields();
    if (probe0.ready) {
      return { ready: true, partial: false, gateClicked: false, waitedMs: 0 };
    }
    if (isVerifyTrafficLoginGatePage()) {
      gateClicked = await maybeRecoverVerifyTrafficLoginGate(source || "ensure_form", { waitFormMs: 6000 });
    } else if (isTrafficErrorUrl()) {
      const gateBtn = findVerifyTrafficContinueLoginButton();
      if (gateBtn) {
        gateClicked = await maybeRecoverVerifyTrafficLoginGate(source || "ensure_form_traffic", { waitFormMs: 6000 });
      }
    }
    let ready = await waitForInlineLoginForm(5000, 350, source || "ensure");
    let probe1 = probeLoginFormFields();
    if (!ready && gateClicked && isTrafficErrorUrl() && !isOnBuyerLoginPage()) {
      await navigate(DEFAULT_BUYER_LOGIN_URL);
      ready = await waitForInlineLoginForm(8000, 350, "buyer_login_fallback");
      probe1 = probeLoginFormFields();
    }
    const waitedMs = Date.now() - started;
    const partial = !ready && (probe1.hasUser || probe1.hasPass);
    const assumeReady = gateClicked && (ready || partial || isOnBuyerLoginPage());
    return {
      ready: ready || partial || assumeReady,
      partial,
      gateClicked,
      waitedMs
    };
  }

  function getProductFlowCaptchaRisk() {
    const href = location.href || "";
    const risk = inspectLoginPageRisk();
    if (risk && risk.status === "NEED_CAPTCHA") {
      return risk;
    }
    if (isCaptchaRiskHref(href)) {
      return { status: "NEED_CAPTCHA", href };
    }
    if (document.querySelector("iframe[src*='captcha'], iframe[src*='recaptcha'], iframe[src*='hcaptcha']")) {
      return { status: "NEED_CAPTCHA", href };
    }
    return null;
  }

  async function abortInteractIfProductCaptcha(contextLabel) {
    const risk = getProductFlowCaptchaRisk();
    if (!risk) {
      return null;
    }
    const label = String(contextLabel || "view_media").trim() || "view_media";
    await window.ShopeeAutomationBridge.log(
      "info",
      `PRODUCT_CAPTCHA_AFTER_${label} status=NEED_CAPTCHA href=${risk.href}`
    );
    return {
      status: "NEED_CAPTCHA",
      state: "NEED_CAPTCHA",
      href: risk.href,
      message: `captcha_after_${label}`
    };
  }

  function hasAccountLockedRiskText(text) {
    const normalized = normalizeRiskText(text);
    return normalized.includes("your login attempt has been rejected due to unusual activities in your account")
      || normalized.includes("login attempt has been rejected due to unusual activities")
      || normalized.includes("due to unusual activities in your account")
      || normalized.includes("due to unusual activities")
      || normalized.includes("your account has been temporarily restricted due to automated tools detected")
      || normalized.includes("temporarily restricted due to automated tools detected")
      || normalized.includes("restricted due to automated tools detected")
      || normalized.includes("password is incorrect, please try again")
      || normalized.includes("incorrect, please try again");
  }

  function inspectLoginPageRisk() {
    const href = location.href || "";
    const hl = href.toLowerCase();
    const text = pageText();
    let out = null;
    if (hasAccountLockedRiskText(text)) {
      out = { status: "ACCOUNT_LOCKED", href, reason: "account_locked_text" };
    } else if (isVerifyTrafficLoginGatePage()) {
      out = null;
    } else if (isTrafficErrorUrl() && (hasInlineLoginForm() || isOnBuyerLoginPage())) {
      out = null;
    } else if (isTrafficErrorUrl()) {
      out = null;
    } else if (isCaptchaRiskHref(href)) {
      out = { status: "NEED_CAPTCHA", href, reason: "captcha_href" };
    } else if (document.querySelector("iframe[src*='captcha'], iframe[src*='recaptcha'], iframe[src*='hcaptcha']")) {
      out = { status: "NEED_CAPTCHA", href, reason: "captcha_iframe" };
    } else if (hl.includes("/verify/email-link")) {
      out = { status: "NEED_VERIFY", href, reason: "verify_email_href" };
    } else if (text.includes("please verify your identity")) {
      out = { status: "NEED_VERIFY", href, reason: "verify_identity_text" };
    }
    return out;
  }

  function detectState() {
    const risk = inspectLoginPageRisk();
    if (risk) {
      return risk.status;
    }
    const text = pageText();
    const href = location.href.toLowerCase();
    const onLoginPage = href.includes("/buyer/login");
    const hasLoginKeyInput = !!findFirst(["input[name='loginKey']", "input[name='username']"]);
    const hasPasswordInput = !!findFirst(["input[name='password']", "input[type='password']"]);
    const loginButton = findButtonByText(["đăng nhập", "log in", "login"]);
    const loginLink = findLoginLink();
    if (text.includes("đã bị khóa") || text.includes("bị cấm") || hasAccountLockedRiskText(text)) {
      return "ACCOUNT_LOCKED";
    }
    if (isCaptchaRiskHref(href) || text.includes("vui lòng xác nhận captcha") || document.querySelector("iframe[src*='verify/captcha'], iframe[src*='/captcha']")) {
      return "NEED_CAPTCHA";
    }
    if (href.includes("/verify/email-link") || text.includes("xác minh email") || text.includes("email-link") || text.includes("please verify your identity")) {
      return "NEED_VERIFY";
    }
    if (href.includes("/verify/traffic")) {
      return "NEED_LOGIN";
    }
    if (text.includes("otp") || text.includes("mã xác nhận") || text.includes("sms")) {
      return "NEED_OTP";
    }
    if (hasLoggedInProof()) {
      return "LOGGED_IN";
    }
    if (hasLoginKeyInput || hasPasswordInput || loginButton || onLoginPage) {
      return "NEED_LOGIN";
    }
    if (loginLink && isShopeeHomeUrl(href)) {
      return "NEED_LOGIN";
    }
    return "UNKNOWN";
  }

  async function waitForLoginOutcome(timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    let postLoginNavbarWaitStarted = 0;
    while (Date.now() < deadline) {
      const href = location.href;
      const onPostLoginHome = href.includes("is_from_login=true") && !href.toLowerCase().includes("/buyer/login");
      if (onPostLoginHome) {
        if (!postLoginNavbarWaitStarted) {
          postLoginNavbarWaitStarted = Date.now();
          await closePostLoginPopupsTwoRounds({ popupWaitMs: POST_LOGIN_POPUP_WAIT_MS });
          await window.ShopeeAutomationBridge.log("info", `LOGIN_POST_REDIRECT href=${href}`);
        }
        if (findNavbarUsername()) {
          const popupClosed = await closePostLoginPopupsTwoRounds({ popupWaitMs: POST_LOGIN_POPUP_WAIT_MS });
          await window.ShopeeAutomationBridge.log("info", `LOGIN_SUCCESS_DETECTED href=${location.href} loginProof=true hasNavbarUsername=true`);
          return { status: "LOGGED_IN", state: "LOGGED_IN", popupClosed, loginProof: true, hasNavbarUsername: true, hasLoginLink: false, loginDetect: "post_redirect_navbar" };
        }
        if (Date.now() - postLoginNavbarWaitStarted > 28000) {
          await window.ShopeeAutomationBridge.log("info", `LOGIN_NAVBAR_TIMEOUT href=${location.href}`);
          return { status: "NEED_LOGIN", state: "NEED_LOGIN", loginProof: false, hasNavbarUsername: false, hasLoginLink: !!findLoginLink(), message: "NAVBAR_AFTER_LOGIN_TIMEOUT", loginDetect: "navbar_timeout" };
        }
        await sleep(450);
        continue;
      }
      if (hasLoggedInProof()) {
        const popupClosed = await closePostLoginPopupsTwoRounds({ popupWaitMs: POST_LOGIN_POPUP_WAIT_MS });
        await window.ShopeeAutomationBridge.log("info", `LOGIN_SUCCESS_DETECTED href=${href} loginProof=true hasNavbarUsername=true`);
        return { status: "LOGGED_IN", state: "LOGGED_IN", popupClosed, loginProof: true, hasNavbarUsername: true, hasLoginLink: false, loginDetect: "navbar" };
      }
      if (await maybeRecoverVerifyTrafficLoginGate("wait_login_outcome")) {
        await sleep(500);
        continue;
      }
      const risk = inspectLoginPageRisk();
      if (risk) {
        await window.ShopeeAutomationBridge.log("info", `LOGIN_BLOCKED status=${risk.status} href=${risk.href}`);
        return { status: risk.status, state: risk.status, loginProof: false, href: risk.href, loginDetect: "inspectLoginPageRisk" };
      }
      const state = detectState();
      if (state === "NEED_OTP" || state === "NEED_VERIFY" || state === "NEED_CAPTCHA" || state === "ACCOUNT_LOCKED") {
        await window.ShopeeAutomationBridge.log("info", `LOGIN_BLOCKED status=${state} href=${location.href}`);
        return { status: state, state, loginProof: false, loginDetect: "detectState" };
      }
      await sleep(500);
    }
    const finalState = detectState();
    await window.ShopeeAutomationBridge.log("info", `LOGIN_WAIT_TIMEOUT state=${finalState} href=${location.href}`);
    return { status: finalState === "LOGGED_IN" && hasLoggedInProof() ? "LOGGED_IN" : "NEED_LOGIN", state: finalState, loginProof: hasLoggedInProof(), hasNavbarUsername: !!findNavbarUsername(), hasLoginLink: !!findLoginLink(), loginDetect: "timeout" };
  }

  async function waitForState(predicate, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const state = detectState();
      if (predicate(state)) return state;
      await sleep(700);
    }
    return detectState();
  }

  function setNativeInputValue(element, value) {
    const prototype = Object.getPrototypeOf(element);
    const descriptor = Object.getOwnPropertyDescriptor(prototype, "value");
    if (descriptor && descriptor.set) {
      descriptor.set.call(element, value);
    } else {
      element.value = value;
    }
  }

  async function humanType(element, value) {
    element.focus();
    setNativeInputValue(element, "");
    element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward", data: null }));
    const text = String(value || "");
    let current = "";
    for (const char of text) {
      current += char;
      setNativeInputValue(element, current);
      element.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: char }));
      element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertText", data: char }));
      element.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: char }));
      await sleep(45 + Math.floor(Math.random() * 85));
    }
    element.dispatchEvent(new Event("change", { bubbles: true }));
    element.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  async function waitForEnabledButton(button, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (button && !button.disabled && button.getAttribute("disabled") === null) {
        return true;
      }
      await sleep(300);
    }
    return !!button && !button.disabled;
  }


  function inputValueLength(element) {
    return element && typeof element.value === "string" ? element.value.length : 0;
  }

  async function refillLoginInputIfNeeded(element, value, label) {
    if (!element) return false;
    const expected = String(value || "");
    for (let attempt = 1; attempt <= 2; attempt++) {
      element.scrollIntoView({ behavior: "instant", block: "center" });
      element.focus();
      await sleep(80);
      await humanType(element, expected);
      await sleep(180);
      if (String(element.value || "") === expected) {
        return true;
      }
      setNativeInputValue(element, expected);
      element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertReplacementText", data: expected }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      element.dispatchEvent(new Event("blur", { bubbles: true }));
      await sleep(220);
      if (String(element.value || "") === expected) {
        return true;
      }
      await window.ShopeeAutomationBridge.log("info", `LOGIN_REFILL_RETRY field=${label} attempt=${attempt} valueLen=${inputValueLength(element)}`).catch(() => {});
    }
    return String(element.value || "") === expected;
  }

  async function dispatchLoginInputsReady(usernameInput, passwordInput) {
    for (const element of [usernameInput, passwordInput]) {
      if (!element) continue;
      element.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "insertReplacementText", data: element.value || "" }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      element.dispatchEvent(new Event("blur", { bubbles: true }));
    }
    await sleep(250);
  }

  async function submitLoginForm(loginButton, passwordInput) {
    const beforeHref = location.href;
    if (loginButton) {
      loginButton.scrollIntoView({ behavior: "smooth", block: "center" });
      await sleep(300);
      clickElementWithPointer(loginButton, true);
      await window.ShopeeAutomationBridge.log("info", "LOGIN_SUBMIT_CLICKED method=button").catch(() => {});
      await sleep(1800);
      if (location.href !== beforeHref || detectState() !== "NEED_LOGIN") {
        return "button";
      }
    }
    const form = passwordInput && passwordInput.closest ? passwordInput.closest("form") : findShopeeAuthLoginForm();
    if (form) {
      try {
        if (typeof form.requestSubmit === "function") {
          form.requestSubmit();
        } else {
          form.dispatchEvent(new Event("submit", { bubbles: true, cancelable: true }));
          if (typeof form.submit === "function") form.submit();
        }
        await window.ShopeeAutomationBridge.log("info", "LOGIN_SUBMIT_CLICKED method=form").catch(() => {});
        await sleep(1500);
        if (location.href !== beforeHref || detectState() !== "NEED_LOGIN") {
          return "form";
        }
      } catch (e) {
        await window.ShopeeAutomationBridge.log("info", `LOGIN_FORM_SUBMIT_FAILED ${String(e && e.message || e)}`).catch(() => {});
      }
    }
    if (passwordInput) {
      await pressEnter(passwordInput);
      await window.ShopeeAutomationBridge.log("info", "LOGIN_SUBMIT_CLICKED method=enter").catch(() => {});
      await sleep(1000);
      return "enter";
    }
    return "none";
  }

  function findSearchInput() {
    return findFirst([
      "input[aria-label='Search for products, brands and shops']",
      "input[aria-label*='Search']",
      "input[aria-label*='Tìm kiếm']",
      "input.shopee-searchbar-input__input",
      "input[role='combobox'][placeholder*='Search']",
      "input[role='combobox'][placeholder*='Tìm']",
      "input[placeholder*='Search for products']",
      "input[placeholder*='Tìm kiếm']",
      "form[action*='search'] input",
      "[class*='search'] input[type='text']"
    ]);
  }

  async function pressEnter(element) {
    element.focus();
    element.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, cancelable: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
    element.dispatchEvent(new KeyboardEvent("keypress", { bubbles: true, cancelable: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
    element.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, cancelable: true, key: "Enter", code: "Enter", keyCode: 13, which: 13 }));
    await sleep(800);
  }

  function firstVisibleIn(selectorList, root) {
    const host = root || document;
    for (const selector of selectorList) {
      const found = Array.from(host.querySelectorAll(selector)).find(visible);
      if (found) return found;
    }
    return null;
  }

  async function safeScrollIntoView(element) {
    if (!element) return;
    element.scrollIntoView({ behavior: "smooth", block: "center" });
    await sleep(600);
  }

  function findReviewSectionAnchor() {
    const selectors = [
      ".product-ratings__header_score",
      ".product-rating-overview__filter",
      ".product-rating-overview",
      ".product-rating-overview__filters",
      "[class*='product-ratings']",
      "[class*='rating-overview']",
      "[id*='review']",
      "section[class*='rating']"
    ];
    for (const selector of selectors) {
      const el = document.querySelector(selector);
      if (el && visible(el)) return el;
    }
    return Array.from(document.querySelectorAll("h2, h3, div, section"))
      .filter(visible)
      .find(el => {
        const text = (el.textContent || "").trim().toLowerCase();
        const normalized = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
        return text.includes("đánh giá") || normalized.includes("danh gia") || text.includes("product ratings") || text.includes("reviews");
      }) || null;
  }

  function isReviewSectionInView() {
    const anchor = findReviewSectionAnchor();
    if (!anchor) return false;
    const rect = anchor.getBoundingClientRect();
    const vh = window.innerHeight || document.documentElement.clientHeight || 800;
    return rect.top < vh * 0.85 && rect.bottom > 40;
  }

  async function scrollStepPixels(pixels) {
    const step = Math.max(80, Math.min(280, Number(pixels) || 200));
    window.scrollBy({ top: step, left: 0, behavior: "smooth" });
    await sleep(650 + Math.floor(Math.random() * 450));
  }

  async function scrollShopPageSmooth(maxMs) {
    const deadline = Date.now() + (maxMs || 28000);
    let steps = 0;
    const stepPx = 200;
    await window.ShopeeAutomationBridge.log("info", `SCROLL_SHOP_BEGIN stepPx=${stepPx}`);
    while (Date.now() < deadline) {
      const doc = document.documentElement;
      const maxScroll = Math.max(0, (doc.scrollHeight || 0) - (window.innerHeight || 800));
      if (window.scrollY >= maxScroll - 60) {
        await window.ShopeeAutomationBridge.log("info", `SCROLL_SHOP_DONE steps=${steps} reachedBottom=true`);
        return { steps, reachedBottom: true, stepPx };
      }
      await scrollStepPixels(stepPx);
      steps += 1;
      if (steps > 45) break;
    }
    await window.ShopeeAutomationBridge.log("info", `SCROLL_SHOP_DONE steps=${steps} reachedBottom=false`);
    return { steps, reachedBottom: false, stepPx };
  }

  async function scrollProductPageToReview(maxMs) {
    const deadline = Date.now() + (maxMs || 60000);
    let steps = 0;
    const stepPx = 200;
    await window.ShopeeAutomationBridge.log("info", `SCROLL_TO_REVIEW_BEGIN stepPx=${stepPx}`);
    while (Date.now() < deadline) {
      if (isReviewSectionInView()) {
        await window.ShopeeAutomationBridge.log("info", `SCROLL_TO_REVIEW_DONE steps=${steps} reachedReview=true`);
        return { status: "DONE", steps, reachedReview: true, stepPx };
      }
      const anchor = findReviewSectionAnchor();
      if (anchor) {
        const rect = anchor.getBoundingClientRect();
        const vh = window.innerHeight || 800;
        if (rect.top > 0 && rect.top < vh * 0.72) {
          await window.ShopeeAutomationBridge.log("info", `SCROLL_TO_REVIEW_DONE steps=${steps} reachedReview=true anchor`);
          return { status: "DONE", steps, reachedReview: true, stepPx };
        }
        if (rect.top > vh * 0.5) {
          const remaining = Math.min(stepPx, Math.max(120, Math.floor(rect.top - vh * 0.35)));
          await scrollStepPixels(remaining);
          steps += 1;
          continue;
        }
      }
      await scrollStepPixels(stepPx);
      steps += 1;
    }
    await window.ShopeeAutomationBridge.log("info", `SCROLL_TO_REVIEW_TIMEOUT steps=${steps} hasAnchor=${!!findReviewSectionAnchor()}`);
    return { status: "DONE", steps, reachedReview: isReviewSectionInView(), stepPx };
  }

  function findShopeeHeaderLogoClickTarget() {
    const wrapper = document.querySelector(".header-with-search__logo-wrapper");
    if (wrapper && visible(wrapper)) {
      const link = wrapper.closest("a") || wrapper.querySelector("a");
      if (link && visible(link)) return link;
      const svg = wrapper.querySelector("svg.header-with-search__shopee-logo, svg.icon-shopee-logo, svg.shopee-svg-icon");
      if (svg && visible(svg)) return svg.closest("a") || wrapper;
      return wrapper;
    }
    const svgLogo = document.querySelector("svg.header-with-search__shopee-logo, svg.icon-shopee-logo");
    if (svgLogo && visible(svgLogo)) {
      const host = svgLogo.closest(".header-with-search__logo-wrapper") || svgLogo.closest("a") || svgLogo.parentElement;
      if (host && visible(host)) return host.closest("a") || host;
    }
    const homeLink = Array.from(document.querySelectorAll("a[href='https://shopee.vn/'], a[href='/']"))
      .find(a => visible(a) && (a.querySelector(".header-with-search__logo-wrapper") || a.querySelector("svg.icon-shopee-logo")));
    return homeLink || null;
  }

  async function clickShopeeHomeLogo() {
    const deadline = Date.now() + 12000;
    while (Date.now() < deadline) {
      const target = findShopeeHeaderLogoClickTarget();
      if (target) {
        await safeScrollIntoView(target);
        clickElementWithPointer(target, true);
        await window.ShopeeAutomationBridge.log("info", "HOME_LOGO_CLICKED");
        await sleep(1200);
        await emitContentReadyIfStable();
        return { ok: true, method: "logo" };
      }
      await sleep(400);
    }
    await window.ShopeeAutomationBridge.log("info", "HOME_LOGO_NOT_FOUND fallback url");
    await openUrl("https://shopee.vn/");
    return { ok: true, method: "url_fallback" };
  }

  function clickElement(element) {
    if (!element) return false;
    element.dispatchEvent(new MouseEvent("mouseover", { bubbles: true }));
    element.dispatchEvent(new MouseEvent("mousemove", { bubbles: true }));
    element.dispatchEvent(new MouseEvent("mousedown", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent("mouseup", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new MouseEvent("click", { bubbles: true, cancelable: true }));
    return true;
  }

  function clickElementWithPointer(element, invokeNativeClick = true) {
    if (!element) return false;
    const rect = element.getBoundingClientRect();
    const clientX = Math.max(1, Math.floor(rect.left + rect.width / 2));
    const clientY = Math.max(1, Math.floor(rect.top + rect.height / 2));
    const eventInit = { bubbles: true, cancelable: true, view: window, clientX, clientY, screenX: clientX, screenY: clientY, button: 0, buttons: 1 };
    if (typeof PointerEvent === "function") {
      element.dispatchEvent(new PointerEvent("pointerover", { ...eventInit, pointerId: 1, pointerType: "mouse", isPrimary: true }));
      element.dispatchEvent(new PointerEvent("pointerenter", { ...eventInit, pointerId: 1, pointerType: "mouse", isPrimary: true }));
      element.dispatchEvent(new PointerEvent("pointermove", { ...eventInit, pointerId: 1, pointerType: "mouse", isPrimary: true }));
      element.dispatchEvent(new PointerEvent("pointerdown", { ...eventInit, pointerId: 1, pointerType: "mouse", isPrimary: true }));
    }
    element.dispatchEvent(new MouseEvent("mouseover", eventInit));
    element.dispatchEvent(new MouseEvent("mousemove", eventInit));
    element.dispatchEvent(new MouseEvent("mousedown", eventInit));
    if (typeof PointerEvent === "function") {
      element.dispatchEvent(new PointerEvent("pointerup", { ...eventInit, pointerId: 1, pointerType: "mouse", isPrimary: true }));
    }
    element.dispatchEvent(new MouseEvent("mouseup", eventInit));
    element.dispatchEvent(new MouseEvent("click", { ...eventInit, buttons: 0, detail: 1 }));
    if (invokeNativeClick && typeof element.click === "function") element.click();
    return true;
  }

  async function waitForVisibleSelector(selectors, timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      const found = firstVisibleIn(selectors);
      if (found) return found;
      await sleep(250);
    }
    return null;
  }

  function visibleElements(selectorList, root) {
    const host = root || document;
    return selectorList.flatMap(selector => Array.from(host.querySelectorAll(selector))).filter(visible);
  }

  function pickRandomElement(list) {
    if (!list || !list.length) return null;
    return list[Math.floor(Math.random() * list.length)];
  }

  function isVariationSection(section) {
    if (!section || !section.querySelector("button.sApkZm, button.selection-box-unselected, button.selection-box-selected")) {
      return false;
    }
    const title = ((section.querySelector("h2.Dagtcd, h2") || {}).textContent || "").trim().toLowerCase();
    if (!title) return true;
    if (title.includes("số lượng") || title.includes("so luong") || title.includes("quantity")) return false;
    return true;
  }

  async function selectRandomProductVariations() {
    const groups = Array.from(document.querySelectorAll("section.flex.items-center, section[class*='items-center']"))
      .filter(isVariationSection);
    let selected = 0;
    const picks = [];
    for (const group of groups) {
      const options = Array.from(group.querySelectorAll("button.sApkZm, button.selection-box-unselected, button.selection-box-selected"))
        .filter(button => visible(button) && button.getAttribute("aria-disabled") !== "true" && !button.disabled);
      const preferUnselected = options.filter(button => button.classList.contains("selection-box-unselected"));
      const pool = (preferUnselected.length ? preferUnselected : options);
      const option = pickRandomElement(pool);
      if (option) {
        const label = option.getAttribute("aria-label") || (option.textContent || "").trim().slice(0, 40);
        await safeScrollIntoView(option);
        if (clickElement(option)) {
          selected += 1;
          picks.push(label);
        }
        await sleep(350 + Math.floor(Math.random() * 250));
      }
    }
    if (picks.length) {
      await window.ShopeeAutomationBridge.log("info", `VARIATION_RANDOM picks=${picks.join("|")}`);
    }
    return selected;
  }

  function findAddToCartButton() {
    const bySelector = firstVisibleIn([
      "button.btn.btn-tinted.btn--l",
      "button.btn-tinted.btn--l",
      "button[aria-label*='add to cart']",
      "button[aria-label*='Add to cart']",
      "button[aria-label*='thêm vào giỏ']",
      "button[aria-label*='Thêm vào giỏ']",
      "button.btn-tinted",
      "button[class*='btn-tinted']"
    ]);
    if (bySelector) return bySelector.closest("button") || bySelector;
    const buttons = Array.from(document.querySelectorAll("button[aria-disabled='false'], button:not([aria-disabled='true'])"));
    const byText = buttons.find(btn => {
      if (!visible(btn)) return false;
      const text = (btn.textContent || "").trim().toLowerCase();
      return text.includes("thêm vào giỏ hàng") || text.includes("thêm vào giỏ") || text.includes("add to cart");
    });
    if (byText) return byText;
    const spans = Array.from(document.querySelectorAll("span"));
    for (const span of spans) {
      const text = (span.textContent || "").trim().toLowerCase();
      if (!text.includes("thêm vào giỏ")) continue;
      const parent = span.closest("button");
      if (parent && visible(parent) && parent.getAttribute("aria-disabled") !== "true" && !parent.disabled) {
        return parent;
      }
    }
    return findButtonByText(["thêm vào giỏ hàng", "add to cart", "thêm vào giỏ"]);
  }

  async function tryEnableCartQuantity() {
    const qtyInput = document.querySelector("input[role='spinbutton'][aria-valuenow], input.suQW3X.u00pLG, .shopee-input-quantity input[type='text']");
    if (!qtyInput || !qtyInput.disabled) return;
    const inc = qtyInput.closest(".shopee-input-quantity, ._9m0o30")?.querySelector("button[aria-label='Increase'], button[aria-label*='Increase']");
    if (inc && !inc.disabled && visible(inc)) {
      clickElementWithPointer(inc, true);
      await sleep(400);
    }
  }

  async function openUrl(url) {
    if (!url) return;
    if (location.href !== url) {
      location.href = url;
      await sleep(1500);
    }
  }

  async function taskOpenHome(task) {
    if (hasInlineLoginForm() || isOnBuyerLoginPage()) {
      await window.ShopeeAutomationBridge.log("info", "OPEN_HOME_ALREADY_ON_LOGIN");
      return needLoginTaskResult({ popupClosed: false });
    }
    if (isTrafficErrorUrl()) {
      const gateClicked = isVerifyTrafficLoginGatePage();
      await window.ShopeeAutomationBridge.log("info", `OPEN_HOME_TRAFFIC_GATE_TO_LOGIN gateClicked=${gateClicked}`);
      return await reportNeedLoginThenNavigateToBuyerLogin(task, { popupClosed: false, gateClicked, loginFormReady: false });
    }
    const viaLogo = !!(task && task.viaLogo);
    const forceNavigate = !!(task && task.forceNavigateHome);
    const compactViewport = window.innerWidth < 320 || window.innerHeight < 240;
    const alreadyOnHome = isShopeeHomeUrl(location.href);
    if (viaLogo && !alreadyOnHome) {
      const logoResult = await clickShopeeHomeLogo();
      await waitForState(() => document.readyState === "complete" || document.readyState === "interactive", 12000);
    } else if (!alreadyOnHome || forceNavigate) {
      if (!isTrafficErrorUrl()) {
        const before = location.href;
        await openUrl("https://shopee.vn/");
        if (location.href !== before && !isTrafficErrorUrl()) {
          await waitForState(() => document.readyState === "complete" || document.readyState === "interactive", 8000);
          if (!isTrafficErrorUrl()) {
            await emitContentReadyIfStable();
          }
        }
      }
    } else {
      await window.ShopeeAutomationBridge.log("info", "OPEN_HOME_SKIP_NAVIGATE already on home");
      await sleep(500);
    }
    if (isTrafficErrorUrl() || hasInlineLoginForm() || isOnBuyerLoginPage()) {
      const gateClicked = isVerifyTrafficLoginGatePage();
      await window.ShopeeAutomationBridge.log("info", `OPEN_HOME_TRAFFIC_GATE_TO_LOGIN gateClicked=${gateClicked}`);
      if (hasInlineLoginForm() || isOnBuyerLoginPage()) {
        return needLoginTaskResult({ popupClosed: 0, gateClicked, loginFormReady: hasInlineLoginForm() });
      }
      return await reportNeedLoginThenNavigateToBuyerLogin(task, { popupClosed: 0, gateClicked, loginFormReady: false });
    }
    let popupClosed = 0;
    const popupAttempts = compactViewport ? 1 : 1;
    const popupWaitMs = compactViewport ? 400 : 800;
    popupClosed = await closeHomePopup(popupAttempts, { popupWaitMs, useGlobalClose: true });
    if (isTrafficErrorUrl() || hasInlineLoginForm()) {
      return needLoginTaskResult({ popupClosed });
    }
    const proof = hasLoggedInProof();
    const state = proof ? "LOGGED_IN" : detectState();
    if (!proof && (state === "NEED_CAPTCHA" || state === "ACCOUNT_LOCKED")) {
      return await reportNeedLoginThenNavigateToBuyerLogin(task, { message: "PRE_LOGIN_RISK_TO_LOGIN", risk: state, popupClosed });
    }
    return { status: "DONE", state, loginProof: proof, popupClosed, popupStillVisible: isHomePopupVisible(), hasLoginLink: !!findLoginLink(), hasNavbarUsername: !!findNavbarUsername() };
  }

  async function taskCheckLogin(task) {
    if (task && task.reloadAfterCookies) {
      if (hasInlineLoginForm()) {
        const proof = hasLoggedInProof();
        if (proof) {
          return { status: "LOGGED_IN", state: "LOGGED_IN", loginProof: true, hasNavbarUsername: !!findNavbarUsername(), hasLoginLink: false };
        }
        return needLoginTaskResult({ message: "INLINE_LOGIN_FORM_AFTER_COOKIES", loginFormReady: true });
      }
      const captchaHref = isCaptchaRiskHref(location.href);
      const proof = hasLoggedInProof();
      const onLogin = isOnLoginFormSurface();
      const trafficErr = isTrafficErrorUrl();
      if (captchaHref && !proof) {
        return await reportNeedLoginThenNavigateToBuyerLogin(task, {
          message: "PRE_LOGIN_RISK_TO_LOGIN",
          risk: "NEED_CAPTCHA",
          loginFormReady: false
        });
      }
      if (onLogin || trafficErr || captchaHref) {
        location.reload();
        await sleep(900);
      } else if (!proof) {
        return await reportNeedLoginThenNavigateToBuyerLogin(task, {
          message: "PRE_LOGIN_RISK_TO_LOGIN",
          loginFormReady: false
        });
      } else {
        await openUrl("https://shopee.vn/");
        await sleep(700);
      }
    }
    if (task && task.awaitLoginForm) {
      const prep = await waitForInlineLoginForm(10000, 250, "check_login_await");
      const ready = prep || hasInlineLoginForm();
      return needLoginTaskResult({
        message: ready ? "TRAFFIC_LOGIN_FORM_READY" : "TRAFFIC_LOGIN_FORM_PENDING",
        loginFormReady: ready,
        loginFormPartial: ready && !hasInlineLoginForm() ? false : undefined
      });
    }
    if (hasInlineLoginForm() || isOnBuyerLoginPage()) {
      return needLoginTaskResult({
        message: "INLINE_LOGIN_FORM",
        loginFormReady: true
      });
    }
    if (isVerifyTrafficLoginGatePage() || isTrafficErrorUrl()) {
      return await reportNeedLoginThenNavigateToBuyerLogin(task, {
        message: "TRAFFIC_GATE_OPENED",
        loginFormReady: false,
        gateOpened: true
      });
    }
    const riskEarly = inspectLoginPageRisk();
    if (riskEarly) {
      if (!hasLoggedInProof()) {
        return await reportNeedLoginThenNavigateToBuyerLogin(task, {
          message: "PRE_LOGIN_RISK_TO_LOGIN",
          risk: riskEarly.status,
          loginFormReady: false
        });
      }
      await window.ShopeeAutomationBridge.log("info", `LOGIN_BLOCKED status=${riskEarly.status} href=${riskEarly.href} reason=${riskEarly.reason || ""}`);
      return { status: riskEarly.status, state: riskEarly.status, loginProof: false, href: riskEarly.href, hasLoginLink: !!findLoginLink(), hasNavbarUsername: !!findNavbarUsername() };
    }
    const popupClosed = await closeHomePopup(1, { popupWaitMs: 600, useGlobalClose: true });
    const hasLoginLink = !!findLoginLink();
    const hasNavbarUsername = !!findNavbarUsername();
    const loginProof = hasLoggedInProof();
    const state = loginProof ? "LOGGED_IN" : (hasLoginLink ? "NEED_LOGIN" : detectState());
    if (!loginProof && (state === "NEED_CAPTCHA" || state === "ACCOUNT_LOCKED")) {
      return await reportNeedLoginThenNavigateToBuyerLogin(task, { message: "PRE_LOGIN_RISK_TO_LOGIN", risk: state });
    }
    await window.ShopeeAutomationBridge.log("info", `CHECK_LOGIN resolved=${state} loginProof=${loginProof} hasLoginLink=${hasLoginLink} hasNavbarUsername=${hasNavbarUsername}`);
    const out = { status: state, state, loginProof: loginProof && hasNavbarUsername && !hasLoginLink, popupClosed, popupStillVisible: isHomePopupVisible(), hasLoginLink, hasNavbarUsername };
    return out;
  }

  async function taskImportCookies(task) {
    const cookieText = task.cookie || task.cookieText || "";
    if (!cookieText.trim()) {
      return { status: "SKIPPED", state: detectState(), imported: 0, skipped: 0, spcFExpected: "", spcFActual: "", spcFMatched: false };
    }
    const result = await window.ShopeeAutomationBridge.importCookies(cookieText) || { imported: 0, skipped: 0, spcFExpected: "", spcFActual: "", spcFMatched: false };
    await sleep(600);
    const out = {
      status: "DONE",
      state: detectState(),
      imported: result.imported || 0,
      skipped: result.skipped || 0,
      spcFExpected: result.spcFExpected || "",
      spcFActual: result.spcFActual || "",
      spcFMatched: !!result.spcFMatched
    };
    return out;
  }

  function normalizeShopeeLoginUser(raw) {
    return String(raw || "").replace(/xdf/g, "").replace(/nlv/g, "");
  }

  async function taskLoginWithPassword(task) {
    const loginDeadline = Date.now() + 48000;
    const loginTimedOut = () => Date.now() >= loginDeadline;
    let navigatedAttempts = 0;
    await window.ShopeeAutomationBridge.log("info", "LOGIN_WAIT_FORM stage=login_with_password").catch(() => {});

    while (!isOnBuyerLoginPage() && !hasInlineLoginForm() && !loginTimedOut()) {
      const traffic = isVerifyTrafficLoginGatePage() || isTrafficErrorUrl();
      const navResult = {
        status: "NAVIGATED_LOGIN",
        state: "NEED_LOGIN",
        message: traffic ? "traffic_gate_to_buyer_login" : "await_buyer_login_page",
        targetUrl: DEFAULT_BUYER_LOGIN_URL
      };
      navigatedAttempts += 1;
      await window.ShopeeAutomationBridge.log("info", `LOGIN_NAVIGATE_DIRECT attempt=${navigatedAttempts} traffic=${traffic ? 1 : 0} href=${location.href}`).catch(() => {});
      await navigate(DEFAULT_BUYER_LOGIN_URL);
      await waitForInlineLoginForm(12000, 300, `login_nav_${navigatedAttempts}`);
      if (navigatedAttempts >= 3) {
        return navResult;
      }
    }

    await ensureBuyerLoginPageReady("login_with_password");

    let fields = { userEl: null, passEl: null, probe: null };
    for (let attempt = 1; attempt <= 3 && !loginTimedOut(); attempt++) {
      await closeLoginPagePopupsQuick();
      const waitBudget = Math.max(6000, Math.min(18000, loginDeadline - Date.now()));
      fields = await waitForUsableLoginFields(waitBudget);
      if (fields.userEl && fields.passEl) break;
      const probe = fields.probe || probeLoginFormFields();
      await window.ShopeeAutomationBridge.log(
        "info",
        `LOGIN_FORM_RETRY attempt=${attempt} hasUser=${probe.hasUser} hasPass=${probe.hasPass} domKey=${probe.domKeyCount} iframes=${probe.iframeCount} href=${location.href}`
      ).catch(() => {});
      if (isVerifyTrafficLoginGatePage() || isTrafficErrorUrl() || isOnBuyerLoginPage()) {
        await navigate(DEFAULT_BUYER_LOGIN_URL);
        await waitForInlineLoginForm(12000, 300, `login_form_retry_${attempt}`);
      }
    }

    if (loginTimedOut()) {
      await window.ShopeeAutomationBridge.log("info", "LOGIN_FLOW_TIMEOUT stage=wait_form");
      return { status: "NEED_LOGIN", state: "NEED_LOGIN", message: "LOGIN_FLOW_TIMEOUT" };
    }

    let usernameInput = fields.userEl;
    let passwordInput = fields.passEl;
    if (!usernameInput || !passwordInput) {
      const probe = probeLoginFormFields();
      await window.ShopeeAutomationBridge.log(
        "info",
        `LOGIN_FORM_NOT_FOUND vw=${window.innerWidth} vh=${window.innerHeight} hasUser=${probe.hasUser} hasPass=${probe.hasPass} domKey=${probe.domKeyCount} iframes=${probe.iframeCount} href=${location.href}`
      );
      return { status: "NEED_LOGIN", state: detectState(), message: "LOGIN_FORM_NOT_FOUND", href: location.href, loginFormReady: probe.ready, loginFormPartial: probe.hasUser || probe.hasPass };
    }

    const userVal = normalizeShopeeLoginUser(task.user || task.username || "");
    const passVal = String(task.pass || task.password || "");
    const userFilled = await refillLoginInputIfNeeded(usernameInput, userVal, "user");
    const passFilled = await refillLoginInputIfNeeded(passwordInput, passVal, "pass");
    await dispatchLoginInputsReady(usernameInput, passwordInput);
    if (!userFilled || !passFilled || inputValueLength(usernameInput) !== userVal.length || inputValueLength(passwordInput) !== passVal.length) {
      await window.ShopeeAutomationBridge.log("info", `LOGIN_INPUT_FILL_INCOMPLETE userLen=${inputValueLength(usernameInput)} userExpected=${userVal.length} passLen=${inputValueLength(passwordInput)} passExpected=${passVal.length}`);
      return { status: "NEED_LOGIN", state: "NEED_LOGIN", message: "LOGIN_INPUT_FILL_INCOMPLETE", userValueLength: inputValueLength(usernameInput), passValueLength: inputValueLength(passwordInput) };
    }

    let loginButton = findLoginSubmitButton(passwordInput);
    if (!loginButton) {
      await dispatchLoginInputsReady(usernameInput, passwordInput);
      loginButton = findLoginSubmitButton(passwordInput);
    }
    if (!loginButton) {
      return { status: "NEED_LOGIN", state: "NEED_LOGIN", message: "LOGIN_BUTTON_NOT_FOUND", userValueLength: inputValueLength(usernameInput), passValueLength: inputValueLength(passwordInput) };
    }
    let enabled = await waitForEnabledButton(loginButton, 10000);
    if (!enabled) {
      await dispatchLoginInputsReady(usernameInput, passwordInput);
      await sleep(1200);
      enabled = await waitForEnabledButton(loginButton, 6000);
    }
    if (!enabled) {
      return { status: "NEED_LOGIN", state: "NEED_LOGIN", message: "LOGIN_BUTTON_DISABLED", userValueLength: inputValueLength(usernameInput), passValueLength: inputValueLength(passwordInput) };
    }

    const submitMethod = await submitLoginForm(loginButton, passwordInput);
    const immediateRiskDeadline = Date.now() + 5000;
    while (Date.now() < immediateRiskDeadline) {
      const risk = inspectLoginPageRisk();
      if (risk) {
        stopPostLoginRiskWatch();
        await window.ShopeeAutomationBridge.log("info", `LOGIN_BLOCKED status=${risk.status} href=${risk.href} source=login_submit`);
        return { status: risk.status, state: risk.status, loginProof: false, href: risk.href, loginDetect: "login_submit_risk" };
      }
      if (location.href.includes("is_from_login=true") || hasLoggedInProof()) {
        break;
      }
      await sleep(250);
    }
    startPostLoginRiskWatch();
    return { status: "LOGIN_SUBMITTED", state: "PENDING", message: "await_post_login_redirect", submitMethod };
  }

  async function taskPostLoginFinish() {
    await window.ShopeeAutomationBridge.log("info", `POST_LOGIN_BEGIN href=${location.href}`);
    const deadline = Date.now() + 22000;
    let postLoginPopupPasses = 0;
    while (Date.now() < deadline) {
      if (await maybeRecoverVerifyTrafficLoginGate("post_login_finish")) {
        return {
          status: "NEED_LOGIN",
          state: "NEED_LOGIN",
          loginProof: false,
          message: "TRAFFIC_VERIFY_GATE_TO_LOGIN",
          loginDetect: "post_login_finish_gate"
        };
      }
      const risk = inspectLoginPageRisk();
      if (risk) {
        stopPostLoginRiskWatch();
        await window.ShopeeAutomationBridge.log("info", `LOGIN_BLOCKED status=${risk.status} href=${risk.href}`);
        return { status: risk.status, state: risk.status, loginProof: false, href: risk.href, loginDetect: "post_login_finish" };
      }
      const loginProof = hasLoggedInProof();
      if (loginProof) {
        stopPostLoginRiskWatch();
        let popupClosed = 0;
        if (postLoginPopupPasses < 1) {
          await window.ShopeeAutomationBridge.log("info", "POST_LOGIN_ALREADY_LOGGED_IN");
          popupClosed = await closePostLoginPopupsTwoRounds({ popupWaitMs: 1200, skipBeginLog: true });
          postLoginPopupPasses += 1;
        }
        applyLoggedInCartBadgePrivacy();
        await window.ShopeeAutomationBridge.log("info", "LOGIN_SUCCESS_DETECTED post_login_finish");
        return { status: "LOGGED_IN", state: "LOGGED_IN", loginProof: true, hasNavbarUsername: true, hasLoginLink: false, popupClosed, loginDetect: "post_login_finish" };
      }
      const onPostLoginSurface =
        location.href.includes("is_from_login=true") ||
        (isShopeeHomeUrl(location.href) && !location.href.toLowerCase().includes("/buyer/login"));
      if (onPostLoginSurface && postLoginPopupPasses < 1) {
        await closePostLoginPopupsTwoRounds({ popupWaitMs: 2000 });
        postLoginPopupPasses += 1;
      }
      await sleep(400);
    }
    await window.ShopeeAutomationBridge.log("info", `POST_LOGIN_NAVBAR_TIMEOUT href=${location.href}`);
    return { status: "NEED_LOGIN", state: "NEED_LOGIN", loginProof: false, hasNavbarUsername: !!findNavbarUsername(), hasLoginLink: !!findLoginLink(), message: "NAVBAR_AFTER_LOGIN_TIMEOUT" };
  }

  async function taskWaitLoginResult() {
    return await taskPostLoginFinish();
  }

  async function searchNavigateAsync(searchUrl, keyword, method) {
    window.ShopeeAutomationBridge.navigate(searchUrl).catch(() => {});
    return { status: "NAVIGATING_SEARCH", keyword, searchUrl, method };
  }

  async function trySearchKeywordDomInput(keyword) {
    const onHomeLike = isShopeeHomeUrl(location.href) || location.href.includes("is_from_login");
    if (onHomeLike) {
      await closePostLoginPopupsTwoRounds({ popupWaitMs: 1200, skipBeginLog: true });
    }
    let searchInput = findSearchInput();
    if (!searchInput && onHomeLike) {
      searchInput = await waitForVisibleSelector([
        "input.shopee-searchbar-input__input",
        "input[aria-label*='Search']",
        "input[aria-label*='Tìm kiếm']",
        "input[placeholder*='Tìm kiếm']",
        "input[type='search']"
      ], 2500);
    }
    const popupBlocking = isHomePopupVisible() || !!findAnyPopupCloseButton();
    if (!searchInput || popupBlocking) {
      return { status: "FALLBACK", method: searchInput ? "FALLBACK_URL" : "URL_ONLY", popupBlocking };
    }
    searchInput.focus();
    await humanType(searchInput, keyword);
    await pressEnter(searchInput);
    await sleep(2000);
    const productCount = collectProductLinks().length;
    if (productCount > 0) {
      return { status: "DONE", keyword, method: "DOM_INPUT", products: productCount };
    }
    return { status: "FALLBACK", method: "FALLBACK_URL", popupBlocking: false };
  }

  async function taskSearchKeyword(task) {
    const keyword = String(task.keyword || "").trim() || "áo thun dài tay";
    const searchUrl = `https://shopee.vn/search?keyword=${encodeURIComponent(keyword)}`;
    if (task.forceUrl) {
      await window.ShopeeAutomationBridge.log("info", `SEARCH_FORCE_URL keyword=${keyword.slice(0, 40)}`);
      return await searchNavigateAsync(searchUrl, keyword, "FORCE_URL");
    }
    let domResult = null;
    try {
      domResult = await withTimeout(trySearchKeywordDomInput(keyword), SEARCH_DOM_INPUT_MAX_MS, "SEARCH_DOM_TIMEOUT");
      if (domResult && domResult.status === "DONE") {
        return domResult;
      }
    } catch (e) {
      await window.ShopeeAutomationBridge.log("info", `SEARCH_DOM_TIMEOUT keyword=${keyword.slice(0, 40)} reason=${String(e && e.message || e)}`);
    }
    const method = domResult && domResult.method ? domResult.method : "FALLBACK_URL";
    await window.ShopeeAutomationBridge.log("info", `SEARCH_FALLBACK_URL keyword=${keyword.slice(0, 40)} popup=${isHomePopupVisible()} method=${method}`);
    return await searchNavigateAsync(searchUrl, keyword, method);
  }

  const SERP_MAX_PRODUCTS_PER_PAGE = 60;

  function productIdsToToken(ids) {
    return ids && ids.shopId && ids.itemId ? `i.${ids.shopId}.${ids.itemId}`.toLowerCase() : "";
  }

  function normalizeProductTokenFromUrl(url) {
    return productIdsToToken(extractProductIds(url));
  }

  function extractProductImportantPart(href) {
    return normalizeProductTokenFromUrl(href);
  }

  function buildBm2StyleSerpRankingReport(productUrl, anchorList) {
    const links = anchorList || collectProductLinkAnchors();
    const targetToken = normalizeProductTokenFromUrl(productUrl);
    const normalized = [];
    const seen = new Set();
    for (const link of links) {
      const href = link.href || link.getAttribute("href") || "";
      const important = extractProductImportantPart(href);
      if (!important || seen.has(important)) continue;
      seen.add(important);
      normalized.push(important);
    }
    let targetPosition = 0;
    if (targetToken) {
      const idx = normalized.findIndex(part => normalizeProductTokenFromUrl(part) === targetToken);
      if (idx >= 0 && idx < SERP_MAX_PRODUCTS_PER_PAGE) {
        targetPosition = idx + 1;
      }
    }
    const pageSlice = normalized.slice(0, SERP_MAX_PRODUCTS_PER_PAGE);
    const items = pageSlice.map((part, i) => ({
      token: normalizeProductTokenFromUrl(part) || part,
      position: i + 1,
      isAd: false
    }));
    const summary = items.map(it => `${it.token}:${it.position}`).join(",");
    return {
      method: "dom_query_order_dedupe_dash_i_bm2",
      methodVi: "Thứ tự link trong DOM (như BM2), dedupe theo -i.shop.item, tối đa 60 SP/trang 1",
      page: 1,
      targetToken: targetToken || "",
      targetPosition,
      organicCount: pageSlice.length,
      uniqueTotal: normalized.length,
      items,
      summary
    };
  }

  function collectProductLinkAnchors() {
    return Array.from(document.querySelectorAll("a[href*='-i.'], a[href*='/i.'], a[href*='i.'], a[href*='/product/']"));
  }

  function collectSearchResultGridAnchors() {
    const selectors = [
      "li.shopee-search-item-result__item a[href*='-i.']",
      "li.shopee-search-item-result__item a[href*='/product/']",
      ".shopee-search-item-result__items a[href*='-i.']",
      ".shopee-search-item-result__items a[href*='/product/']",
      "[class*='search-item-result__item'] a[href*='-i.']"
    ];
    const seenEl = new Set();
    const anchors = [];
    for (const sel of selectors) {
      for (const a of document.querySelectorAll(sel)) {
        if (seenEl.has(a)) continue;
        seenEl.add(a);
        anchors.push(a);
      }
    }
    return anchors;
  }

  function pickPrimarySerpAnchorList() {
    const grid = collectSearchResultGridAnchors();
    if (grid.length >= 3) return { anchors: grid, scope: "search_grid" };
    return { anchors: collectProductLinkAnchors(), scope: "document_fallback" };
  }

  function collectProductLinks() {
    const anchors = collectProductLinkAnchors();
    const urls = [];
    const tokens = new Set();
    for (const anchor of anchors) {
      const href = anchor.href || anchor.getAttribute("href") || "";
      if (!href) continue;
      const token = normalizeProductTokenFromUrl(href);
      if (!token) continue;
      const key = token;
      if (!tokens.has(key)) {
        tokens.add(key);
        urls.push(href.startsWith("http") ? href : new URL(href, location.origin).href);
      }
    }
    return urls;
  }

  function extractProductIds(url) {
    const text = String(url || "");
    let match = text.match(/(?:-|\/)i\.(\d+)\.(\d+)/i) || text.match(/i\.(\d+)\.(\d+)/i);
    if (match) {
      return { shopId: match[1], itemId: match[2] };
    }
    match = text.match(/\/product\/(\d+)\/(\d+)/i);
    if (match) {
      return { shopId: match[1], itemId: match[2] };
    }
    return null;
  }

  function findMatchingProductUrl(targetUrl, productUrls) {
    const targetIds = extractProductIds(targetUrl);
    if (!targetIds) {
      return "";
    }
    return productUrls.find(url => {
      const ids = extractProductIds(url);
      return ids && ids.shopId === targetIds.shopId && ids.itemId === targetIds.itemId;
    }) || "";
  }

  function findProductAnchorByUrl(targetUrl) {
    const targetToken = normalizeProductTokenFromUrl(targetUrl);
    if (!targetToken) {
      const matchUrl = findMatchingProductUrl(targetUrl, collectProductLinks());
      if (!matchUrl) return null;
      return collectProductLinkAnchors().find(a => {
        const h = a.href || "";
        return h === matchUrl || h.split("?")[0] === matchUrl.split("?")[0];
      }) || null;
    }
    const anchors = collectProductLinkAnchors();
    return anchors.find(a => {
      const href = a.href || a.getAttribute("href") || "";
      return normalizeProductTokenFromUrl(href) === targetToken;
    }) || null;
  }

  function isShopeeSearchResultsPage(href) {
    const u = String(href || location.href || "");
    if (!u.includes("shopee.vn")) return false;
    if (u.includes("/search")) return true;
    if (/[?&]keyword=/i.test(u)) return true;
    return false;
  }

  function isProductHref(href) {
    const h = String(href || "").toLowerCase();
    return /-i\.\d+\.\d+/.test(h) || /\/product\/\d+\/\d+/.test(h) || /i\.\d+\.\d+/.test(h);
  }

  function getSearchKeywordLabel(task) {
    const fromTask = String((task && task.keyword) || "").trim();
    if (fromTask) return fromTask;
    try {
      const u = new URL(location.href);
      return decodeURIComponent(u.searchParams.get("keyword") || "").trim();
    } catch (e) {
      return "";
    }
  }

  function escapeLogQuotedText(text) {
    return String(text || "").replace(/"/g, "'");
  }

  function isLikelySearchAdProductAnchor(anchor) {
    if (!anchor) return false;
    const href = String(anchor.href || anchor.getAttribute("href") || "").toLowerCase();
    if (href.includes("sp_atk")) return true;
    const text = (anchor.textContent || "").toLowerCase();
    if (/\bad\b/.test(text) || text.includes("iklan") || text.includes("广告")) return true;
    return !!anchor.querySelector("[class*='nWEmLb'], [class*='dELyIc'], [class*='q4tMnz']");
  }

  function orderSerpProductAnchors(anchors) {
    return anchors.slice().sort((a, b) => {
      const ra = a.getBoundingClientRect();
      const rb = b.getBoundingClientRect();
      const rowA = Math.round((ra.top + ra.height * 0.5) / 100);
      const rowB = Math.round((rb.top + rb.height * 0.5) / 100);
      if (rowA !== rowB) return rowA - rowB;
      if (Math.abs(ra.top - rb.top) > 8) return ra.top - rb.top;
      return ra.left - rb.left;
    });
  }

  function getSerpOrganicProductRank(productUrl) {
    const report = buildSerpOrganicRankingReport(productUrl);
    return { position: report.targetPosition, serpTotal: report.organicCount };
  }

  function buildSerpOrganicRankingReport(productUrl, anchorList, scopeLabel) {
    const targetToken = normalizeProductTokenFromUrl(productUrl);
    const ordered = orderSerpProductAnchors(anchorList || pickPrimarySerpAnchorList().anchors);
    const seen = new Set();
    const items = [];
    let rank = 0;
    let targetPosition = 0;
    for (const a of ordered) {
      const href = a.href || a.getAttribute("href") || "";
      const t = normalizeProductTokenFromUrl(href);
      const isAd = isLikelySearchAdProductAnchor(a);
      if (!t || seen.has(t)) continue;
      seen.add(t);
      if (!isAd) {
        rank += 1;
        items.push({ token: t, position: rank, isAd: false });
        if (targetToken && t === targetToken) targetPosition = rank;
      } else {
        items.push({ token: t, position: 0, isAd: true });
      }
    }
    if (targetToken && targetPosition <= 0 && items.some(it => it.token === targetToken && !it.isAd)) {
      targetPosition = items.find(it => it.token === targetToken && !it.isAd).position;
    }
    const organic = items.filter(it => !it.isAd);
    const summary = organic.map(it => `${it.token}:${it.position}`).join(",");
    const scope = scopeLabel || "search_grid";
    return {
      method: scope === "search_grid" ? "grid_visual_skip_ads" : "visual_row_sort_skip_ads_dedupe_token",
      methodVi: scope === "search_grid"
        ? "Chỉ ô trong lưới kết quả tìm kiếm (shopee-search-item-result), sắp hàng/trái, bỏ QC"
        : "Sắp link SP theo vị trí màn hình (hàng/trái), bỏ QC/sp_atk, mỗi i.shop.item một lần",
      page: 1,
      scope,
      targetToken: targetToken || "",
      targetPosition: clampSerpPageOnePosition(targetPosition),
      organicCount: Math.min(organic.length, SERP_MAX_PRODUCTS_PER_PAGE),
      items: organic.slice(0, SERP_MAX_PRODUCTS_PER_PAGE),
      summary: organic.slice(0, SERP_MAX_PRODUCTS_PER_PAGE).map(it => `${it.token}:${it.position}`).join(",")
    };
  }

  function clampSerpPageOnePosition(position) {
    const p = parseInt(position, 10) || 0;
    if (p <= 0) return 0;
    if (p > SERP_MAX_PRODUCTS_PER_PAGE) return 0;
    return p;
  }

  function resolveSerpPositionForProduct(productUrl, serpContext) {
    const { anchors, scope } = pickPrimarySerpAnchorList();
    const organic = buildSerpOrganicRankingReport(productUrl, anchors, scope);
    const organicPos = clampSerpPageOnePosition(organic.targetPosition);
    if (serpContext && serpContext.capturedSerp && serpContext.capturedPosition > 0) {
      const capped = clampSerpPageOnePosition(serpContext.capturedPosition);
      if (capped > 0) {
        return {
          position: capped,
          serp: serpContext.capturedSerp,
          rankMode: serpContext.capturedRankMode || "captured"
        };
      }
    }
    if (organicPos > 0) {
      return { position: organicPos, serp: organic, rankMode: scope === "search_grid" ? "grid_organic" : "organic_doc" };
    }
    const bm2 = buildBm2StyleSerpRankingReport(productUrl, anchors);
    if (bm2.targetPosition > 0) {
      return { position: bm2.targetPosition, serp: bm2, rankMode: "bm2_fallback" };
    }
    return { position: 0, serp: organic, rankMode: "none" };
  }

  function getProductRankOnSearchPage(productUrl) {
    return getSerpOrganicProductRank(productUrl).position;
  }

  async function logSearchProductFound(task, productUrl, page) {
    const kw = escapeLogQuotedText(getSearchKeywordLabel(task));
    const pos = getProductRankOnSearchPage(productUrl);
    const pg = Math.max(1, parseInt(page, 10) || 1);
    await window.ShopeeAutomationBridge.log("info", `SEARCH_PRODUCT_FOUND keyword="${kw}" position=${pos} page=${pg}`);
  }

  async function logSearchProductNotFound(task, page) {
    const kw = escapeLogQuotedText(getSearchKeywordLabel(task));
    const pg = Math.max(1, parseInt(page, 10) || 1);
    await window.ShopeeAutomationBridge.log("info", `SEARCH_PRODUCT_NOT_FOUND keyword="${kw}" page=${pg}`);
  }

  function findProductAnchorAtVitri(vitri) {
    const pos = Math.max(1, parseInt(vitri, 10) || 1);
    const anchors = collectProductLinkAnchors()
      .filter(a => {
        const href = a.href || a.getAttribute("href") || "";
        return href && normalizeProductTokenFromUrl(href);
      });
    const seen = new Set();
    const ordered = [];
    for (const a of anchors) {
      const key = a.href.split("?")[0];
      if (seen.has(key)) continue;
      seen.add(key);
      ordered.push(a);
    }
    return ordered[pos - 1] || null;
  }

  function isSearchPaginationVisible() {
    const nav = document.querySelector("nav.shopee-page-controller[role='navigation']") ||
      document.querySelector("nav[role='navigation'].shopee-page-controller") ||
      document.querySelector("nav[role='navigation']");
    const nextBtn = findSearchNextPageButton();
    const check = el => {
      if (!el || !visible(el)) return false;
      const rect = el.getBoundingClientRect();
      const vh = window.innerHeight || 800;
      return rect.top <= vh + 50 && rect.bottom >= -50;
    };
    return check(nav) || check(nextBtn);
  }

  function isSearchPaginationControlEnabled(el) {
    if (!el || !visible(el)) return false;
    if (el.disabled) return false;
    const aria = (el.getAttribute("aria-disabled") || "").toLowerCase();
    return aria !== "true";
  }

  function resolveSearchPaginationHref(hrefRaw) {
    const raw = String(hrefRaw || "").trim();
    if (!raw || raw === "#") return "";
    try {
      return new URL(raw, location.href).toString();
    } catch (e) {
      return "";
    }
  }

  function getSearchPageIndexFromLocation() {
    try {
      const u = new URL(location.href);
      const p = u.searchParams.get("page");
      if (p === null || p === "") return 0;
      const n = parseInt(p, 10);
      return Number.isFinite(n) && n >= 0 ? n : 0;
    } catch (e) {
      return 0;
    }
  }

  function findSearchNextPageButton() {
    const selectors = [
      "a.shopee-icon-button.shopee-icon-button--right",
      "nav.shopee-page-controller a.shopee-icon-button--right",
      "nav.shopee-page-controller .shopee-icon-button--right",
      "nav.shopee-page-controller button.shopee-icon-button--right",
      "button.shopee-icon-button.shopee-icon-button--right",
      "a.shopee-button-outline.shopee-mini-page-controller__next-btn",
      "a.shopee-mini-page-controller__next-btn"
    ];
    for (const sel of selectors) {
      const el = document.querySelector(sel);
      if (!isSearchPaginationControlEnabled(el)) continue;
      if (el.tagName === "A" && el.getAttribute("href")) {
        return el;
      }
      const wrapped = el.closest("a[href], button");
      if (wrapped && isSearchPaginationControlEnabled(wrapped)) {
        return wrapped;
      }
      return el;
    }
    return null;
  }

  async function scrollSearchPageStep200(maxSteps) {
    const stepPx = 200;
    const limit = Math.max(1, maxSteps || 40);
    let steps = 0;
    while (steps < limit) {
      if (isSearchPaginationVisible()) {
        return { steps, reachedPagination: true, stepPx };
      }
      const doc = document.documentElement;
      const maxScroll = Math.max(0, (doc.scrollHeight || 0) - (window.innerHeight || 800));
      if (window.scrollY >= maxScroll - 40) {
        return { steps, reachedPagination: isSearchPaginationVisible(), stepPx };
      }
      await scrollStepPixels(stepPx);
      steps += 1;
    }
    return { steps, reachedPagination: isSearchPaginationVisible(), stepPx };
  }

  function getSearchResultListSignature() {
    const links = collectProductLinks();
    return links.slice(0, 5).join("|");
  }

  function resolveMaxSearchPages(task) {
    const fromTask = parseInt(task && task.maxSearchPages, 10);
    if (Number.isFinite(fromTask) && fromTask > 0) {
      return Math.max(1, fromTask);
    }
    const fromConfig = parseInt(config && config.maxSearchPages, 10);
    if (Number.isFinite(fromConfig) && fromConfig > 0) {
      return Math.max(1, fromConfig);
    }
    return 1;
  }

  function getSearchKeywordFromLocation() {
    try {
      const u = new URL(location.href);
      return decodeURIComponent(u.searchParams.get("keyword") || "").trim();
    } catch (e) {
      return "";
    }
  }

  /** Shopee SERP: `page` trong URL là chỉ số 0-based (trang 1 không có page; trang 2 → page=1, khớp href nút Next). */
  function buildShopeeSearchPageUrl(displayPageOneBased) {
    const pageIndex = Math.max(0, (parseInt(displayPageOneBased, 10) || 1) - 1);
    try {
      const u = new URL(location.href);
      if (pageIndex <= 0) {
        u.searchParams.delete("page");
      } else {
        u.searchParams.set("page", String(pageIndex));
      }
      return u.toString();
    } catch (e) {
      const kw = getSearchKeywordFromLocation();
      if (!kw) return "";
      const base = `https://shopee.vn/search?keyword=${encodeURIComponent(kw)}`;
      return pageIndex <= 0 ? base : `${base}&page=${pageIndex}`;
    }
  }

  function findSearchNextPageHrefFromDom() {
    const ctrl = findSearchNextPageButton();
    if (!ctrl || ctrl.tagName !== "A") return "";
    return resolveSearchPaginationHref(ctrl.getAttribute("href"));
  }

  function searchPageIndexIncreased(beforePageIndex) {
    const before = beforePageIndex != null ? beforePageIndex : 0;
    return getSearchPageIndexFromLocation() > before;
  }

  async function waitForSearchResultsChange(beforeSig, timeoutMs, beforePageIndex) {
    const pageBefore = beforePageIndex != null ? beforePageIndex : getSearchPageIndexFromLocation();
    const deadline = Date.now() + (timeoutMs || 14000);
    while (Date.now() < deadline) {
      await sleep(400);
      if (!isShopeeSearchResultsPage(location.href)) continue;
      if (getSearchPageIndexFromLocation() > pageBefore) {
        return true;
      }
      const afterSig = getSearchResultListSignature();
      if (afterSig && afterSig !== beforeSig && getSearchPageIndexFromLocation() !== pageBefore) {
        return true;
      }
    }
    return searchPageIndexIncreased(pageBefore);
  }

  async function trySpaNavigateToSearchUrl(targetUrl) {
    const target = String(targetUrl || "").trim();
    if (!target || !/\/search/i.test(target)) {
      return { ok: false, reason: "BAD_SEARCH_URL" };
    }
    const beforePageIndex = getSearchPageIndexFromLocation();
    const beforeSig = getSearchResultListSignature();
    try {
      const nextUrl = new URL(target, location.href);
      history.pushState(history.state, "", nextUrl.pathname + nextUrl.search);
      window.dispatchEvent(new PopStateEvent("popstate", { state: history.state }));
    } catch (e) {
      return { ok: false, reason: "SPA_PUSH_FAIL" };
    }
    const deadline = Date.now() + 12000;
    while (Date.now() < deadline) {
      await sleep(350);
      if (searchPageIndexIncreased(beforePageIndex)) {
        return { ok: true, reason: "SPA_PUSHSTATE" };
      }
      const sig = getSearchResultListSignature();
      if (sig && sig !== beforeSig && searchPageIndexIncreased(beforePageIndex)) {
        return { ok: true, reason: "SPA_PUSHSTATE_SIG" };
      }
    }
    if (searchPageIndexIncreased(beforePageIndex)) {
      return { ok: true, reason: "SPA_PUSHSTATE_LATE" };
    }
    return { ok: false, reason: "SPA_NO_PAGE_CHANGE" };
  }

  async function goToSearchPaginationUrl(hrefOrUrl) {
    const raw = String(hrefOrUrl || "").trim();
    const target = raw.startsWith("http") ? raw : resolveSearchPaginationHref(raw);
    if (!target || !/\/search/i.test(target)) {
      return { ok: false, reason: "BAD_SEARCH_URL" };
    }
    const spa = await trySpaNavigateToSearchUrl(target);
    if (spa.ok) {
      return spa;
    }
    const beforePageIndex = getSearchPageIndexFromLocation();
    const nextCtrl = findSearchNextPageButton();
    if (nextCtrl) {
      try {
        nextCtrl.scrollIntoView({ block: "center", inline: "nearest" });
      } catch (e) {
      }
      await sleep(250);
      if (typeof nextCtrl.click === "function") {
        nextCtrl.click();
      } else {
        clickElement(nextCtrl);
      }
      const waited = await waitForSearchResultsChange(getSearchResultListSignature(), 14000, beforePageIndex);
      if (waited && searchPageIndexIncreased(beforePageIndex)) {
        return { ok: true, reason: "RETRY_NEXT_CLICK" };
      }
    }
    return { ok: false, reason: spa.reason || "PAGINATION_NAV_FAIL" };
  }

  function normalizeSearchNextStepResult(raw, fallbackReason) {
    const r = raw && typeof raw === "object" ? raw : {};
    const ok = r.ok === true;
    let reason = String(r.reason || "").trim();
    if (!reason) {
      reason = fallbackReason || (ok ? "NEXT_OK" : "NEXT_FAIL");
    }
    return { ok, reason };
  }

  async function clickSearchNextPageButton() {
    const scrollInfo = await scrollSearchPageStep200(45);
    const nextCtrl = findSearchNextPageButton();
    if (!nextCtrl) {
      return { ok: false, reason: "NO_NEXT_BUTTON" };
    }
    const beforeSig = getSearchResultListSignature();
    const beforePageIndex = getSearchPageIndexFromLocation();
    const clickTarget = nextCtrl.closest("a, button") || nextCtrl;
    const href = nextCtrl.tagName === "A" ? resolveSearchPaginationHref(nextCtrl.getAttribute("href")) : "";

    if (clickTarget && typeof clickTarget.click === "function") {
      try {
        clickTarget.scrollIntoView({ block: "center", inline: "nearest" });
      } catch (e) {
      }
      await sleep(200);
      clickTarget.click();
      let changed = await waitForSearchResultsChange(beforeSig, 14000, beforePageIndex);
      if (changed && searchPageIndexIncreased(beforePageIndex)) {
        return { ok: true, reason: "NEXT_NATIVE_CLICK" };
      }
    }

    if (href && /\/search/i.test(href)) {
      await window.ShopeeAutomationBridge.log("info", `SEARCH_NEXT_VIA_HREF page_index_before=${beforePageIndex}`);
      const assignRes = await goToSearchPaginationUrl(href);
      if (assignRes.ok) {
        return { ok: true, reason: assignRes.reason || "NEXT_ANCHOR_HREF" };
      }
      return { ok: false, reason: assignRes.reason || "NEXT_HREF_NO_CHANGE" };
    }

    clickElement(clickTarget);
    const changed = await waitForSearchResultsChange(beforeSig, 12000, beforePageIndex);
    return changed ? { ok: true, reason: "NEXT_SYNTH_CLICK" } : { ok: false, reason: "SIGNATURE_UNCHANGED" };
  }

  async function navigateToSearchDisplayPage(displayPageOneBased) {
    const targetUrl = buildShopeeSearchPageUrl(displayPageOneBased);
    if (!targetUrl) {
      return { ok: false, reason: "BAD_URL" };
    }
    const beforeSig = getSearchResultListSignature();
    await window.ShopeeAutomationBridge.log("info", `SEARCH_GOTO_PAGE url_page_index=${Math.max(0, displayPageOneBased - 1)} display=${displayPageOneBased}`);
    const assignRes = await goToSearchPaginationUrl(targetUrl);
    if (assignRes.ok) {
      return { ok: true, reason: assignRes.reason || "URL_NAV" };
    }
    if (isShopeeSearchResultsPage(location.href) && collectProductLinks().length > 0
      && getSearchPageIndexFromLocation() === Math.max(0, displayPageOneBased - 1)) {
      return { ok: true, reason: "URL_NAV_SAME_SIG" };
    }
    return { ok: false, reason: assignRes.reason || "URL_NAV_TIMEOUT" };
  }

  function getSearchPageIndexForDisplay(displayPageOneBased) {
    return Math.max(0, (parseInt(displayPageOneBased, 10) || 1) - 1);
  }

  function isOnSearchDisplayPage(displayPageOneBased) {
    return getSearchPageIndexFromLocation() === getSearchPageIndexForDisplay(displayPageOneBased);
  }

  /** Sau khi bấm Next từ trang hiển thị `from`, URL phải là `page=(from-1)` (vd. từ trang 1 → page=1). */
  function hasAdvancedToNextSearchDisplayPage(fromDisplayPageOneBased) {
    const from = Math.max(1, parseInt(fromDisplayPageOneBased, 10) || 1);
    return getSearchPageIndexFromLocation() === from;
  }

  async function ensureOnSearchDisplayPage(displayPageOneBased) {
    const want = getSearchPageIndexForDisplay(displayPageOneBased);
    const cur = getSearchPageIndexFromLocation();
    if (cur === want) {
      return { ok: true, reason: "ALREADY_ON_DISPLAY" };
    }
    if (cur > want) {
      const back = await trySpaNavigateToSearchUrl(buildShopeeSearchPageUrl(displayPageOneBased));
      if (back.ok && isOnSearchDisplayPage(displayPageOneBased)) {
        return { ok: true, reason: "CORRECTED_FROM_OVERSHOOT" };
      }
    }
    if (cur < want && want - cur === 1) {
      const step = await clickSearchNextPageButton();
      if (step && step.ok && isOnSearchDisplayPage(displayPageOneBased)) {
        return { ok: true, reason: step.reason || "SINGLE_STEP_NEXT" };
      }
    }
    return { ok: false, reason: `PAGE_MISMATCH cur=${cur} want=${want}` };
  }

  async function clickSearchNextPage(fromDisplayPage) {
    const fromPage = Math.max(1, parseInt(fromDisplayPage, 10) || 1);
    if (isOnSearchDisplayPage(fromPage + 1)) {
      return { ok: true, reason: "ALREADY_ON_NEXT_PAGE" };
    }
    const nextDisplay = fromPage + 1;
    let byButton = { ok: false, reason: "NEXT_STEP_FAIL" };
    try {
      byButton = normalizeSearchNextStepResult(await clickSearchNextPageButton(), "BUTTON_STEP");
    } catch (err) {
      byButton = { ok: false, reason: "BUTTON_THROW:" + String(err && err.message || err).slice(0, 40) };
    }
    if (byButton.ok) {
      return byButton;
    }
    const failReason = byButton.reason || "NEXT_STEP_FAIL";
    const domHref = findSearchNextPageHrefFromDom();
    if (domHref && /\/search/i.test(domHref)) {
      await window.ShopeeAutomationBridge.log(
        "info",
        `SEARCH_NEXT_FALLBACK_DOM_HREF from=${fromDisplayPage} reason=${failReason}`
      );
      const retry = normalizeSearchNextStepResult(await goToSearchPaginationUrl(domHref), "DOM_HREF");
      if (retry.ok) {
        return retry;
      }
    }
    await window.ShopeeAutomationBridge.log(
      "info",
      `SEARCH_NEXT_FALLBACK_URL from=${fromDisplayPage} to=${nextDisplay} reason=${failReason}`
    );
    let urlNav = { ok: false, reason: "URL_NAV_TIMEOUT" };
    try {
      urlNav = normalizeSearchNextStepResult(await navigateToSearchDisplayPage(nextDisplay), "URL_NAV");
    } catch (err) {
      urlNav = { ok: false, reason: "URL_NAV_THROW:" + String(err && err.message || err).slice(0, 40) };
    }
    if (urlNav.ok) {
      return urlNav;
    }
    if (isOnSearchDisplayPage(fromPage + 1)) {
      return { ok: true, reason: "PAGE_INDEX_AFTER_FAIL" };
    }
    return { ok: false, reason: urlNav.reason || failReason };
  }

  async function tryFindProductOnCurrentSearchPage(task, productUrl, searchPage, methodIfFound) {
    await window.ShopeeAutomationBridge.log(
      "info",
      `SEARCH_SCAN_BEGIN page=${searchPage} target=${productUrl ? "linkSanpham" : "none"}`
    );

    if (productUrl) {
      if (searchPage > 1) {
        window.scrollTo({ top: 0, behavior: "auto" });
        await sleep(350);
      }
      await waitForProducts(8000);
      let anchor = findProductAnchorByUrl(productUrl);
      if (anchor) {
        return await navigateToProductFromSearch(anchor, productUrl, methodIfFound || "MATCH_SCROLL_CLICK", task, searchPage);
      }

      await window.ShopeeAutomationBridge.log("info", `SEARCH_PRODUCT_NOT_ON_PAGE page=${searchPage} scrolling_to_pagination`);
      const scrollInfo = await scrollSearchPageStep200(45);
      await window.ShopeeAutomationBridge.log(
        "info",
        `SEARCH_SCROLL_PAGINATION page=${searchPage} steps=${scrollInfo.steps} reached=${scrollInfo.reachedPagination}`
      );

      anchor = findProductAnchorByUrl(productUrl);
      if (anchor) {
        return await navigateToProductFromSearch(anchor, productUrl, "MATCH_AFTER_SCROLL", task, searchPage);
      }
      return null;
    }

    if (searchPage > 1) {
      return null;
    }

    const vitri = task.vitri;
    const useVitri = vitri != null && vitri !== "" && Number(vitri) > 0;
    if (useVitri) {
      const anchor = findProductAnchorAtVitri(vitri);
      if (anchor) {
        return await navigateToProductFromSearch(anchor, anchor.href, "VITRI_SCROLL_CLICK", task, 1);
      }
    }

    const links = collectProductLinks();
    if (links.length) {
      const first = Array.from(document.querySelectorAll("a[href*='-i.']")).find(a => visible(a) && a.href === links[0]);
      if (first) {
        return await navigateToProductFromSearch(first, first.href, "FIRST_SCROLL_CLICK", task, 1);
      }
    }

    await scrollSearchPageStep200(45);
    return { status: "TIMEOUT", message: "PRODUCT_NOT_FOUND", domProducts: links.length };
  }

  function isAnchorRoughlyInView(el) {
    if (!el) return false;
    const rect = el.getBoundingClientRect();
    const vh = window.innerHeight || 800;
    return rect.width > 0 && rect.height > 0 && rect.top < vh * 0.92 && rect.bottom > 8;
  }

  async function quickBringAnchorToView(el) {
    if (!el) return;
    if (isAnchorRoughlyInView(el)) return;
    el.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" });
    await sleep(280);
    if (!isAnchorRoughlyInView(el)) {
      el.scrollIntoView({ block: "center", inline: "nearest", behavior: "auto" });
      await sleep(200);
    }
  }

  async function scrollToElementSmooth(el) {
    if (!el) return;
    await quickBringAnchorToView(el);
  }

  async function clickSearchNextPage() {
    const next = findSearchNextPageButton();
    if (!next) return false;
    await scrollToElementSmooth(next);
    const clicked = clickElementWithPointer(next, true);
    await sleep(1800);
    return clicked;
  }

  function extractProductIdToken(url) {
    return normalizeProductTokenFromUrl(url);
  }

  function isShopeeBrowsingHost(href) {
    try {
      const host = new URL(String(href || ""), location.href).hostname.toLowerCase();
      return host.includes("shopee");
    } catch (e) {
      return false;
    }
  }

  function isFacebookLinkWarningPage(href) {
    const h = String(href || location.href || "").toLowerCase();
    try {
      const host = new URL(h, location.href).hostname.toLowerCase();
      if (!host.includes("facebook.com")) return false;
      return h.includes("/flx/warn") || h.includes("l.facebook.com/l.php");
    } catch (e) {
      return h.includes("facebook.com") && h.includes("/flx/warn");
    }
  }

  function isLikelyProductPageUrl(href) {
    const h = String(href || "");
    if (!isShopeeBrowsingHost(h)) return false;
    return !!extractProductIds(h);
  }

  function urlMatchesProductTarget(currentHref, productUrl, productIdHint) {
    const cur = String(currentHref || "");
    const target = String(productUrl || "");
    const token = normalizeProductTokenFromUrl(productIdHint) || productIdHint || extractProductIdToken(target);
    if (!isShopeeBrowsingHost(cur)) return false;
    if (!isLikelyProductPageUrl(cur)) return false;
    if (token && normalizeProductTokenFromUrl(cur) === String(token).toLowerCase()) return true;
    if (target) {
      const norm = target.split("?")[0];
      const pathPart = norm.replace(/^https?:\/\/[^/]+/i, "");
      if (pathPart && pathPart.length > 8 && cur.includes(pathPart)) return true;
    }
    return false;
  }

  function decodeFacebookRedirectTarget(href) {
    try {
      const url = new URL(href, location.href);
      const u = url.searchParams.get("u");
      if (u) return decodeURIComponent(u);
    } catch (e) {
      /* ignore */
    }
    return "";
  }

  async function readPendingFacebookProduct() {
    const res = await window.ShopeeAutomationBridge.getPendingFbProduct();
    return res && res.pending ? res.pending : null;
  }

  async function clearPendingFacebookProduct() {
    await window.ShopeeAutomationBridge.clearPendingFbProduct();
  }

  function resolveFacebookOutboundShopeeUrl(href) {
    const raw = String(href || "").trim();
    if (!raw) return "";
    let dest = decodeFacebookRedirectTarget(raw);
    if (!dest && raw.toLowerCase().includes("l.facebook.com/l.php")) {
      try {
        dest = decodeFacebookRedirectTarget(new URL(raw, location.href).href);
      } catch (e) {
        /* ignore */
      }
    }
    if (dest && dest.toLowerCase().includes("shopee")) return dest;
    return "";
  }

  function findFacebookFollowOrShopeeLink(productUrl, productIdHint) {
    const token = String(productIdHint || extractProductIdToken(productUrl) || "").trim().toLowerCase();
    const anchors = Array.from(document.querySelectorAll("a[href], a[role='button']")).filter(visible);
    const scored = [];
    for (const a of anchors) {
      const href = (a.getAttribute("href") || a.href || "").trim();
      if (!href || href === "#") continue;
      const lower = href.toLowerCase();
      const text = (a.textContent || "").trim().toLowerCase();
      const dest = resolveFacebookOutboundShopeeUrl(href);
      const decoded = dest.toLowerCase();
      const hrefToken = normalizeProductTokenFromUrl(href);
      const decodedToken = normalizeProductTokenFromUrl(dest);
      let score = 0;
      if (text.includes("follow link")) score += 120;
      if (a.getAttribute("role") === "button" && (lower.includes("l.facebook.com/l.php") || lower.includes("/flx/warn"))) score += 90;
      if (lower.includes("l.facebook.com/l.php")) score += 75;
      if (decoded) score += 95;
      if (token && (hrefToken === token || decodedToken === token || lower.includes(token) || decoded.includes(token))) score += 60;
      if (lower.includes("shopee.vn") || lower.includes("shopee")) score += 40;
      if (score > 0) scored.push({ a, score, href, dest });
    }
    scored.sort((x, y) => y.score - x.score);
    return scored.length ? scored[0] : null;
  }

  function findShopeeProductLinkOnRedirectPage(productIdHint) {
    const token = String(productIdHint || "").trim().toLowerCase();
    const selectorGroups = [];
    if (token) {
      selectorGroups.push(`a[href*="${token}"]`);
    }
    selectorGroups.push(
      "a[href*='shopee.vn'][href*='-i.']",
      "a[href*='shopee.vn'][href*='/product/']",
      "a[href*='shopee'][href*='-i.']",
      "a[href*='shopee'][href*='/product/']",
      "a[href*='shopee.vn']"
    );
    for (const sel of selectorGroups) {
      try {
        const anchors = Array.from(document.querySelectorAll(sel)).filter(visible);
        for (const a of anchors) {
          const href = a.href || "";
          const hrefToken = normalizeProductTokenFromUrl(href);
          if (href && token && hrefToken === token) {
            return a;
          }
          if (href && !token && (isLikelyProductPageUrl(href) || href.includes("shopee"))) {
            return a;
          }
        }
      } catch (e) {
        /* ignore invalid selector */
      }
    }
    const textAnchors = Array.from(document.querySelectorAll("a")).filter(a => {
      if (!visible(a)) return false;
      const text = (a.textContent || "").trim().toLowerCase();
      const textToken = normalizeProductTokenFromUrl(text);
      if (token && textToken) return textToken === token;
      return text.startsWith("https://sh") || text.startsWith("https://vn.sh") || text.includes("shopee.vn");
    });
    return textAnchors[0] || null;
  }

  async function startFacebookRedirectNavigation(productUrl, productIdHint) {
    const target = String(productUrl || "").trim();
    if (!target) {
      return { started: false };
    }
    const idHint = productIdHint || extractProductIdToken(target);
    const redirectUrl = `https://l.facebook.com/l.php?u=${encodeURIComponent(target)}`;
    await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_FB_REDIRECT_BEGIN");
    await window.ShopeeAutomationBridge.setPendingFbProduct({
      productUrl: target,
      idHint,
      ts: Date.now()
    });
    const nav = await navigate(redirectUrl);
    if (!nav || !nav.ok) {
      await clearPendingFacebookProduct();
      await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_FB_REDIRECT_FAIL reason=navigate_redirect");
      return { started: false };
    }
    return { started: true, productUrl: target };
  }

  async function actOnFacebookFollowLink(pick) {
    if (!pick || !pick.a) return false;
    const dest = pick.dest || resolveFacebookOutboundShopeeUrl(pick.href || pick.a.href);
    await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_FB_REDIRECT_CLICKED");
    if (dest) {
      await navigate(dest);
      return true;
    }
    clickElementWithPointer(pick.a, true);
    return true;
  }

  async function resumePendingFacebookProductOpen() {
    const host = (location.hostname || "").toLowerCase();
    if (!host.includes("facebook.com")) {
      return;
    }
    let pending = await readPendingFacebookProduct();
    const deadline = Date.now() + 45000;
    let acted = false;
    while (Date.now() < deadline) {
      if (!pending) {
        pending = await readPendingFacebookProduct();
      }
      const productUrl = pending ? pending.productUrl : "";
      const token = pending ? (pending.idHint || extractProductIdToken(pending.productUrl)) : "";

      if (!acted) {
        if (isFacebookLinkWarningPage(location.href)) {
          const warnDest = decodeFacebookRedirectTarget(location.href);
          if (warnDest && warnDest.toLowerCase().includes("shopee")) {
            if (!acted) {
              await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_FB_REDIRECT_CLICKED");
            }
            acted = true;
            await navigate(warnDest);
            await sleep(2200);
            continue;
          }
        }
        const pick = findFacebookFollowOrShopeeLink(productUrl, token);
        if (pick) {
          acted = await actOnFacebookFollowLink(pick);
          await sleep(2200);
          continue;
        }
      }

      if (isShopeeBrowsingHost(location.href) && pending && urlMatchesProductTarget(location.href, pending.productUrl, token)) {
        await clearPendingFacebookProduct();
        await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_FB_REDIRECT_OK");
        await emitContentReadyIfStable();
        return;
      }
      await sleep(500);
    }
    if (!pending) {
      pending = await readPendingFacebookProduct();
    }
    if (!pending) {
      await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_FB_REDIRECT_FAIL reason=no_pending");
      return;
    }
    await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_FB_REDIRECT_FAIL reason=interstitial_timeout");
    await clearPendingFacebookProduct();
    await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_DIRECT_FALLBACK");
    await navigate(pending.productUrl);
  }

  async function openProductUrlWithSoftRedirect(productUrl, productIdHint, extra) {
    const target = String(productUrl || "").trim();
    const extras = extra || {};
    const outcomeFields = {
      searchOutcome: extras.searchOutcome || "NOT_FOUND",
      keyword: extras.keyword || "",
      searchPage: extras.searchPage || 1,
      position: extras.position
    };
    const fb = await startFacebookRedirectNavigation(target, productIdHint);
    if (fb.started) {
      return {
        status: "NAVIGATING_PRODUCT",
        productUrl: target,
        method: "FACEBOOK_REDIRECT",
        message: extras.message || "FB_INTERSTITIAL",
        domProducts: extras.domProducts,
        ...outcomeFields
      };
    }

    await window.ShopeeAutomationBridge.log("info", "OPEN_PRODUCT_DIRECT_FALLBACK");
    await navigate(target);
    return {
      status: "NAVIGATING_PRODUCT",
      productUrl: target,
      method: "DIRECT_PRODUCT_URL",
      message: extras.message || "DIRECT_AFTER_FB_FAIL",
      domProducts: extras.domProducts,
      ...outcomeFields
    };
  }

  function buildSearchOutcomeFound(task, productUrl, searchPage, serpContext) {
    const pg = Math.max(1, parseInt(searchPage, 10) || 1);
    const resolved = resolveSerpPositionForProduct(productUrl, serpContext);
    const serp = resolved.serp || buildBm2StyleSerpRankingReport(productUrl);
    const position = clampSerpPageOnePosition(resolved.position);
    const kw = getSearchKeywordLabel(task);
    const organicItems = serp.items ? serp.items.filter(it => !it.isAd) : [];
    const serpRanking = (organicItems.length ? organicItems : (serp.items || []))
      .map(it => ({ token: it.token, position: it.position }));
    return {
      searchOutcome: "FOUND",
      keyword: kw,
      position,
      searchPage: pg,
      serpTotal: serp.organicCount,
      serpRankingMethod: serp.method,
      serpRankMode: resolved.rankMode || "",
      serpRankingSummary: serp.summary,
      serpRanking,
      serpTargetToken: serp.targetToken || normalizeProductTokenFromUrl(productUrl)
    };
  }

  function buildSearchOutcomeNotFound(task, searchPage, maxPagesScanned) {
    const pg = Math.max(1, parseInt(searchPage, 10) || 1);
    const maxP = Math.max(pg, parseInt(maxPagesScanned, 10) || pg);
    return {
      searchOutcome: "NOT_FOUND",
      keyword: getSearchKeywordLabel(task),
      searchPage: pg,
      maxSearchPagesScanned: maxP,
      maxSearchPagesLimit: resolveMaxSearchPages(task)
    };
  }

  async function scrollSearchSerpDownThenFocusProduct(anchor, productUrl) {
    const emptyCtx = { capturedPosition: 0, capturedSerp: null, capturedRankMode: "" };
    if (!isShopeeSearchResultsPage(location.href)) {
      return { anchor, serpContext: emptyCtx };
    }
    window.scrollTo({ top: 0, behavior: "auto" });
    await sleep(400);
    const atTopResolved = resolveSerpPositionForProduct(productUrl, null);
    await window.ShopeeAutomationBridge.log("info", "SEARCH_PRE_OPEN_SCROLL_BEGIN");
    const scrollInfo = await scrollSearchPageStep200(45);
    await window.ShopeeAutomationBridge.log(
      "info",
      `SEARCH_PRE_OPEN_SCROLL steps=${scrollInfo.steps} reached=${scrollInfo.reachedPagination}`
    );
    const afterScrollResolved = resolveSerpPositionForProduct(productUrl, null);
    const pickResolved = () => {
      const candidates = [
        { ...atTopResolved, capturedAt: "at_top_before_scroll" },
        { ...afterScrollResolved, capturedAt: "after_pre_open_scroll" }
      ].filter(c => c.position > 0);
      if (candidates.length) {
        candidates.sort((a, b) => a.position - b.position);
        return candidates[0];
      }
      return { ...afterScrollResolved, capturedAt: "after_pre_open_scroll" };
    };
    const picked = pickResolved();
    const serpContext = {
      capturedPosition: picked.position,
      capturedSerp: picked.serp,
      capturedRankMode: picked.rankMode,
      capturedLinkCount: collectProductLinks().length,
      capturedAt: picked.capturedAt || "after_pre_open_scroll"
    };
    window.scrollTo({ top: 0, behavior: "auto" });
    await sleep(450);
    let focused = findProductAnchorByUrl(productUrl) || anchor;
    if (focused) {
      await quickBringAnchorToView(focused);
      await sleep(350);
      focused = findProductAnchorByUrl(productUrl) || focused;
    }
    if (serpContext.capturedPosition <= 0 && focused) {
      const inViewResolved = resolveSerpPositionForProduct(productUrl, null);
      if (inViewResolved.position > 0) {
        serpContext.capturedPosition = inViewResolved.position;
        serpContext.capturedSerp = inViewResolved.serp;
        serpContext.capturedRankMode = inViewResolved.rankMode;
        serpContext.capturedAt = "after_focus_anchor";
      }
    }
    return { anchor: focused, serpContext };
  }

  async function navigateToProductFromSearch(anchor, productUrl, method, task, searchPage) {
    let openAnchor = anchor;
    let serpContext = null;
    if (openAnchor && productUrl && isShopeeSearchResultsPage(location.href)) {
      const prep = await scrollSearchSerpDownThenFocusProduct(openAnchor, productUrl);
      openAnchor = prep.anchor;
      serpContext = prep.serpContext;
    }
    const targetHref = String((openAnchor && (openAnchor.href || openAnchor.getAttribute("href"))) || productUrl || "").trim();
    const outcome = buildSearchOutcomeFound(task, productUrl, searchPage, serpContext);
    if (!targetHref) {
      return { status: "TIMEOUT", message: "PRODUCT_LINK_EMPTY", domProducts: collectProductLinks().length, ...outcome };
    }
    await navigate(targetHref);
    return {
      status: "NAVIGATING_PRODUCT",
      productUrl: targetHref,
      method,
      domProducts: collectProductLinks().length,
      ...outcome
    };
  }

  async function findAndOpenProductOnSearchResults(task) {
    const productUrlRaw = String(task.productUrl || "").trim();
    const productIdHint = String(task.productId || "").trim();
    const productUrl = normalizeProductTokenFromUrl(productIdHint) || productUrlRaw;
    const maxPages = resolveMaxSearchPages(task);
    let lastPageScanned = 1;

    await window.ShopeeAutomationBridge.log(
      "info",
      `SEARCH_MULTI_PAGE_BEGIN max=${maxPages} product=${productUrl ? "yes" : "no"}`
    );

    for (let page = 1; page <= maxPages; page += 1) {
      lastPageScanned = page;
      if (page > 1 && isShopeeSearchResultsPage(location.href)) {
        const jump = await ensureOnSearchDisplayPage(page);
        if (!jump.ok) {
          await window.ShopeeAutomationBridge.log(
            "info",
            `SEARCH_GOTO_PAGE_FAIL display=${page} reason=${jump.reason}`
          );
        }
      }
      window.scrollTo({ top: 0, behavior: "auto" });
      await sleep(page > 1 ? 450 : 0);

      const hit = await tryFindProductOnCurrentSearchPage(task, productUrl, page, "MATCH_SCROLL_CLICK");
      if (hit && (hit.status === "NAVIGATING_PRODUCT" || hit.productUrl)) {
        return hit;
      }
      if (hit && hit.status === "TIMEOUT") {
        return hit;
      }
      if (!productUrl) {
        break;
      }
      if (page >= maxPages) {
        break;
      }

      let next = normalizeSearchNextStepResult(await clickSearchNextPage(page), "LOOP_NEXT");
      if (!next.ok && isOnSearchDisplayPage(page + 1)) {
        next = { ok: true, reason: "PAGE_INDEX_ADVANCED" };
      }
      if (!next.ok) {
        await window.ShopeeAutomationBridge.log(
          "info",
          `SEARCH_NEXT_PAGE_FAIL from=${page} to=${page + 1} reason=${next && next.reason ? next.reason : "UNKNOWN"}`
        );
        break;
      }
      await window.ShopeeAutomationBridge.log(
        "info",
        `SEARCH_NEXT_PAGE_OK page=${page + 1} max=${maxPages} via=${next.reason}`
      );
      window.scrollTo({ top: 0, behavior: "auto" });
      await sleep(500);
    }

    if (productUrlRaw) {
      const notFound = buildSearchOutcomeNotFound(task, lastPageScanned, maxPages);
      const msg =
        maxPages <= 1
          ? "PRODUCT_NOT_ON_FIRST_SEARCH_PAGE"
          : `PRODUCT_NOT_IN_SEARCH_PAGES scanned=${lastPageScanned} limit=${maxPages}`;
      return await openProductUrlWithSoftRedirect(productUrlRaw, productUrl || extractProductIdToken(productUrlRaw), {
        message: msg,
        domProducts: collectProductLinks().length,
        ...notFound
      });
    }

    return { status: "TIMEOUT", message: "PRODUCT_NOT_FOUND", domProducts: collectProductLinks().length };
  }

  async function waitForProducts(timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    while (Date.now() < deadline) {
      if (collectProductLinks().length > 0) return true;
      await scrollStepPixels(200);
    }
    return false;
  }

  async function waitForProductDetail(timeoutMs) {
    const deadline = Date.now() + timeoutMs;
    const selectors = [".airUhU", ".YM40Nc", ".UBG7wZ", ".product-ratings__header_score", ".product-rating-overview__filter", "[class*='product-detail']", "button"];
    while (Date.now() < deadline) {
      if (firstVisibleIn(selectors)) return true;
      await sleep(600);
    }
    return false;
  }

  async function waitForProductGallery(timeoutMs) {
    const deadline = Date.now() + (timeoutMs || 20000);
    const gallerySelectors = [
      ".airUhU .UBG7wZ",
      ".airUhU",
      ".UBG7wZ",
      ".YM40Nc",
      "div.thumbnail-selected-mask",
      "[class*='image-carousel'] img",
      "[class*='product-detail'] video",
      "video"
    ];
    while (Date.now() < deadline) {
      for (const selector of gallerySelectors) {
        const el = Array.from(document.querySelectorAll(selector)).find(visible);
        if (el) return el;
      }
      const main = findMainProductMediaTarget();
      if (main) return main;
      await sleep(500);
    }
    return null;
  }

  function collectProductThumbnailItems() {
    const fromStrip = visibleElements([
      ".airUhU .UBG7wZ",
      ".airUhU button",
      ".airUhU [role='button']",
      ".UBG7wZ",
      ".YM40Nc",
      "div.thumbnail-selected-mask",
      "[class*='thumbnail'] img",
      "[class*='image-carousel'] img"
    ]);
    if (fromStrip.length) return fromStrip.slice(0, 6);
    const main = findMainProductMediaTarget();
    return main ? [main] : [];
  }

  async function taskOpenProduct(task) {
    const productUrlRaw = String(task.productUrl || "").trim();
    const productIdHint = String(task.productId || "").trim();
    const productUrl = normalizeProductTokenFromUrl(productIdHint) || productUrlRaw;
    const onSearch = isShopeeSearchResultsPage(location.href);
    const domCount = collectProductLinks().length;
    const maxPages = resolveMaxSearchPages(task);

    const shouldScanSearch =
      !isProductHref(location.href) &&
      (onSearch || (productUrl && maxPages > 1) || (domCount > 0 && productUrl));
    if (shouldScanSearch) {
      if (!domCount) {
        await waitForProducts(12000);
      }
      return await findAndOpenProductOnSearchResults(task);
    }

    let links = collectProductLinks();
    if (!links.length) {
      await waitForProducts(15000);
      links = collectProductLinks();
    }
    let selectedUrl = "";
    let method = "FIRST_DOM";
    if (productUrl) {
      const anchor = findProductAnchorByUrl(productUrl);
      if (anchor && (anchor.href || anchor.getAttribute("href"))) {
        selectedUrl = anchor.href || anchor.getAttribute("href");
        method = "MATCH_DOM_ANCHOR";
      } else {
        selectedUrl = findMatchingProductUrl(productUrl, links);
        if (selectedUrl) {
          method = "MATCH_DOM_ID";
        } else {
          selectedUrl = productUrlRaw || productUrl;
          method = "DIRECT_PRODUCT_URL";
        }
      }
    } else if (links.length) {
      selectedUrl = links[0];
    }
    if (!selectedUrl) {
      return { status: "TIMEOUT", message: "PRODUCT_NOT_FOUND", domProducts: links.length };
    }
    if (productUrl && method === "DIRECT_PRODUCT_URL") {
      return await openProductUrlWithSoftRedirect(selectedUrl, productUrl || extractProductIdToken(selectedUrl), {
        domProducts: links.length,
        message: "PRODUCT_NOT_IN_DOM",
        ...buildSearchOutcomeNotFound(task, 1)
      });
    }
    if (productUrl && method === "MATCH_DOM_ANCHOR") {
      const anchor = findProductAnchorByUrl(productUrl);
      if (anchor) {
        return await navigateToProductFromSearch(anchor, productUrl, "MATCH_DOM_ANCHOR", task, 1);
      }
    }
    await navigate(selectedUrl);
    return { status: "NAVIGATING_PRODUCT", productUrl: selectedUrl, method, domProducts: links.length, targetProductUrl: productUrl };
  }

  function isOnExpectedProductPage(productUrl) {
    const expected = normalizeProductTokenFromUrl(productUrl);
    if (!expected) return isProductHref(location.href);
    return isProductHref(location.href) && normalizeProductTokenFromUrl(location.href) === expected;
  }

  async function recoverProductPageContext(productUrl, reason, options) {
    if (isCaptchaRiskHref(location.href)) {
      await window.ShopeeAutomationBridge.log("info", `PRODUCT_PAGE_RECOVER_ABORT reason=captcha src=${reason || ""}`);
      return false;
    }
    const opts = options || {};
    const skipNavigate = !!opts.skipNavigate;
    const detailWaitMs = Math.max(2000, parseInt(opts.detailWaitMs, 10) || 8000);
    const target = String(productUrl || "").trim();
    await closeMediaLightbox();
    await closeHomePopup(2, { popupWaitMs: 600, useGlobalClose: true });
    await sleep(200);
    if (target && !isOnExpectedProductPage(target) && !skipNavigate) {
      await window.ShopeeAutomationBridge.log("info", `PRODUCT_PAGE_RECOVER_BEGIN reason=${reason || "unknown"}`);
      await navigate(target);
      await waitForProductDetail(detailWaitMs);
      await window.ShopeeAutomationBridge.log("info", "PRODUCT_PAGE_RECOVER_OK");
      return true;
    }
    if (target && !isOnExpectedProductPage(target) && skipNavigate) {
      await window.ShopeeAutomationBridge.log("info", `PRODUCT_PAGE_RECOVER_SKIP_NAV reason=${reason || "unknown"}`);
    }
    if (!target && !isProductHref(location.href)) {
      await window.ShopeeAutomationBridge.log("info", `PRODUCT_PAGE_RECOVER_SKIP reason=no_url href=${(location.href || "").slice(0, 80)}`);
    }
    return isOnExpectedProductPage(target) || isProductHref(location.href);
  }

  function findMediaLightbox() {
    const nodes = Array.from(document.querySelectorAll("[role='dialog'], .UCGJYT, .NDTw5b, .aUuKn4"));
    return nodes.find(el => {
      if (!visible(el)) return false;
      const r = el.getBoundingClientRect();
      if (r.width < 260 || r.height < 220) return false;
      return !!el.querySelector("img[alt='icon arrow right bold'], .RZy1Jt, .C2knlh, img[src*='susercontent'], video");
    }) || null;
  }

  function findMediaNextButton(root) {
    const host = root || findMediaLightbox() || document;
    const byAlt = Array.from(host.querySelectorAll("img[alt='icon arrow right bold']")).find(visible);
    if (byAlt) return byAlt.closest(".RZy1Jt") || byAlt.parentElement || byAlt;
    return firstVisibleIn([".RZy1Jt", ".C2knlh", "[role='dialog'] .C2knlh"], host);
  }

  function dispatchEscapeTo(target) {
    const el = target || document;
    const init = { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true, cancelable: true };
    try { el.dispatchEvent(new KeyboardEvent("keydown", init)); } catch (e) {}
    try { el.dispatchEvent(new KeyboardEvent("keyup", init)); } catch (e2) {}
  }

  async function waitForMediaLightbox(timeoutMs) {
    const deadline = Date.now() + (timeoutMs || 2200);
    while (Date.now() < deadline) {
      const found = findMediaLightbox();
      if (found) return found;
      await sleep(200);
    }
    return null;
  }

  async function closeMediaLightbox() {
    const closeSelectors = [
      ".aUuKn4 .dqUa8V",
      ".dqUa8V",
      "[role='dialog'] [class*='close']",
      "[role='dialog'] [aria-label*='close' i]",
      "[role='dialog'] [aria-label*='đóng' i]",
      "button[aria-label*='close']",
      "img[alt*='close' i]",
      ".UCGJYT button",
      ".aUuKn4 button",
      ".NDTw5b button"
    ];
    for (let retry = 0; retry < 5; retry += 1) {
      const dialog = findMediaLightbox();
      const closeButton = firstVisibleIn(closeSelectors, dialog || document);
      if (closeButton && clickElementWithPointer(closeButton.closest("button") || closeButton, true)) {
        await sleep(400);
        if (!findMediaLightbox()) {
          return true;
        }
      }
      if (dialog) {
        const r = dialog.getBoundingClientRect();
        const x = Math.min(window.innerWidth - 6, Math.max(6, r.right - 18));
        const y = Math.max(6, r.top + 18);
        const corner = document.elementFromPoint(x, y);
        if (corner) clickElementWithPointer(corner, true);
        dispatchEscapeTo(dialog);
      }
      try { document.body && document.body.focus(); } catch (e3) {}
      dispatchEscapeTo(window);
      dispatchEscapeTo(document);
      dispatchEscapeTo(document.body);
      await sleep(400);
      if (!findMediaLightbox()) {
        return true;
      }
    }
    return false;
  }

  async function runViewMediaPopupFlow(productUrl) {
    const flowDeadline = Date.now() + 26000;
    const flowTimedOut = () => Date.now() >= flowDeadline;
    const recoverLight = reason => recoverProductPageContext(productUrl, reason, { skipNavigate: true, detailWaitMs: 4000 });
    await window.ShopeeAutomationBridge.log("info", "VIEW_MEDIA_BEGIN");
    if (isCaptchaRiskHref(location.href)) {
      return { ok: false, status: "NEED_CAPTCHA", reason: "captcha" };
    }
    if (!isOnExpectedProductPage(productUrl)) {
      await recoverProductPageContext(productUrl, "before_view_media", { detailWaitMs: 10000 });
    }
    window.scrollTo({ top: 0, behavior: "auto" });
    await sleep(400);
    await closeHomePopup(2, { popupWaitMs: 800, useGlobalClose: true });
    const galleryReady = await waitForProductGallery(7000);
    if (!galleryReady) {
      await window.ShopeeAutomationBridge.log("info", "VIEW_MEDIA_FAIL no_gallery");
      await recoverLight("no_gallery");
      return { ok: false, reason: "no_gallery" };
    }
    if (flowTimedOut()) {
      await window.ShopeeAutomationBridge.log("info", "VIEW_MEDIA_FAIL flow_timeout");
      await recoverLight("flow_timeout_early");
      return { ok: false, reason: "flow_timeout" };
    }
    const mediaItems = collectProductThumbnailItems();
    let popup = null;
    let clicks = 0;
    const tryOpenPopup = async (target) => {
      if (!target) return null;
      await safeScrollIntoView(target);
      if (clickElementWithPointer(target.closest("button, a, div") || target, true)) clicks += 1;
      await sleep(400);
      const mainTarget = findMainProductMediaTarget();
      if (mainTarget && mainTarget !== target) {
        clickElementWithPointer(mainTarget, true);
        clicks += 1;
        await sleep(400);
      }
      return await waitForMediaLightbox(2200);
    };
    for (const item of mediaItems) {
      if (popup || flowTimedOut()) break;
      const inner = [item.querySelector(".thumbnail-selected-mask"), item.querySelector("img"), item.querySelector("video"), item].filter(Boolean);
      for (const t of inner) {
        if (flowTimedOut()) break;
        popup = await tryOpenPopup(t);
        if (popup) break;
      }
    }
    if (!popup) {
      popup = await tryOpenPopup(findMainProductMediaTarget());
    }
    if (!popup) {
      const carouselNext = await waitForVisibleSelector([".shopee-icon-button--right", "button.lWmpR1", "button[class*='icon-button'][class*='right']", ".C2knlh"], 3000);
      if (carouselNext) {
        for (let i = 0; i < 4; i += 1) {
          clickElementWithPointer(carouselNext.closest("button") || carouselNext, false);
          clicks += 1;
          await sleep(700);
          popup = await waitForMediaLightbox(1200);
          if (popup) break;
        }
      }
    }
    if (popup) {
      await sleep(1200);
      let nextClicks = 0;
      for (let i = 0; i < 3; i += 1) {
        if (flowTimedOut()) break;
        popup = findMediaLightbox() || popup;
        const nextButton = findMediaNextButton(popup) || await waitForVisibleSelector([
          "[role='dialog'] .RZy1Jt",
          ".RZy1Jt",
          "img[alt='icon arrow right bold']",
          "[role='dialog'] .C2knlh",
          ".NDTw5b .C2knlh",
          ".aUuKn4 .C2knlh"
        ], 800);
        if (!nextButton) {
          break;
        }
        clickElementWithPointer(nextButton.closest("button, .RZy1Jt") || nextButton, true);
        clicks += 1;
        nextClicks += 1;
        await sleep(1500);
      }
      const closed = await closeMediaLightbox();
      await recoverLight("after_popup");
      await window.ShopeeAutomationBridge.log("info", `VIEW_MEDIA_DONE method=popup clicks=${clicks} next=${nextClicks} closed=${closed ? 1 : 0}`);
      return { ok: true, method: "popup", clicks };
    }
    if (clicks > 0) {
      await recoverLight("after_inline");
      await window.ShopeeAutomationBridge.log("info", `VIEW_MEDIA_DONE method=inline clicks=${clicks}`);
      return { ok: true, method: "inline", clicks };
    }
    if (flowTimedOut()) {
      await window.ShopeeAutomationBridge.log("info", "VIEW_MEDIA_FAIL flow_timeout");
      await recoverLight("flow_timeout");
      return { ok: false, reason: "flow_timeout" };
    }
    await window.ShopeeAutomationBridge.log("info", "VIEW_MEDIA_FAIL no_interaction");
    await recoverLight("no_interaction");
    return { ok: false, reason: "no_interaction" };
  }

  function randomProductViewPauseSeconds(task) {
    const min = Math.max(1, Number(task.productViewPauseMin ?? 15));
    const max = Math.max(min + 1, Number(task.productViewPauseMax ?? 25));
    if (max <= min) {
      return min;
    }
    return min + Math.floor(Math.random() * (max - min));
  }

  async function taskScrollProduct(task) {
    const productUrl = String(task.productUrl || "").trim();
    if (productUrl && !isOnExpectedProductPage(productUrl)) {
      await recoverProductPageContext(productUrl, "before_scroll_product");
    }
    await waitForProductDetail(15000);
    await closeHomePopup(2, { popupWaitMs: 1500, useGlobalClose: true });
    const scrollResult = await scrollProductPageToReview(Number(task.maxScrollMs || 45000));
    const popupClosed = await closeHomePopup(2);
    const pauseSec = randomProductViewPauseSeconds(task);
    await window.ShopeeAutomationBridge.log("info", `PRODUCT_VIEW_PAUSE seconds=${pauseSec}`);
    await sleep(pauseSec * 1000);
    return { status: "DONE", phase: "scroll", popupClosed, productViewPauseSeconds: pauseSec, ...scrollResult };
  }

  async function taskInteractProduct(task) {
    const actions = task.actions || {};
    const phase = String(task.phase || "all");
    const productUrl = String(task.productUrl || "").trim();
    const completed = [];
    const failed = [];
    if (productUrl && !isOnExpectedProductPage(productUrl)) {
      await recoverProductPageContext(productUrl, "before_interact");
    }
    const detailReady = await waitForProductDetail(20000);
    await closeHomePopup(2, { popupWaitMs: 1500, useGlobalClose: true });
    if (!detailReady) {
      return { status: "DONE", phase, completed, failed: ["productDetail"], message: "PRODUCT_DETAIL_NOT_READY" };
    }

    if (phase === "review") {
      if (actions.review) {
        const review = findReviewSectionAnchor();
        if (review) {
          const reviewBlock = firstVisibleIn([".product-rating-overview", ".product-rating-overview__filters", "[class*='product-ratings']"]) || review;
          await safeScrollIntoView(reviewBlock);
          const filters = visibleElements([".product-rating-overview__filter"]);
          const isAllFilter = item => {
            const text = (item.textContent || "").trim().toLowerCase();
            const normalized = text.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
            return text === "all" || text === "tất cả" || normalized === "tat ca";
          };
          const defaultFilter = filters.find(isAllFilter) || filters[0] || null;
          const activeAll = defaultFilter && String(defaultFilter.className || "").includes("--active");
          if (defaultFilter && !activeAll) {
            clickElement(defaultFilter);
            await sleep(900);
          }
          const reviewMedia = visibleElements([".shopee-rating-media-list-image__content--blur", ".rating-media-list__image-wrapper"]).slice(0, 3);
          for (const item of reviewMedia) {
            await safeScrollIntoView(item);
            clickElement(item);
            await sleep(800);
          }
          completed.push("review");
        } else {
          failed.push("review");
        }
      }
      return { status: "DONE", phase: "review", completed, failed };
    }

    if (actions.viewMedia && (phase === "preScroll" || phase === "all")) {
      const flow = await runViewMediaPopupFlow(productUrl);
      if (flow.status === "NEED_CAPTCHA" || isCaptchaRiskHref(location.href)) {
        return { status: "NEED_CAPTCHA", state: "NEED_CAPTCHA", href: location.href, message: flow.reason || "captcha_during_view_media" };
      }
      if (flow.ok) {
        completed.push(flow.method === "popup" ? "viewMediaPopup" : "viewMediaInline");
        await sleep(500);
      } else {
        failed.push("viewMedia");
        if (productUrl) {
          await recoverProductPageContext(productUrl, "view_media_failed", { skipNavigate: true });
        }
      }
      const captchaAfterMedia = await abortInteractIfProductCaptcha("view_media");
      if (captchaAfterMedia) {
        return captchaAfterMedia;
      }
    }

    if (actions.like && (phase === "preScroll" || phase === "all")) {
      const like = firstVisibleIn(["button[aria-label*='favorite']", "button[aria-label*='like']", "button[title*='like']", "button.w2JMKY", "svg[class*='icon-like']", "svg[class*='like']", "[class*='like-button']", "[class*='love']"]);
      if (like) {
        const likeButton = like.closest("button") || like;
        const likeText = (likeButton.textContent || "").trim().toLowerCase();
        const filledHeart = !!likeButton.querySelector("path[fill='#FF424F'], path[fill='#ff424f']");
        const alreadyLiked = filledHeart || likeText.includes("đã thích") || likeText.includes("liked");
        if (alreadyLiked) {
          completed.push("likeAlready");
        } else {
          clickElement(likeButton);
          await window.ShopeeAutomationBridge.log("info", "LIKE_PRODUCT_CLICKED");
          completed.push("like");
          await sleep(1000);
        }
      } else {
        failed.push("like");
      }
    }

    if (actions.addToCart && (phase === "preScroll" || phase === "all")) {
      const variantCount = await selectRandomProductVariations();
      await tryEnableCartQuantity();
      await sleep(300);
      let add = findAddToCartButton();
      if (!add) {
        await safeScrollIntoView(document.querySelector(".flex.flex-column") || document.body);
        await sleep(400);
        add = findAddToCartButton();
      }
      if (!add) {
        await window.ShopeeAutomationBridge.log("info", `ADD_TO_CART_NOT_FOUND variants=${variantCount}`);
        failed.push("addToCart");
      } else if (add.disabled || add.getAttribute("aria-disabled") === "true") {
        await window.ShopeeAutomationBridge.log("info", "ADD_TO_CART_SKIPPED_DISABLED");
        failed.push("addToCart");
      } else {
        const label = (add.textContent || add.getAttribute("aria-label") || "").trim().slice(0, 60);
        await safeScrollIntoView(add);
        const clicked = clickElementWithPointer(add.closest("button") || add, true);
        await window.ShopeeAutomationBridge.log("info", `ADD_TO_CART_CLICKED clicked=${clicked} label=${label}`);
        await sleep(1200);
        completed.push("addToCart");
      }
    }

    if (actions.viewShop) {
      completed.push("viewShop");
    }
    if (actions.followShop) {
      completed.push("followShop");
    }
    return { status: "DONE", phase: phase === "preScroll" ? "preScroll" : "interact", completed, failed };
  }

  async function taskViewShop(task) {
    await waitForProductDetail(10000);
    const shop = findButtonByText(["xem shop", "view shop"]);
    if (!shop) {
      return { status: "DONE", failed: ["viewShop"] };
    }
    const beforeHref = location.href;
    await safeScrollIntoView(shop);
    clickElement(shop.closest("a, button") || shop);
    const deadline = Date.now() + 25000;
    while (Date.now() < deadline) {
      const href = location.href;
      if (href !== beforeHref && !href.includes("-i.")) {
        await emitContentReadyIfStable();
        return { status: "NAVIGATING_SHOP", shopUrl: href };
      }
      await sleep(400);
    }
    await emitContentReadyIfStable();
    return { status: "NAVIGATING_SHOP", shopUrl: location.href };
  }

  async function taskScrollShop(task) {
    await sleep(200);
    const info = await scrollShopPageSmooth(28000);
    return { status: "DONE", phase: "shopScroll", completed: ["shopScroll"], ...info };
  }

  async function taskFollowShop(task) {
    const actions = (task && task.actions) || {};
    const wantScroll = !!actions.viewShop;
    const follow = await waitForVisibleSelector(
      ["button.shopee-button-outline--fill", "button.shopee-button-outline", "button.shopee-button-outline--complement", "button[class*='follow']", "button[aria-label*='follow']"],
      5000
    ) || findButtonByText(["theo dõi", "follow"]);
    const completed = [];
    const failed = [];
    if (follow && /(^|\s)(theo dõi|follow)(\s|$)/i.test((follow.textContent || "").trim())) {
      await safeScrollIntoView(follow);
      clickElement(follow.closest("button") || follow);
      completed.push("followShop");
      await sleep(350);
    } else if (actions.followShop) {
      failed.push("followShop");
    }
    if (wantScroll) {
      await window.ShopeeAutomationBridge.log("info", "SHOP_SCROLL_AFTER_FOLLOW");
      const info = await scrollShopPageSmooth(28000);
      completed.push("shopScroll");
      return { status: "DONE", phase: "shopScroll", completed, failed, ...info };
    }
    if (completed.length) {
      return { status: "DONE", completed, failed };
    }
    return { status: "DONE", failed: failed.length ? failed : ["followShop"] };
  }

  const INTERACT_PRODUCT_MAX_MS = 75000;
  const LOGIN_TASK_MAX_MS = 55000;
  const SEARCH_KEYWORD_MAX_MS = 18000;
  const SEARCH_DOM_INPUT_MAX_MS = 10000;

  function withTimeout(promise, ms, label) {
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => reject(new Error(label || "TASK_TIMEOUT")), ms);
      Promise.resolve(promise).then(
        v => { clearTimeout(timer); resolve(v); },
        e => { clearTimeout(timer); reject(e); }
      );
    });
  }

  async function executeTask(task) {
    switch (task.type) {
      case "OPEN_HOME": return await taskOpenHome(task);
      case "CHECK_LOGIN": return await taskCheckLogin(task);
      case "IMPORT_COOKIES": return await taskImportCookies(task);
      case "LOGIN_WITH_PASSWORD": return await withTimeout(taskLoginWithPassword(task), LOGIN_TASK_MAX_MS, "LOGIN_TASK_TIMEOUT");
      case "WAIT_LOGIN_RESULT": return await taskWaitLoginResult(task);
      case "POST_LOGIN_FINISH": return await taskPostLoginFinish(task);
      case "SEARCH_KEYWORD": return await withTimeout(taskSearchKeyword(task), SEARCH_KEYWORD_MAX_MS, "SEARCH_KEYWORD_TIMEOUT");
      case "OPEN_PRODUCT": return await taskOpenProduct(task);
      case "SCROLL_PRODUCT": return await taskScrollProduct(task);
      case "INTERACT_PRODUCT": return await withTimeout(taskInteractProduct(task), INTERACT_PRODUCT_MAX_MS, "INTERACT_PRODUCT_TIMEOUT");
      case "VIEW_SHOP": return await taskViewShop(task);
      case "SCROLL_SHOP": return await taskScrollShop(task);
      case "FOLLOW_SHOP": return await taskFollowShop(task);
      case "DONE": return { status: "DONE" };
      default: return { status: "UNKNOWN_TASK", message: task.type || "" };
    }
  }

  async function getTask() {
    if (!baseUrl || !token || runningTaskId) return null;
    try {
      const response = await fetch(`${baseUrl}/task`, { headers: requestHeaders() });
      if (!response.ok) return null;
      const task = await response.json();
      if (!task || !task.type || !task.id) return null;
      return task;
    } catch (error) {
      return null;
    }
  }

  async function report(task, result) {
    if (result && result.alreadyReported) return;
    await window.ShopeeAutomationBridge.result({
      taskId: task.id,
      type: task.type,
      result: result || {},
      status: result && result.status || "DONE"
    });
  } 

  async function reportThenNavigate(task, result, targetUrl) {
    const body = Object.assign({}, result || {});
    delete body.alreadyReported;
    await window.ShopeeAutomationBridge.result({
      taskId: task.id,
      type: task.type,
      result: body,
      status: body.status || "DONE"
    });
    const nav = await navigate(targetUrl);
    return nav;
  } 

  async function poll() {
    const task = await getTask();
    if (!task) return;
    runningTaskId = task.id;
    const beginMessage = task.type === "IMPORT_COOKIES" && Number(task.attempt || 0) > 0
      ? `TASK_BEGIN ${task.type} attempt=${Number(task.attempt || 0)}`
      : `TASK_BEGIN ${task.type}`;
    await window.ShopeeAutomationBridge.log("info", beginMessage);
    try {
      const result = await executeTask(task);
      await report(task, result);
      await window.ShopeeAutomationBridge.log("info", `TASK_END ${task.type} ${result.status || "DONE"}`);
    } catch (error) {
      const msg = String(error && error.message || error);
      if (task.type === "INTERACT_PRODUCT" && msg.includes("INTERACT_PRODUCT_TIMEOUT")) {
        const phase = String(task.phase || "preScroll");
        await report(task, {
          status: "DONE",
          phase,
          completed: [],
          failed: ["interactTimeout"],
          message: msg
        });
        await window.ShopeeAutomationBridge.log("info", `TASK_END INTERACT_PRODUCT DONE reason=timeout`);
        return;
      }
      if (task.type === "LOGIN_WITH_PASSWORD" && msg.includes("LOGIN_TASK_TIMEOUT")) {
        await window.ShopeeAutomationBridge.log("info", `LOGIN_FLOW_TIMEOUT stage=task_timeout href=${location.href}`);
        await report(task, { status: "NEED_LOGIN", state: "NEED_LOGIN", message: "LOGIN_TASK_TIMEOUT", href: location.href });
        await window.ShopeeAutomationBridge.log("info", `TASK_END LOGIN_WITH_PASSWORD NEED_LOGIN reason=timeout`);
        return;
      }
      if (task.type === "SEARCH_KEYWORD" && msg.includes("SEARCH_KEYWORD_TIMEOUT")) {
        const keyword = String(task.keyword || "").trim() || "áo thun dài tay";
        const searchUrl = `https://shopee.vn/search?keyword=${encodeURIComponent(keyword)}`;
        await window.ShopeeAutomationBridge.log("info", `SEARCH_KEYWORD_TIMEOUT keyword=${keyword.slice(0, 40)} fallback=url`);
        await report(task, { status: "NAVIGATING_SEARCH", keyword, searchUrl, method: "TIMEOUT_FALLBACK_URL", message: msg });
        window.ShopeeAutomationBridge.navigate(searchUrl).catch(() => {});
        await window.ShopeeAutomationBridge.log("info", `TASK_END SEARCH_KEYWORD NAVIGATING_SEARCH reason=timeout`);
        return;
      }
      await report(task, { status: "ERROR", message: msg });
    } finally {
      runningTaskId = "";
    }
  }

  window.ShopeeAutomation = { detectState, collectProductLinks };
  const bootHost = (location.hostname || "").toLowerCase();
  if (bootHost.includes("facebook.com")) {
    setTimeout(() => {
      resumePendingFacebookProductOpen().catch(() => {});
    }, 800);
    setTimeout(() => {
      resumePendingFacebookProductOpen().catch(() => {});
    }, 2800);
  } else {
    readPendingFacebookProduct().then(p => {
      if (p && urlMatchesProductTarget(location.href, p.productUrl, p.idHint || extractProductIdToken(p.productUrl))) {
        clearPendingFacebookProduct();
      }
    }).catch(() => {});
    applyLoggedInCartBadgePrivacy();
    emitContentReadyIfStable();
    setInterval(poll, pollIntervalMs);
    setTimeout(poll, 400);
    setInterval(() => {
      if (hasLoggedInProof()) {
        applyLoggedInCartBadgePrivacy();
      }
    }, 2500);
  }
})();

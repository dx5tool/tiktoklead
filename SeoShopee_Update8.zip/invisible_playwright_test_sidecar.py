import argparse
import hashlib
import json
import random
import re
import os
import socket
import secrets
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

try:
    import psutil
except Exception:
    psutil = None
from typing import Any, Dict, Optional
from urllib.parse import quote, urlparse, urlsplit, urlunsplit

KEYWORD_TIME_LIMIT_SEC = 300
INTERACT_TASK_STALL_SEC = 95
SHOP_CONTENT_WAIT_SEC = 5

try:
    import invisible_playwright
    from invisible_playwright import (
        BINARY_VERSION,
        FIREFOX_UPSTREAM_VERSION,
        InvisiblePlaywright,
        ensure_binary,
        get_default_stealth_prefs,
    )
except Exception as import_error:
    print(f"ERROR: cannot import invisible_playwright: {import_error}", file=sys.stderr, flush=True)
    raise

FIREFOX_BUNDLE_REL = os.path.join("Data", "firefox-invisible")

TRUE_VALUES = {"1", "true", "yes", "y", "on"}


def _extract_media_peerconnection_prefs(prefs: Dict[str, Any]) -> Dict[str, Any]:
    return {str(k): v for k, v in prefs.items() if str(k).startswith("media.peerconnection.")}


def merge_webrtc_media_prefs_from_package(target: Dict[str, Any], package_prefs: Dict[str, Any]) -> None:
    for key, value in _extract_media_peerconnection_prefs(package_prefs).items():
        target[key] = value


def _is_rfc1918_ipv4(ip: str) -> bool:
    try:
        parts = [int(x) for x in (ip or "").split(".")]
        if len(parts) != 4:
            return False
        if parts[0] == 10:
            return True
        if parts[0] == 172 and 16 <= parts[1] <= 31:
            return True
        if parts[0] == 192 and parts[1] == 168:
            return True
    except Exception:
        return False
    return False


def collect_host_network_context() -> Dict[str, Any]:
    ctx: Dict[str, Any] = {
        "privateIpv4": [],
        "publicIpv4": [],
        "adapters": [],
        "likelyVps": False,
        "hostNetworkClass": "unknown",
    }
    if psutil is None:
        ctx["psutilMissing"] = True
        return ctx
    try:
        for name, addrs in psutil.net_if_addrs().items():
            adapter: Dict[str, Any] = {"name": name, "ipv4": []}
            for addr in addrs:
                if addr.family != socket.AF_INET:
                    continue
                ip = (addr.address or "").strip()
                if not ip or ip.startswith("127."):
                    continue
                adapter["ipv4"].append(ip)
                if _is_rfc1918_ipv4(ip):
                    ctx["privateIpv4"].append(ip)
                else:
                    ctx["publicIpv4"].append(ip)
            if adapter["ipv4"]:
                ctx["adapters"].append(adapter)
    except Exception as ex:
        ctx["psutilError"] = f"{type(ex).__name__}: {ex}"

    ctx["privateIpv4"] = list(dict.fromkeys(ctx["privateIpv4"]))
    ctx["publicIpv4"] = list(dict.fromkeys(ctx["publicIpv4"]))
    names = " ".join(str(a.get("name", "")).lower() for a in ctx["adapters"])
    ctx["likelyVps"] = any(token in names for token in ("tap", "tun", "openstack", "virtio", "hyper-v", "vethernet"))
    if ctx["privateIpv4"] and not ctx["publicIpv4"]:
        ctx["hostNetworkClass"] = "private_only"
    elif not ctx["privateIpv4"] and ctx["publicIpv4"]:
        ctx["hostNetworkClass"] = "public_only"
    elif ctx["privateIpv4"] and ctx["publicIpv4"]:
        ctx["hostNetworkClass"] = "mixed"
    return ctx


def _host_has_ipv4(net_ctx: Dict[str, Any], ip: str) -> bool:
    target = (ip or "").strip()
    if not target:
        return False
    for adapter in net_ctx.get("adapters") or []:
        for addr in adapter.get("ipv4") or []:
            if str(addr) == target:
                return True
    return False


def _adapter_is_loopback(name: str) -> bool:
    return "loopback" in (name or "").lower()


def _physical_private_ipv4(net_ctx: Dict[str, Any]) -> list[str]:
    """RFC1918 on real NICs only — ignore loopback binds from prior VPS sessions."""
    out: list[str] = []
    for adapter in net_ctx.get("adapters") or []:
        name = str(adapter.get("name") or "")
        if _adapter_is_loopback(name):
            continue
        for ip in adapter.get("ipv4") or []:
            if _is_rfc1918_ipv4(str(ip)):
                out.append(str(ip))
    return list(dict.fromkeys(out))


def _pick_preferred_lan_ip(net_ctx: Dict[str, Any]) -> Optional[str]:
    """Prefer primary Wi‑Fi/Ethernet (not * virtual); matches dev leak (.20 on 'Wi‑Fi')."""
    candidates: list[tuple[int, str]] = []
    for adapter in net_ctx.get("adapters") or []:
        name = str(adapter.get("name") or "")
        if _adapter_is_loopback(name):
            continue
        lower = name.lower()
        if "*" in name:
            score = 0
        elif lower == "wi-fi" or lower == "wifi":
            score = 3
        elif "wi-fi" in lower or lower == "ethernet":
            score = 2
        elif "ethernet" in lower:
            score = 1
        else:
            score = 0
        for ip in adapter.get("ipv4") or []:
            if _is_rfc1918_ipv4(str(ip)):
                candidates.append((score, str(ip)))
    if not candidates:
        phys = _physical_private_ipv4(net_ctx)
        return phys[0] if phys else None
    candidates.sort(key=lambda t: (-t[0], t[1]))
    return candidates[0][1]


def ensure_stealth_host_ip_bound_on_windows(
    host_ip: str,
    net_ctx: Dict[str, Any],
) -> Dict[str, Any]:
    """VPS: package LAN IP must exist on an interface for ICE/stealth (dev has real Wi‑Fi)."""
    result: Dict[str, Any] = {
        "hostIp": host_ip,
        "skipped": True,
        "reason": "",
        "platform": sys.platform,
    }
    if sys.platform != "win32":
        result["reason"] = "not_windows"
        return result
    ip = (host_ip or "").strip()
    if not _is_rfc1918_ipv4(ip):
        result["reason"] = "not_rfc1918"
        return result
    if _host_has_ipv4(net_ctx, ip):
        result["reason"] = "already_bound"
        return result
    if net_ctx.get("hostNetworkClass") != "public_only" and not net_ctx.get("likelyVps"):
        result["reason"] = "not_vps_profile"
        return result

    loopback_names = ("Loopback Pseudo-Interface 1", "Loopback Pseudo-Interface")
    last_err = ""
    for if_name in loopback_names:
        cmd = [
            "netsh",
            "interface",
            "ipv4",
            "add",
            "address",
            if_name,
            ip,
            "255.255.255.255",
        ]
        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=30,
                creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
            )
            out = ((proc.stdout or "") + (proc.stderr or "")).strip()
            result.update(
                {
                    "skipped": False,
                    "interface": if_name,
                    "exitCode": proc.returncode,
                    "netshOutput": out[:500],
                }
            )
            if proc.returncode == 0 or "already" in out.lower():
                result["bound"] = True
                return result
            last_err = out
        except Exception as ex:
            last_err = f"{type(ex).__name__}: {ex}"

    result.update({"skipped": False, "bound": False, "error": last_err[:500]})
    return result


def maybe_align_webrtc_host_ip_with_host_lan(
    prefs: Dict[str, Any],
    net_ctx: Dict[str, Any],
) -> None:
    """Dev: align to Wi‑Fi LAN. VPS: keep upstream seed host_ip; optional loopback bind only."""
    package_host = prefs.get("zoom.stealth.webrtc.host_ip") or prefs.get("webrtc.host_ip")
    package_host = str(package_host or "").strip()

    if net_ctx.get("likelyVps"):
        ensure_stealth_host_ip_bound_on_windows(package_host, net_ctx)
        return

    phys = _physical_private_ipv4(net_ctx)
    if not phys:
        return

    chosen = _pick_preferred_lan_ip(net_ctx) or phys[0]
    if str(package_host) != chosen:
        prefs["zoom.stealth.webrtc.host_ip"] = chosen


WINDOWS_VN_FONT_PRESET = [
    "Arial",
    "Arial Black",
    "Bahnschrift",
    "Calibri",
    "Cambria",
    "Cambria Math",
    "Candara",
    "Comic Sans MS",
    "Consolas",
    "Constantia",
    "Corbel",
    "Courier New",
    "Ebrima",
    "Franklin Gothic Medium",
    "Gabriola",
    "Georgia",
    "Impact",
    "Lucida Console",
    "Lucida Sans Unicode",
    "Malgun Gothic",
    "Microsoft Himalaya",
    "Microsoft JhengHei",
    "Microsoft New Tai Lue",
    "Microsoft PhagsPa",
    "Microsoft Sans Serif",
    "Microsoft Tai Le",
    "Microsoft YaHei",
    "Microsoft Yi Baiti",
    "MingLiU-ExtB",
    "Mongolian Baiti",
    "MS Gothic",
    "MV Boli",
    "Myanmar Text",
    "Nirmala UI",
    "Palatino Linotype",
    "Segoe MDL2 Assets",
    "Segoe Print",
    "Segoe Script",
    "Segoe UI",
    "Segoe UI Emoji",
    "Segoe UI Historic",
    "Segoe UI Symbol",
    "SimSun",
    "Sitka Text",
    "Sylfaen",
    "Symbol",
    "Tahoma",
    "Times New Roman",
    "Trebuchet MS",
    "Verdana",
    "Webdings",
    "Wingdings",
]


def parse_bool(value: str) -> bool:
    return str(value or "").strip().lower() in TRUE_VALUES


def resolve_seed(raw_seed: str, profile_name: str, profile_dir: str) -> int:
    raw_seed = (raw_seed or "").strip()
    if raw_seed:
        return int(raw_seed)

    seed_source = f"{profile_name}|{os.path.abspath(profile_dir)}"
    digest = hashlib.sha256(seed_source.encode("utf-8", errors="ignore")).hexdigest()
    return 100000 + (int(digest[:8], 16) % 900000000)


def strip_all_optional_prefs_for_off_mode(prefs: Dict[str, Any]) -> None:
    for key in list(prefs.keys()):
        text_key = str(key)
        if text_key.startswith("zoom.stealth.") or text_key == "intl.accept_languages":
            prefs.pop(key, None)


def keep_minimal_seed_prefs(prefs: Dict[str, Any]) -> None:
    """Seed fingerprint without screen/DPR prefs (HWND stays maximized; avoid layout fight)."""
    allowed_keys = {
        "zoom.stealth.seed",
        "zoom.stealth.fpp.hw_seed",
        "zoom.stealth.webrtc.host_ip",
        "zoom.stealth.hw_concurrency",
        "zoom.stealth.storage.quota_mb",
    }
    for key in (
        "zoom.stealth.screen.width",
        "zoom.stealth.screen.height",
        "zoom.stealth.screen.avail_width",
        "zoom.stealth.screen.avail_height",
        "zoom.stealth.screen.dpr",
        "layout.css.devPixelsPerPx",
    ):
        prefs.pop(key, None)
    for key in list(prefs.keys()):
        if str(key) not in allowed_keys:
            prefs.pop(key, None)


def resolve_app_base_dir(explicit: str) -> str:
    explicit = (explicit or "").strip()
    if explicit:
        return os.path.abspath(explicit)
    return os.path.abspath(os.getcwd())


def resolve_firefox_executable(app_base_dir: str) -> str:
    bundle_exe = os.path.join(app_base_dir, FIREFOX_BUNDLE_REL, "firefox.exe")
    if os.path.isfile(bundle_exe) and os.path.getsize(bundle_exe) > 0:
        return os.path.abspath(bundle_exe)
    return ensure_binary()


def apply_disable_translations_prefs(prefs: Dict[str, Any]) -> None:
    """Tắt Firefox Translations / popup dịch (prefs tối thiểu, không đụng vị trí cửa sổ)."""
    prefs["browser.translations.enabled"] = False
    prefs["browser.translations.automaticallyPopup"] = False
    prefs["browser.translations.enable"] = False


def apply_webrtc_lan_candidate_prefs(prefs: Dict[str, Any]) -> None:
    prefs["media.peerconnection.enabled"] = True
    prefs["media.peerconnection.ice.no_host"] = False
    prefs["media.peerconnection.ice.default_address_only"] = False
    prefs["media.peerconnection.ice.obfuscate_host_addresses"] = False
    prefs["media.peerconnection.ice.disableIPv6"] = True
    prefs["media.peerconnection.ice.proxy_only"] = False
    prefs["media.peerconnection.ice.relay_only"] = False
    prefs["media.peerconnection.use_document_iceservers"] = True


def apply_windows_vn_font_prefs(prefs: Dict[str, Any]) -> None:
    font_whitelist = ",".join(WINDOWS_VN_FONT_PRESET)
    prefs["zoom.stealth.font.whitelist"] = font_whitelist
    prefs["font.name.serif.x-western"] = "Times New Roman"
    prefs["font.name.sans-serif.x-western"] = "Arial"
    prefs["font.name.monospace.x-western"] = "Consolas"
    prefs["font.name-list.serif.x-western"] = "Times New Roman, Cambria, Georgia"
    prefs["font.name-list.sans-serif.x-western"] = "Arial, Segoe UI, Calibri, Tahoma, Verdana"
    prefs["font.name-list.monospace.x-western"] = "Consolas, Courier New, Lucida Console"
    prefs["font.name.serif.x-unicode"] = "Times New Roman"
    prefs["font.name.sans-serif.x-unicode"] = "Arial"
    prefs["font.name.monospace.x-unicode"] = "Consolas"
    prefs["font.name.serif.x-vietnamese"] = "Times New Roman"
    prefs["font.name.sans-serif.x-vietnamese"] = "Arial"
    prefs["font.name.monospace.x-vietnamese"] = "Consolas"
    prefs["font.name-list.serif.x-vietnamese"] = "Times New Roman, Cambria, Georgia"
    prefs["font.name-list.sans-serif.x-vietnamese"] = "Arial, Segoe UI, Calibri, Tahoma, Verdana"
    prefs["font.name-list.monospace.x-vietnamese"] = "Consolas, Courier New, Lucida Console"
    prefs["font.default.x-western"] = "sans-serif"
    prefs["font.default.x-vietnamese"] = "sans-serif"
    prefs["font.size.variable.x-western"] = 16
    prefs["font.size.variable.x-vietnamese"] = 16
    prefs["font.size.monospace.x-western"] = 13
    prefs["font.size.monospace.x-vietnamese"] = 13
    prefs["intl.accept_languages"] = "vi-VN,vi,en-US,en"
    prefs["general.useragent.locale"] = "vi-VN"
    prefs["javascript.use_us_english_locale"] = False


def build_proxy(server: str, username: str, password: str) -> Optional[Dict[str, str]]:
    server = (server or "").strip()
    username = (username or "").strip()
    password = password or ""
    if not server:
        return None

    proxy: Dict[str, str] = {"server": server}
    if username:
        proxy["username"] = username
        proxy["password"] = password
    return proxy


STEALTHFOX_WEBRTC_PUBLIC_IP_ENV = "STEALTHFOX_WEBRTC_PUBLIC_IP"


def _parse_ipv4_from_text(text: str) -> Optional[str]:
    m = re.search(r"\b(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b", text or "")
    if not m:
        return None
    ip = m.group(1)
    parts = ip.split(".")
    if len(parts) != 4:
        return None
    try:
        if all(0 <= int(p) <= 255 for p in parts):
            return ip
    except ValueError:
        return None
    return None


def _parse_socks_proxy_endpoint(server: str) -> Optional[tuple[str, int, str]]:
    raw = (server or "").strip()
    if not raw:
        return None
    if "://" not in raw:
        raw = "socks5://" + raw
    parsed = urlparse(raw)
    host = parsed.hostname
    if not host:
        return None
    port = parsed.port or 1080
    scheme = (parsed.scheme or "socks5").lower()
    return host, int(port), scheme


def fetch_proxy_egress_ipv4(proxy: Dict[str, str], timeout_sec: float = 18.0) -> Dict[str, Any]:
    """Resolve SOCKS egress IP (must match browser Remote IP, not proxy hostname)."""
    result: Dict[str, Any] = {
        "ok": False,
        "ip": None,
        "error": "",
        "url": "https://api.ipify.org",
        "method": "",
    }
    server = (proxy.get("server") or "").strip()
    if not server:
        result["error"] = "no_proxy"
        return result
    endpoint = _parse_socks_proxy_endpoint(server)
    proxy_host = endpoint[0] if endpoint else None

    def _finish(ip: Optional[str], method: str, err: str = "") -> Dict[str, Any]:
        result["method"] = method
        if ip:
            result["ok"] = True
            result["ip"] = ip
            if proxy_host and ip == proxy_host:
                result["warning"] = "egress_equals_proxy_hostname_not_exit_ip"
        else:
            result["error"] = err or "no_ipv4"
        return result

    try:
        import socks

        if not endpoint:
            raise ValueError("invalid_proxy_server")
        phost, pport, scheme = endpoint
        ptype = socks.SOCKS5 if "socks5" in scheme else socks.SOCKS4
        user = (proxy.get("username") or "").strip()
        passwd = proxy.get("password") or ""
        orig_socket = socket.socket
        try:
            socks.setdefaultproxy(ptype, phost, pport, True, user or None, passwd or None)
            socket.socket = socks.socksocket
            import requests

            resp = requests.get(result["url"], timeout=timeout_sec)
            resp.raise_for_status()
            return _finish(_parse_ipv4_from_text(resp.text), "pysocks")
        finally:
            socket.socket = orig_socket
            socks.setdefaultproxy()
    except Exception as ex_pysocks:
        result["pysocksError"] = f"{type(ex_pysocks).__name__}: {ex_pysocks}"

    try:
        import requests

        proxies = {"http": server, "https": server}
        auth = None
        user = (proxy.get("username") or "").strip()
        if user:
            auth = (user, proxy.get("password") or "")
        resp = requests.get(result["url"], proxies=proxies, timeout=timeout_sec, auth=auth)
        resp.raise_for_status()
        ip = _parse_ipv4_from_text(resp.text)
        out = _finish(ip, "requests_proxies")
        if proxy_host and ip == proxy_host:
            out["rejected"] = True
            out["ok"] = False
            out["error"] = "egress_is_proxy_host_use_pysocks"
        return out
    except Exception as ex:
        result["error"] = f"{type(ex).__name__}: {ex}"
        result["method"] = "requests_proxies"
        return result


def apply_stealthfox_webrtc_env_for_firefox(
    env: Dict[str, str],
    proxy: Optional[Dict[str, str]],
) -> None:
    """invisible_playwright launcher propagates STEALTHFOX_WEBRTC_PUBLIC_IP to nICEr (srflx swap)."""
    explicit = (os.environ.get(STEALTHFOX_WEBRTC_PUBLIC_IP_ENV) or "").strip()
    egress_ip = _parse_ipv4_from_text(explicit) if explicit else None
    if not egress_ip and proxy:
        fetch_meta = fetch_proxy_egress_ipv4(proxy)
        if fetch_meta.get("ok"):
            egress_ip = str(fetch_meta.get("ip"))

    proxy_host = None
    if proxy:
        ep = _parse_socks_proxy_endpoint((proxy.get("server") or "").strip())
        proxy_host = ep[0] if ep else None
    if egress_ip and proxy_host and egress_ip == proxy_host:
        egress_ip = None
    if egress_ip:
        env[STEALTHFOX_WEBRTC_PUBLIC_IP_ENV] = egress_ip


def resolve_humanize(enabled: bool, max_seconds: str) -> Any:
    if not enabled:
        return False

    max_seconds = (max_seconds or "").strip()
    if not max_seconds:
        return True

    return float(max_seconds)


def get_navigation_url(args: argparse.Namespace) -> str:
    if args.navigation_mode == "target":
        return args.target_url
    if args.navigation_mode == "category":
        return args.category_url
    return ""


def normalize_url_for_raw_command_line(url: str) -> str:
    try:
        parts = urlsplit(url)
        if not parts.scheme or not parts.netloc:
            return url
        encoded_path = quote(parts.path, safe="/%")
        encoded_query = quote(parts.query, safe="=&%?/:+,-._~")
        encoded_fragment = quote(parts.fragment, safe="=&%?/:+,-._~")
        return urlunsplit((parts.scheme, parts.netloc, encoded_path, encoded_query, encoded_fragment))
    except Exception:
        return url


def context_new_page(browser_or_context: Any, persistent: bool) -> Any:
    if persistent:
        return browser_or_context.new_page()
    context = browser_or_context.new_context()
    return context.new_page()


def run_diagnostics(page: Any) -> None:
    print("DIAGNOSTICS: begin", flush=True)
    try:
        navigator_json = page.evaluate(
            """
            () => JSON.stringify({
                userAgent: navigator.userAgent,
                webdriver: navigator.webdriver === undefined ? 'undefined' : navigator.webdriver,
                language: navigator.language,
                languages: Array.from(navigator.languages || []),
                platform: navigator.platform,
                vendor: navigator.vendor,
                hardwareConcurrency: navigator.hardwareConcurrency,
                deviceMemory: navigator.deviceMemory,
                timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
                url: location.href
            })
            """
        )
        print("DIAGNOSTICS_NAVIGATOR: " + navigator_json, flush=True)
    except Exception as ex:
        print(f"DIAGNOSTICS_NAVIGATOR_FAILED: {type(ex).__name__}: {ex}", flush=True)

    try:
        page_state = page.evaluate(
            """
            () => JSON.stringify({
                href: location.href,
                title: document.title,
                readyState: document.readyState,
                visibilityState: document.visibilityState,
                innerWidth: window.innerWidth,
                innerHeight: window.innerHeight,
                screenWidth: screen.width,
                screenHeight: screen.height,
                devicePixelRatio: window.devicePixelRatio
            })
            """
        )
        print("DIAGNOSTICS_PAGE_STATE: " + page_state, flush=True)
    except Exception as ex:
        print(f"DIAGNOSTICS_PAGE_STATE_FAILED: {type(ex).__name__}: {ex}", flush=True)

    print("DIAGNOSTICS: end", flush=True)


def apply_proxy_prefs(proxy: Optional[Dict[str, str]], prefs: Dict[str, Any]) -> None:
    if not proxy:
        return

    server = (proxy.get("server") or "").strip()
    if not server or server.lower() == "direct://":
        return

    parsed = urlparse(server if "://" in server else "http://" + server)
    host = parsed.hostname or ""
    port = int(parsed.port or (443 if parsed.scheme == "https" else 80))
    username = proxy.get("username") or ""
    password = proxy.get("password") or ""
    if not host:
        return

    prefs["network.proxy.type"] = 1
    prefs["network.proxy.failover_direct"] = False
    scheme = parsed.scheme.lower()
    if scheme.startswith("socks"):
        prefs["network.proxy.socks"] = host
        prefs["network.proxy.socks_port"] = port
        prefs["network.proxy.socks_version"] = 4 if scheme == "socks4" else 5
        prefs["network.proxy.socks_remote_dns"] = True
        prefs["network.proxy.socks_username"] = username
        prefs["network.proxy.socks_password"] = password
        return

    prefs["network.proxy.http"] = host
    prefs["network.proxy.http_port"] = port
    prefs["network.proxy.ssl"] = host
    prefs["network.proxy.ssl_port"] = port
    prefs["network.proxy.share_proxy_settings"] = True


def pref_to_user_js_line(key: str, value: Any) -> str:
    if isinstance(value, bool):
        encoded = "true" if value else "false"
    elif isinstance(value, int) and not isinstance(value, bool):
        encoded = str(value)
    elif isinstance(value, float):
        encoded = repr(value)
    else:
        encoded = json.dumps(str(value), ensure_ascii=False)
    return f"user_pref({json.dumps(str(key))}, {encoded});"


def apply_block_images_prefs(prefs: Dict[str, Any]) -> None:
    prefs["permissions.default.image"] = 2


def apply_firefox_hidden_automation_prefs(prefs: Dict[str, Any]) -> None:
    """Keep timers/extension polling alive while Firefox is behind other windows (hidden mode)."""
    prefs["dom.min_background_timeout_value"] = 4
    prefs["dom.min_background_timeout_value_without_budget_throttling"] = 4
    prefs["dom.timeout.enable_budget_timer_throttling"] = False
    prefs["dom.timeout.throttling_delay"] = 0
    prefs["dom.timeout.background_throttling_max_budget"] = -1
    prefs["browser.tabs.unloadOnLowMemory"] = False
    prefs["dom.ipc.processPriorityManager.backgroundPerceivable"] = True


def apply_hidden_automation_launch_prefs(prefs: Dict[str, Any]) -> None:
    """Align first paint with C# MinAutomationOuter* (1280x800 at work area origin)."""
    prefs["browser.window.screenX"] = 0
    prefs["browser.window.screenY"] = 0
    prefs["browser.window.width"] = 1280
    prefs["browser.window.height"] = 800
    prefs["browser.startup.page"] = 0
    prefs["browser.sessionstore.max_resumed_crashes"] = 0
    prefs["browser.sessionstore.restore_on_demand"] = False
    prefs["browser.sessionstore.resume_session_once"] = False


def ensure_browser_window_automation_in_xulstore(profile_dir: str) -> None:
    """Avoid Firefox restoring tiny or off-screen chrome from xulstore on startup."""
    path = os.path.join(profile_dir, "xulstore.json")
    data: Dict[str, Any] = {}
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as fp:
                loaded = json.load(fp)
            if isinstance(loaded, dict):
                data = loaded
        except Exception:
            data = {}
    browser = data.get("browserWindow")
    if not isinstance(browser, dict):
        browser = {}
    browser["sizemode"] = "normal"
    browser["width"] = "1280"
    browser["height"] = "800"
    browser["screenX"] = "0"
    browser["screenY"] = "0"
    data["browserWindow"] = browser
    os.makedirs(profile_dir, exist_ok=True)
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as fp:
        json.dump(data, fp, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)
    print(f"XULSTORE_AUTOMATION_VIEWPORT: {path}", flush=True)


def ensure_browser_window_maximized_in_xulstore(profile_dir: str) -> None:
    """Firefox restores chrome size from xulstore.json; default is often ~1296x936 @ (4,4)."""
    path = os.path.join(profile_dir, "xulstore.json")
    data: Dict[str, Any] = {}
    if os.path.isfile(path):
        try:
            with open(path, "r", encoding="utf-8") as fp:
                loaded = json.load(fp)
            if isinstance(loaded, dict):
                data = loaded
        except Exception:
            data = {}
    browser = data.get("browserWindow")
    if not isinstance(browser, dict):
        browser = {}
    browser["sizemode"] = "maximized"
    browser["width"] = "1920"
    browser["height"] = "1032"
    browser["screenX"] = "0"
    browser["screenY"] = "0"
    data["browserWindow"] = browser
    os.makedirs(profile_dir, exist_ok=True)
    tmp_path = path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as fp:
        json.dump(data, fp, ensure_ascii=False, indent=2)
    os.replace(tmp_path, path)
    print(f"XULSTORE_MAXIMIZED: {path}", flush=True)


def write_user_js(profile_dir: str, prefs: Dict[str, Any]) -> None:
    os.makedirs(profile_dir, exist_ok=True)
    prefs = dict(prefs)
    prefs.setdefault("browser.shell.checkDefaultBrowser", False)
    prefs.setdefault("browser.startup.homepage_override.mstone", "ignore")
    prefs.setdefault("browser.startup.firstrunSkipsHomepage", True)
    prefs.setdefault("toolkit.telemetry.reportingpolicy.firstRun", False)
    prefs.setdefault("browser.tabs.warnOnClose", False)
    prefs.setdefault("browser.warnOnQuit", False)
    prefs.setdefault("browser.sessionstore.resume_from_crash", False)

    user_js_path = os.path.join(profile_dir, "user.js")
    tmp_path = user_js_path + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as fp:
        for key in sorted(prefs.keys()):
            fp.write(pref_to_user_js_line(key, prefs[key]) + "\n")
    os.replace(tmp_path, user_js_path)
    print(f"USER_JS: {user_js_path}", flush=True)


def get_process_probe(pid: int) -> Dict[str, Any]:
    if psutil is None:
        return {"psutil": False}
    try:
        parent = psutil.Process(pid)
        descendants = []
        for child in parent.children(recursive=True):
            try:
                descendants.append({"pid": child.pid, "name": child.name(), "cmdline": child.cmdline()[:8]})
            except Exception as child_ex:
                descendants.append({"pid": child.pid, "error": str(child_ex)})
        return {
            "psutil": True,
            "parentAlive": parent.is_running(),
            "parentName": parent.name(),
            "parentStatus": parent.status(),
            "parentCmdline": parent.cmdline()[:8],
            "descendants": descendants,
        }
    except Exception as ex:
        return {"psutil": True, "error": str(ex)}


def get_firefox_processes_for_profile(profile_dir: str) -> list[Dict[str, Any]]:
    if psutil is None:
        return []
    normalized_profile = os.path.normcase(os.path.abspath(profile_dir))
    matches: list[Dict[str, Any]] = []
    try:
        for proc in psutil.process_iter(["pid", "name", "cmdline", "status"]):
            try:
                name = str(proc.info.get("name") or "")
                if "firefox" not in name.lower():
                    continue
                cmdline = [str(part) for part in (proc.info.get("cmdline") or [])]
                normalized_cmdline = [os.path.normcase(os.path.abspath(part)) if os.path.isabs(part) else os.path.normcase(part) for part in cmdline]
                joined = "\n".join(normalized_cmdline)
                if normalized_profile in joined:
                    matches.append({"pid": proc.info.get("pid"), "name": name, "status": proc.info.get("status"), "cmdline": cmdline[:10]})
            except Exception:
                continue
    except Exception:
        return []
    return matches


def raw_profile_has_active_lock(profile_dir: str) -> bool:
    lock_path = os.path.join(profile_dir, "parent.lock")
    return os.path.exists(lock_path)


def terminate_profile_firefox_processes(profile_dir: str) -> None:
    if psutil is None:
        return
    processes = []
    for match in get_firefox_processes_for_profile(profile_dir):
        pid = match.get("pid")
        try:
            if pid:
                proc = psutil.Process(int(pid))
                processes.append(proc)
                proc.terminate()
        except Exception:
            pass
    if not processes:
        return
    try:
        gone, alive = psutil.wait_procs(processes, timeout=6)
    except Exception:
        alive = processes
    for proc in alive:
        try:
            proc.kill()
        except Exception:
            pass


def terminate_process(process: subprocess.Popen, timeout_seconds: float = 6.0) -> None:
    if process.poll() is not None:
        return
    try:
        process.terminate()
        process.wait(timeout=timeout_seconds)
        return
    except Exception:
        pass
    try:
        process.kill()
        process.wait(timeout=timeout_seconds)
    except Exception:
        pass


def read_debug_file_lines(path: str, contains: Optional[list[str]] = None, limit: int = 40) -> list[str]:
    try:
        if not os.path.exists(path):
            return []
        results: list[str] = []
        with open(path, "r", encoding="utf-8", errors="replace") as handle:
            for line in handle:
                text = line.strip()
                if not contains or any(token in text for token in contains):
                    results.append(text[:500])
                    if len(results) >= limit:
                        break
        return results
    except Exception as ex:
        return ["READ_FAILED: " + str(ex)]


def delete_user_js_if_present(profile_dir: str) -> bool:
    user_js_path = os.path.join(profile_dir, "user.js")
    try:
        if os.path.exists(user_js_path):
            os.remove(user_js_path)
            return True
    except Exception:
        return False
    return False


EXTENSION_ID = "shopee-automation@seoshop.local"



def normalize_shopee_login_user(user: str) -> str:
    """Same as C# login: user.Replace(\"xdf\",\"\").Replace(\"nlv\",\"\")."""
    if not user:
        return ""
    return user.replace("xdf", "").replace("nlv", "")


def apply_add_to_cart_session_roll(actions: Dict[str, Any], percent: int) -> None:
    """Một lần random khi mở phiên nick: bật/tắt addToCart cho cả phiên (tỷ lệ %)."""
    if not actions.get("addToCart"):
        return
    try:
        rate = max(0, min(100, int(percent)))
    except (TypeError, ValueError):
        rate = 0
    if rate <= 0:
        actions["addToCart"] = False
        return
    if rate >= 100:
        return
    roll = random.randrange(100)
    enabled = roll < rate
    actions["addToCart"] = enabled
    print(
        f"AUTOMATION_ADD_TO_CART_SESSION: percent={rate} roll={roll} enabled={enabled}",
        flush=True,
    )


def load_automation_payload_file(args: argparse.Namespace) -> None:
    path = (getattr(args, "automation_payload_file", "") or "").strip()
    if not path:
        return
    try:
        with open(path, "r", encoding="utf-8") as fh:
            payload = json.load(fh)
    except Exception as ex:
        print(f"AUTOMATION_PAYLOAD_FILE_ERROR: {type(ex).__name__}: {ex}", flush=True)
        return
    if not isinstance(payload, dict):
        print("AUTOMATION_PAYLOAD_FILE_ERROR: payload_not_object", flush=True)
        return

    mappings = {
        "automationAccount": "automation_account",
        "automationUser": "automation_user",
        "automationPassword": "automation_password",
        "automationCookie": "automation_cookie",
        "automationKeyword": "automation_keyword",
        "automationProductUrl": "automation_product_url",
        "automationKeywordsJson": "automation_keywords_json",
        "automationActions": "automation_actions",
        "automationAddToCartPercent": "automation_add_to_cart_percent",
        "automationMaxSearchPages": "automation_max_search_pages",
        "automationProductViewMin": "automation_product_view_min",
        "automationProductViewMax": "automation_product_view_max",
    }
    for source_key, attr_name in mappings.items():
        if source_key in payload and payload[source_key] is not None:
            setattr(args, attr_name, payload[source_key])
    try:
        os.remove(path)
    except Exception:
        pass


def build_automation_payload(args: argparse.Namespace) -> Optional[Dict[str, Any]]:
    load_automation_payload_file(args)
    account = (args.automation_account or "").strip()
    user = normalize_shopee_login_user((args.automation_user or "").strip())
    password = args.automation_password or ""
    cookie = args.automation_cookie or ""
    if not account and not user and not password and not cookie:
        return None
    keyword = (args.automation_keyword or "").strip()
    product_url = (args.automation_product_url or "").strip()
    actions: Dict[str, Any] = {}
    for item in (args.automation_actions or "").split(","):
        name = item.strip()
        if name:
            actions[name] = True

    try:
        cart_percent = int(getattr(args, "automation_add_to_cart_percent", 0) or 0)
    except (TypeError, ValueError):
        cart_percent = 0
    apply_add_to_cart_session_roll(actions, cart_percent)

    items: list[Dict[str, Any]] = []
    keywords_json = (getattr(args, "automation_keywords_json", "") or "").strip()
    if keywords_json:
        try:
            decoded = json.loads(keywords_json)
            if isinstance(decoded, list):
                for raw_item in decoded:
                    if not isinstance(raw_item, dict):
                        continue
                    item_keyword = str(raw_item.get("keyword") or "").strip()
                    item_product_url = str(raw_item.get("productUrl") or raw_item.get("product_url") or "").strip()
                    if item_keyword or item_product_url:
                        items.append({
                            "keyword": item_keyword,
                            "productUrl": item_product_url,
                            "vitri": raw_item.get("vitri"),
                            "trackedKeywordId": raw_item.get("trackedKeywordId"),
                            "productId": raw_item.get("productId") or "",
                            "productName": raw_item.get("productName") or "",
                        })
        except Exception as ex:
            print(f"AUTOMATION_KEYWORDS_JSON_ERROR: {type(ex).__name__}: {ex}", flush=True)

    if not items and (keyword or product_url):
        items.append({"keyword": keyword, "productUrl": product_url, "vitri": 0})

    max_pages = 2
    try:
        max_pages = max(1, int(getattr(args, "automation_max_search_pages", 2) or 2))
    except (TypeError, ValueError):
        max_pages = 2

    view_min = 15
    view_max = 25
    try:
        view_min = max(1, int(getattr(args, "automation_product_view_min", 15) or 15))
        view_max = max(view_min + 1, int(getattr(args, "automation_product_view_max", 25) or 25))
    except (TypeError, ValueError):
        view_min, view_max = 15, 25

    account = normalize_shopee_login_user(account) if account else account

    return {
        "account": account or user,
        "user": user or account,
        "password": password,
        "cookie": cookie,
        "keyword": keyword,
        "productUrl": product_url,
        "items": items,
        "actions": actions,
        "maxSearchPages": max_pages,
        "productViewPauseMin": view_min,
        "productViewPauseMax": view_max,
    }


class AutomationBridge:
    def __init__(self, payload: Dict[str, Any]):
        self.payload = payload
        self.token = secrets.token_urlsafe(24)
        self.session_id = secrets.token_hex(8)
        self._lock = threading.Lock()
        self._pending: list[Dict[str, Any]] = []
        self._completed: set[str] = set()
        self._counter = 0
        self._stopped = False
        self._paused = False
        self.httpd: Optional[ThreadingHTTPServer] = None
        self.thread: Optional[threading.Thread] = None
        self.port = 0
        self.cookie_import_verified = False
        self.cookie_import_attempts = 0
        self.max_cookie_import_attempts = 3
        self.cookie_import_skip_logged = False
        raw_cookie = str(self.payload.get("cookie") or "")
        self._cookie_text_normalized = self._normalize_cookie_text(raw_cookie)
        if self._cookie_text_normalized:
            self.payload["cookie"] = self._cookie_text_normalized
        self.expected_spc_f = self._extract_spc_f(self._cookie_text_normalized)
        self.traffic_form_wait_rounds = 0
        self.login_attempted = False
        self.session_logged_in = False
        self.done_queued = False
        self.keyword_items = self._normalize_keyword_items(payload)
        self.current_item_index = -1
        self.current_item: Dict[str, Any] = {}
        self.reset_keyword_state()
        self.keyword_started_at = 0.0
        self._shop_wait_deadline = 0.0
        self._open_home_for_next_keyword = False
        self.login_form_retries = 0
        self.login_wait_retries = 0
        self.post_submit_retries = 0
        self.awaiting_post_login = False
        self.post_login_finish_queued = False
        self.post_login_probe_queued = False
        self._login_submitted_at = 0.0
        self._post_login_finish_early_at = 0.0
        self._login_flow_started_at = 0.0
        self._post_login_finish_deadline = 0.0
        self._leased_login_task_id = ""
        self._leased_login_task_at = 0.0
        self._leased_login_task_retries = 0
        self._pending_front_task_id = ""
        self._pending_front_task_type = ""
        self._pending_front_task_at = 0.0
        self._leased_general_task_id = ""
        self._leased_general_task_type = ""
        self._leased_general_task_at = 0.0
        self._post_login_finish_extensions = 0
        self._post_login_success_seen = False
        self._interact_task_issued_at = 0.0
        self._interact_task_phase = ""
        self._post_login_captcha_retries = 0
        self._last_retryable_task_type = ""
        self._last_retryable_task_data: Dict[str, Any] = {}
        self._skip_next_risk_status = False
        self._captcha_retry_task_id = ""
        self.enqueue("OPEN_HOME", {})

    def _normalize_keyword_items(self, payload: Dict[str, Any]) -> list[Dict[str, Any]]:
        raw_items = payload.get("items") if isinstance(payload.get("items"), list) else []
        items: list[Dict[str, Any]] = []
        for raw_item in raw_items:
            if not isinstance(raw_item, dict):
                continue
            keyword = str(raw_item.get("keyword") or "").strip()
            product_url = str(raw_item.get("productUrl") or raw_item.get("product_url") or "").strip()
            if keyword or product_url:
                item = dict(raw_item)
                item["keyword"] = keyword
                item["productUrl"] = product_url
                items.append(item)
        if not items:
            keyword = str(payload.get("keyword") or "").strip()
            product_url = str(payload.get("productUrl") or "").strip()
            if keyword or product_url:
                items.append({"keyword": keyword, "productUrl": product_url, "vitri": 0})
        return items

    @staticmethod
    def _normalize_cookie_text(cookie_text: str) -> str:
        text = (cookie_text or "").strip()
        if not text:
            return ""
        text = re.sub(r"(?:^|[;]\s*)\.shopee\.vn\s*=\s*", "", text, flags=re.IGNORECASE)
        return text.strip()

    @staticmethod
    def _extract_spc_f(cookie_text: str) -> str:
        normalized = AutomationBridge._normalize_cookie_text(cookie_text)
        match = re.search(r'SPC_F\s*=\s*["\']?([^;"\'\s]+)', normalized, re.IGNORECASE)
        return match.group(1) if match else ""

    def _has_cookie_import_candidate(self) -> bool:
        return bool(self._cookie_text_normalized) and bool(self.expected_spc_f)

    def _log_cookie_import_skip_if_needed(self) -> None:
        if self.cookie_import_skip_logged or self.cookie_import_verified:
            return
        if self._has_cookie_import_candidate():
            return
        self.cookie_import_skip_logged = True
        print("AUTOMATION_COOKIE_IMPORT_SKIP: no_cookie_or_no_spc_f", flush=True)

    def _queue_cookie_import_if_available(self) -> bool:
        if self.cookie_import_verified or not self._has_cookie_import_candidate():
            return False
        if self.cookie_import_attempts >= self.max_cookie_import_attempts:
            return False
        self.traffic_form_wait_rounds = 0
        self.cookie_import_attempts += 1
        self.enqueue("IMPORT_COOKIES", {
            "cookie": self._cookie_text_normalized,
            "attempt": self.cookie_import_attempts - 1,
            "expectedSpcF": self.expected_spc_f,
        })
        return True

    def reset_keyword_state(self) -> None:
        self.search_started = False
        self.product_started = False
        self.scroll_started = False
        self.interact_pre_started = False
        self.interact_review_started = False
        self.interact_started = False
        self.shop_started = False
        self.follow_started = False
        self.waiting_product_content = False
        self.waiting_shop_content = False
        self.waiting_search_content = False
        self.search_target_keyword = ""
        self.shop_scroll_started = False
        self.product_target_url = ""
        self.shop_target_url = ""
        self._search_wait_deadline = 0.0
        self._interact_task_issued_at = 0.0
        self._interact_task_phase = ""

    def enqueue(self, task_type: str, data: Dict[str, Any]) -> None:
        self._counter += 1
        task = dict(data or {})
        task["id"] = f"task-{self._counter}"
        task["type"] = task_type
        task["queuedAt"] = time.time()
        self._pending.append(task)
        if len(self._pending) == 1:
            self._pending_front_task_id = str(task.get("id") or "")
            self._pending_front_task_type = task_type
            self._pending_front_task_at = float(task.get("queuedAt") or time.time())
        if task_type == "INTERACT_PRODUCT":
            self._interact_task_issued_at = time.time()
            self._interact_task_phase = str(task.get("phase") or "")
        if task_type == "LOGIN_WITH_PASSWORD":
            self._leased_login_task_id = ""
            self._leased_login_task_at = 0.0
        if task_type not in {
            "DONE",
            "LOGIN_WITH_PASSWORD",
            "CHECK_LOGIN",
            "IMPORT_COOKIES",
            "WAIT_LOGIN_RESULT",
            "POST_LOGIN_FINISH",
        }:
            self._last_retryable_task_type = task_type
            self._last_retryable_task_data = dict(data or {})
        print(f"AUTOMATION_TASK_QUEUED: {task_type}", flush=True)

    def get_next_task(self) -> Optional[Dict[str, Any]]:
        with self._lock:
            if self._stopped or self._paused or not self._pending:
                return None
            task = self._pending.pop(0)
            if self._pending:
                front = self._pending[0]
                self._pending_front_task_id = str(front.get("id") or "")
                self._pending_front_task_type = str(front.get("type") or "")
                self._pending_front_task_at = float(front.get("queuedAt") or time.time())
            else:
                self._pending_front_task_id = ""
                self._pending_front_task_type = ""
                self._pending_front_task_at = 0.0
            task_type = str(task.get("type") or "")
            if task_type in {"CHECK_LOGIN", "IMPORT_COOKIES", "LOGIN_WITH_PASSWORD", "POST_LOGIN_FINISH"}:
                self._leased_general_task_id = str(task.get("id") or "")
                self._leased_general_task_type = task_type
                self._leased_general_task_at = time.time()
            if task_type == "LOGIN_WITH_PASSWORD":
                self._leased_login_task_id = str(task.get("id") or "")
                self._leased_login_task_at = time.time()
                print(f"AUTOMATION_LOGIN_TASK_LEASED: id={self._leased_login_task_id}", flush=True)
            return task

    def complete_task(self, payload: Dict[str, Any]) -> None:
        task_id = str(payload.get("taskId") or "")
        task_type = str(payload.get("type") or "")
        result = payload.get("result") if isinstance(payload.get("result"), dict) else {}
        status = str(payload.get("status") or result.get("status") or "DONE")
        with self._lock:
            if task_id in self._completed:
                print(f"AUTOMATION_STALE_RESULT_IGNORED: {task_type} id={task_id} reason=duplicate", flush=True)
                return
            is_active_general = bool(task_id) and task_id == self._leased_general_task_id
            is_active_login = bool(task_id) and task_id == self._leased_login_task_id
            if self.done_queued and not (
                task_type in {"LOGIN_WITH_PASSWORD", "POST_LOGIN_FINISH", "WAIT_LOGIN_RESULT"}
                and (status or "").upper() == "LOGGED_IN"
                and self._login_result_verified(result)
            ):
                print(f"AUTOMATION_STALE_RESULT_IGNORED: {task_type} id={task_id} reason=done", flush=True)
                return
            if self._paused and not (task_type in {"DONE"}):
                print(f"AUTOMATION_STALE_RESULT_IGNORED: {task_type} id={task_id} reason=paused", flush=True)
                return
            if (
                self._captcha_retry_task_id
                and task_id
                and task_id != self._captcha_retry_task_id
                and task_type in {
                    "INTERACT_PRODUCT",
                    "SCROLL_PRODUCT",
                    "OPEN_PRODUCT",
                    "VIEW_SHOP",
                    "SCROLL_SHOP",
                    "FOLLOW_SHOP",
                    "SEARCH_KEYWORD",
                }
            ):
                print(f"AUTOMATION_STALE_RESULT_IGNORED: {task_type} id={task_id} reason=captcha_retry", flush=True)
                if task_id:
                    self._completed.add(task_id)
                return
            if task_id and task_id == self._captcha_retry_task_id:
                self._captcha_retry_task_id = ""
            if task_id:
                self._completed.add(task_id)
            if not task_id or is_active_general:
                self._leased_general_task_id = ""
                self._leased_general_task_type = ""
                self._leased_general_task_at = 0.0
            if task_type == "LOGIN_WITH_PASSWORD" and (not task_id or is_active_login):
                self._leased_login_task_id = ""
                self._leased_login_task_at = 0.0
            if task_type in {"LOGIN_WITH_PASSWORD", "POST_LOGIN_FINISH", "WAIT_LOGIN_RESULT"} and (status or "").upper() == "LOGGED_IN" and self._login_result_verified(result):
                self._post_login_success_seen = True
                self._post_login_finish_deadline = 0.0
                self.awaiting_post_login = False
                self.post_login_finish_queued = False
            print(f"AUTOMATION_RESULT: {task_type} status={status} result={json.dumps(result, ensure_ascii=False)}", flush=True)
            self.schedule_next(task_type, status, result)

    def _classify_login_risk_from_href(self, href: str) -> str:
        raw = href or ""
        try:
            path = (urlparse(raw).path or "").lower()
        except Exception:
            path = raw.lower().split("?", 1)[0]
        if "/verify/traffic" in path:
            return ""
        if "/verify/captcha" in path or "/captcha" in path:
            return "NEED_CAPTCHA"
        if "/verify/email-link" in path:
            return "NEED_VERIFY"
        return ""

    def _classify_login_risk_from_log(self, message: str, href: str) -> str:
        from_href = self._classify_login_risk_from_href(href)
        if from_href:
            return from_href
        msg = (message or "").lower()
        if "login_blocked status=need_captcha" in msg:
            return "NEED_CAPTCHA"
        if "login_blocked status=need_verify" in msg:
            return "NEED_VERIFY"
        if "login_blocked status=need_otp" in msg:
            return "NEED_OTP"
        if "traffic_verify_login_gate" in msg or "traffic_verify_gate" in msg:
            return ""
        if "please verify your identity" in msg:
            return "NEED_VERIFY"
        if "login_blocked status=account_locked" in msg:
            return "ACCOUNT_LOCKED"
        if "your login attempt has been rejected due to unusual activities in your account" in msg:
            return "ACCOUNT_LOCKED"
        if "due to unusual activities" in msg:
            return "ACCOUNT_LOCKED"
        if "your account has been temporarily restricted due to automated tools detected" in msg:
            return "ACCOUNT_LOCKED"
        if "restricted due to automated tools detected" in msg:
            return "ACCOUNT_LOCKED"
        if "password is incorrect, please try again" in msg:
            return "ACCOUNT_LOCKED"
        if "incorrect, please try again" in msg:
            return "ACCOUNT_LOCKED"
        return ""

    def queue_login_blocked(self, risk_status: str) -> None:
        risk = (risk_status or "").upper()
        close_browser = risk in {"NEED_CAPTCHA", "NEED_VERIFY", "ACCOUNT_LOCKED", "NEED_OTP"}
        print(
            f"AUTOMATION_NICK_STATUS: risk={risk} close={1 if close_browser else 0}",
            flush=True,
        )
        self._paused = True
        self.awaiting_post_login = False
        self._captcha_retry_task_id = ""
        self._pending.clear()
        self._pending_front_task_id = ""
        self._pending_front_task_type = ""
        self._pending_front_task_at = 0.0
        if close_browser:
            print("AUTOMATION_CLOSE_BROWSER", flush=True)
            self.queue_done(immediate=True)
        else:
            print(f"AUTOMATION_PAUSED: {risk}", flush=True)

    def _login_already_queued(self) -> bool:
        if self._leased_login_task_id:
            return True
        if str(self._pending_front_task_type or "") == "LOGIN_WITH_PASSWORD":
            return True
        return any(str(task.get("type") or "") == "LOGIN_WITH_PASSWORD" for task in self._pending)

    def _enqueue_buyer_login(self, reason: str) -> None:
        creds = self._login_with_password_task()
        already = self._login_already_queued()
        if not (creds["user"] and creds["pass"]):
            self.queue_login_failed_done()
            return
        self._paused = False
        self.awaiting_post_login = False
        self.post_login_finish_queued = False
        self.login_attempted = True
        if self._login_flow_started_at <= 0:
            self._login_flow_started_at = time.time()
        print(f"AUTOMATION_PRE_LOGIN_RISK_TO_LOGIN: {reason}", flush=True)
        if already:
            return
        self.enqueue("LOGIN_WITH_PASSWORD", creds)

    def _retry_last_task_after_captcha(self) -> None:
        task_type = str(self._last_retryable_task_type or "").strip()
        data = dict(self._last_retryable_task_data or {})
        self._paused = False
        self._skip_next_risk_status = True
        self.waiting_product_content = False
        self.waiting_search_content = False
        self.waiting_shop_content = False
        self._pending.clear()
        self._pending_front_task_id = ""
        self._pending_front_task_type = ""
        self._pending_front_task_at = 0.0
        if not task_type:
            print("AUTOMATION_CAPTCHA_RETRY: attempt=1 task=OPEN_HOME fallback=1", flush=True)
            self.enqueue("OPEN_HOME", {})
            if self._pending:
                self._captcha_retry_task_id = str(self._pending[-1].get("id") or "")
            return
        print(f"AUTOMATION_CAPTCHA_RETRY: attempt={self._post_login_captcha_retries} task={task_type}", flush=True)
        self.enqueue(task_type, data)
        if self._pending:
            self._captcha_retry_task_id = str(self._pending[-1].get("id") or "")

    def _apply_nick_risk(self, risk_status: str, source: str, task_type: str = "") -> str:
        risk = (risk_status or "").upper()
        if not risk:
            return "none"
        if not self.session_logged_in and risk in {"NEED_CAPTCHA", "ACCOUNT_LOCKED"}:
            self._enqueue_buyer_login(f"risk={risk} source={source} task={task_type}")
            return "login"
        if self.session_logged_in and risk == "NEED_CAPTCHA":
            if self._skip_next_risk_status:
                self._skip_next_risk_status = False
                return "skip"
            if self._post_login_captcha_retries < 1:
                self._post_login_captcha_retries += 1
                self._retry_last_task_after_captcha()
                return "retry"
            print("AUTOMATION_CAPTCHA_RETRY_EXHAUSTED", flush=True)
        self.queue_login_blocked(risk)
        return "block"

    def schedule_next(self, task_type: str, status: str, result: Dict[str, Any]) -> None:
        status_upper = (status or "").upper()
        if status_upper in {"NEED_CAPTCHA", "NEED_OTP", "NEED_VERIFY", "ACCOUNT_LOCKED"}:
            self._apply_nick_risk(status_upper, "schedule_next", task_type)
            return
        if status_upper in {"BLOCKED", "NETWORK_ERROR", "ERROR"}:
            self._paused = True
            print(f"AUTOMATION_PAUSED: {status_upper}", flush=True)
            return
        if task_type == "OPEN_HOME":
            if self._open_home_for_next_keyword:
                self._open_home_for_next_keyword = False
                self._resume_keyword_after_home()
                return
            if status_upper == "NEED_LOGIN":
                print("AUTOMATION_OPEN_HOME_NEED_LOGIN: traffic_gate_or_login_page", flush=True)
            self.enqueue("CHECK_LOGIN", {})
            return
        if task_type == "CHECK_LOGIN":
            login_proof = bool(result.get("loginProof")) and bool(result.get("hasNavbarUsername"))
            if result.get("hasLoginLink"):
                login_proof = False
            if status_upper == "LOGGED_IN" and login_proof:
                self.session_logged_in = True
                self.queue_after_login()
                return
            if status_upper == "LOGGED_IN" and not login_proof:
                print("AUTOMATION_CHECK_LOGIN_FALSE_POSITIVE", flush=True)
            has_cookie = bool((self.payload.get("cookie") or "").strip())
            has_user = bool(normalize_shopee_login_user(str(self.payload.get("user") or "")))
            has_pass = bool(str(self.payload.get("password") or "").strip())
            login_form_ready = bool(result.get("loginFormReady")) or bool(result.get("loginFormPartial"))
            msg = str(result.get("message") or "")
            if self._queue_cookie_import_if_available():
                return
            if (
                status_upper == "NEED_LOGIN"
                and not login_form_ready
                and msg.upper() == "TRAFFIC_LOGIN_FORM_PENDING"
            ):
                self.traffic_form_wait_rounds += 1
                if self.traffic_form_wait_rounds < 4:
                    self.enqueue("CHECK_LOGIN", {"awaitLoginForm": True})
                    return
                self.queue_login_failed_done()
                return
            self._log_cookie_import_skip_if_needed()
            self.queue_login_or_done()
            return
        if task_type == "IMPORT_COOKIES":
            if bool(result.get("spcFMatched")):
                self.cookie_import_verified = True
            elif self._queue_cookie_import_if_available():
                return
            self.enqueue("CHECK_LOGIN", {"reloadAfterCookies": True})
            return
        if task_type == "LOGIN_WITH_PASSWORD":
            if self._login_flow_started_at <= 0:
                self._login_flow_started_at = time.time()
            if status_upper == "LOGIN_SUBMITTED":
                self.awaiting_post_login = True
                self.post_login_finish_queued = False
                self._login_submitted_at = time.time()
                self._post_login_finish_early_at = self._login_submitted_at + 7.0
                print("AUTOMATION_LOGIN_SUBMITTED: await is_from_login", flush=True)
                return
            if status_upper == "NAVIGATED_LOGIN":
                self.enqueue("LOGIN_WITH_PASSWORD", self._login_with_password_task())
                return
            if status_upper == "LOGGED_IN" and self._login_result_verified(result):
                self.login_form_retries = 0
                self.login_wait_retries = 0
                self.post_submit_retries = 0
                self._leased_login_task_retries = 0
                self.post_login_probe_queued = False
                self.session_logged_in = True
                self.queue_after_login()
                return
            if status_upper == "LOGGED_IN":
                print("AUTOMATION_LOGIN_NO_PROOF", flush=True)
                self.enqueue("WAIT_LOGIN_RESULT", {})
                return
            msg = str(result.get("message") or "")
            retryable_login_messages = {
                "LOGIN_FORM_NOT_FOUND",
                "LOGIN_BUTTON_NOT_FOUND",
                "LOGIN_BUTTON_DISABLED",
                "LOGIN_INPUT_FILL_INCOMPLETE",
                "LOGIN_FLOW_TIMEOUT",
                "LOGIN_TASK_TIMEOUT",
            }
            if status_upper == "NEED_LOGIN" and msg in retryable_login_messages:
                if msg == "LOGIN_FLOW_TIMEOUT":
                    print("AUTOMATION_LOGIN_FLOW_TIMEOUT: retry login", flush=True)
                if self.login_form_retries < 5:
                    self.login_form_retries += 1
                    print(f"AUTOMATION_LOGIN_RETRY: stage=form_submit attempt={self.login_form_retries} message={msg}", flush=True)
                    self.enqueue("LOGIN_WITH_PASSWORD", self._login_with_password_task())
                    return
                self.queue_login_failed_done()
                return
            self.login_form_retries = 0
            self.enqueue("WAIT_LOGIN_RESULT", {})
            return
        if task_type == "POST_LOGIN_FINISH":
            self.awaiting_post_login = False
            self.post_login_finish_queued = False
            self._post_login_finish_deadline = 0.0
            if status_upper == "LOGGED_IN" and self._login_result_verified(result):
                self.login_wait_retries = 0
                self.post_submit_retries = 0
                self._leased_login_task_retries = 0
                self.session_logged_in = True
                self._login_flow_started_at = 0.0
                self.queue_after_login()
                return
            if status_upper == "NEED_LOGIN" and self.login_wait_retries < 3:
                self.login_wait_retries += 1
                if self._login_submitted_at > 0:
                    self.post_submit_retries += 1
                print(f"AUTOMATION_LOGIN_RETRY: stage=post_submit attempt={self.login_wait_retries} message={str(result.get('message') or '')}", flush=True)
                self.post_login_probe_queued = False
                self.awaiting_post_login = False
                self.post_login_finish_queued = False
                self._login_submitted_at = 0.0
                self.enqueue("LOGIN_WITH_PASSWORD", self._login_with_password_task())
                return
            self.queue_login_failed_done()
            return
        if task_type == "WAIT_LOGIN_RESULT":
            if status_upper == "LOGGED_IN" and self._login_result_verified(result):
                self.login_wait_retries = 0
                self.post_submit_retries = 0
                self._leased_login_task_retries = 0
                self.session_logged_in = True
                self._login_flow_started_at = 0.0
                self.queue_after_login()
                return
            if status_upper == "NEED_LOGIN" and self.login_wait_retries < 4:
                self.login_wait_retries += 1
                print(f"AUTOMATION_LOGIN_RETRY: stage=wait_result attempt={self.login_wait_retries} message={str(result.get('message') or '')}", flush=True)
                self.enqueue("LOGIN_WITH_PASSWORD", self._login_with_password_task())
                return
            self.queue_login_failed_done()
            return
        if task_type == "SEARCH_KEYWORD":
            if not self.session_logged_in:
                print("AUTOMATION_SEARCH_BLOCKED_NOT_LOGGED_IN", flush=True)
                self.queue_login_failed_done()
                return
            if status_upper == "NAVIGATING_SEARCH":
                self.waiting_search_content = True
                self.search_target_keyword = str(result.get("keyword") or self.current_item.get("keyword") or "")
                self._search_wait_deadline = time.time() + 45.0
                print(f"AUTOMATION_WAITING_SEARCH_CONTENT: keyword={self.search_target_keyword}", flush=True)
                return
            if status_upper in {"DONE", "NAVIGATED_SEARCH"}:
                self.queue_product_or_done()
            else:
                keyword = str(result.get("keyword") or self.current_item.get("keyword") or "")
                if keyword:
                    print(f"AUTOMATION_SEARCH_RETRY_FALLBACK: {keyword}", flush=True)
                    self.enqueue("SEARCH_KEYWORD", {"keyword": keyword, "forceUrl": True})
                else:
                    self.queue_product_or_done()
            return
        if task_type == "OPEN_PRODUCT":
            if status_upper == "NAVIGATING_PRODUCT":
                self.waiting_product_content = True
                self.product_target_url = str(result.get("productUrl") or "")
                self._product_wait_deadline = time.time() + 35.0
                print("AUTOMATION_WAITING_PRODUCT_CONTENT: " + self.product_target_url, flush=True)
                return
            self.queue_interact_pre_or_done()
            return
        if task_type == "SCROLL_PRODUCT":
            self.queue_interact_review_or_done()
            return
        if task_type == "INTERACT_PRODUCT":
            self._interact_task_issued_at = 0.0
            self._interact_task_phase = ""
            phase = str(result.get("phase") or "")
            if phase == "preScroll":
                self.queue_scroll_or_done()
                return
            self.queue_shop_or_next()
            return
        if task_type == "SCROLL_SHOP":
            self.queue_next_keyword_or_done()
            return
        if task_type == "VIEW_SHOP":
            if status_upper == "NAVIGATING_SHOP":
                self.waiting_shop_content = True
                self.shop_target_url = str(result.get("shopUrl") or "")
                self._shop_wait_deadline = time.time() + SHOP_CONTENT_WAIT_SEC
                print("AUTOMATION_WAITING_SHOP_CONTENT: " + self.shop_target_url, flush=True)
                return
            self.queue_after_shop_ready()
            return
        if task_type == "FOLLOW_SHOP":
            completed = result.get("completed") if isinstance(result.get("completed"), list) else []
            if "shopScroll" in completed:
                self.shop_scroll_started = True
            self.queue_after_follow_shop()
            return
        if task_type == "DONE":
            self._paused = True
            print("AUTOMATION_DONE", flush=True)

    def _login_with_password_task(self) -> Dict[str, str]:
        return {
            "user": normalize_shopee_login_user(str(self.payload.get("user") or "")),
            "pass": str(self.payload.get("password") or ""),
        }

    def _login_result_verified(self, result: Dict[str, Any]) -> bool:
        if result.get("hasLoginLink"):
            return False
        return bool(result.get("loginProof")) and bool(result.get("hasNavbarUsername"))

    def queue_login_or_done(self) -> None:
        already = self._login_already_queued()
        creds = self._login_with_password_task()
        if already:
            print("AUTOMATION_LOGIN_ALREADY_QUEUED", flush=True)
            return
        if creds["user"] and creds["pass"]:
            if self.login_attempted:
                print("AUTOMATION_LOGIN_ALREADY_ATTEMPTED skip_queue", flush=True)
                return
            self.login_attempted = True
            self._login_flow_started_at = time.time()
            self.enqueue("LOGIN_WITH_PASSWORD", creds)
            return
        self.queue_login_failed_done()

    def queue_login_failed_done(self) -> None:
        elapsed = int(time.time() - self._login_flow_started_at) if self._login_flow_started_at > 0 else -1
        self._pending.clear()
        self._pending_front_task_id = ""
        self._pending_front_task_type = ""
        self._pending_front_task_at = 0.0
        self._leased_general_task_id = ""
        self._leased_general_task_type = ""
        self._leased_general_task_at = 0.0
        self._leased_login_task_id = ""
        self._leased_login_task_at = 0.0
        print(
            f"AUTOMATION_LOGIN_FAILED awaiting={self.awaiting_post_login} post_finish={self.post_login_finish_queued} elapsed={elapsed}s",
            flush=True,
        )
        self.queue_done(immediate=True)

    def queue_after_login(self) -> None:
        if not self.session_logged_in:
            print("AUTOMATION_AFTER_LOGIN_BLOCKED", flush=True)
            self.queue_login_failed_done()
            return
        if self.current_item_index < 0:
            self._begin_first_keyword_in_place()
            return
        self.queue_product_or_done()

    def _begin_first_keyword_in_place(self) -> None:
        if not self.keyword_items:
            self.queue_done()
            return
        self.current_item_index = 0
        self.reset_keyword_state()
        self.current_item = self.keyword_items[0]
        total = len(self.keyword_items)
        keyword = str(self.current_item.get("keyword") or "")
        self.keyword_started_at = time.time()
        print(f"AUTOMATION_KEYWORD_BEGIN: index=1 total={total} after_login=1", flush=True)
        if keyword:
            self.search_started = True
            self.enqueue("SEARCH_KEYWORD", {"keyword": keyword, "index": 1, "total": total, "afterLogin": True})
            return
        self.queue_product_or_done()

    def _resume_keyword_after_home(self) -> None:
        self.reset_keyword_state()
        self.current_item = self.keyword_items[self.current_item_index]
        total = len(self.keyword_items)
        keyword = str(self.current_item.get("keyword") or "")
        self.keyword_started_at = time.time()
        print(f"AUTOMATION_KEYWORD_BEGIN: index={self.current_item_index + 1} total={total}", flush=True)
        if keyword and not self.search_started:
            self.search_started = True
            self.enqueue("SEARCH_KEYWORD", {"keyword": keyword, "index": self.current_item_index + 1, "total": total})
            return
        self.queue_product_or_done()

    def queue_next_keyword_or_done(self) -> None:
        if self.current_item_index >= 0 and self.current_item:
            total = len(self.keyword_items)
            print(f"AUTOMATION_KEYWORD_DONE: {self.current_item_index + 1}/{total}", flush=True)
        self.current_item_index += 1
        if self.current_item_index >= len(self.keyword_items):
            self.queue_done()
            return
        self._open_home_for_next_keyword = True
        print("AUTOMATION_NEXT_KEYWORD_VIA_HOME", flush=True)
        self.enqueue("OPEN_HOME", {"viaLogo": True})

    def queue_product_or_done(self) -> None:
        if not self.product_started:
            self.product_started = True
            max_pages = int(self.payload.get("maxSearchPages") or 2)
            max_pages = max(1, max_pages)
            self.enqueue(
                "OPEN_PRODUCT",
                {
                    "productUrl": self.current_item.get("productUrl", "") or "",
                    "productId": self.current_item.get("productId", "") or "",
                    "keyword": str(self.current_item.get("keyword") or ""),
                    "vitri": self.current_item.get("vitri"),
                    "maxSearchPages": max_pages,
                },
            )
            return
        self.queue_interact_pre_or_done()

    def _product_action_flags(self) -> Dict[str, bool]:
        actions = dict(self.payload.get("actions") or {})
        return {
            "viewMedia": bool(actions.get("viewMedia")),
            "like": bool(actions.get("like")),
            "addToCart": bool(actions.get("addToCart")),
            "review": bool(actions.get("review")),
        }

    def queue_interact_pre_or_done(self) -> None:
        flags = self._product_action_flags()
        if not self.interact_pre_started and (flags["viewMedia"] or flags["like"] or flags["addToCart"]):
            self.interact_pre_started = True
            print(
                f"AUTOMATION_PRODUCT_PRE: viewMedia={flags['viewMedia']} like={flags['like']} addToCart={flags['addToCart']}",
                flush=True,
            )
            self.enqueue(
                "INTERACT_PRODUCT",
                {
                    "actions": self.payload.get("actions") or {},
                    "phase": "preScroll",
                    "productUrl": str(self.product_target_url or self.current_item.get("productUrl") or "").strip(),
                },
            )
            return
        self.queue_scroll_or_done()

    def queue_scroll_or_done(self) -> None:
        if not self.scroll_started:
            self.scroll_started = True
            self.enqueue(
                "SCROLL_PRODUCT",
                {
                    "actions": self.payload.get("actions") or {},
                    "productUrl": str(self.product_target_url or self.current_item.get("productUrl") or "").strip(),
                    "productViewPauseMin": int(self.payload.get("productViewPauseMin") or 15),
                    "productViewPauseMax": int(self.payload.get("productViewPauseMax") or 25),
                },
            )
            return
        self.queue_interact_review_or_done()

    def queue_interact_review_or_done(self) -> None:
        flags = self._product_action_flags()
        if not self.interact_review_started and flags["review"]:
            self.interact_review_started = True
            actions = dict(self.payload.get("actions") or {})
            self.enqueue(
                "INTERACT_PRODUCT",
                {
                    "actions": actions,
                    "phase": "review",
                    "productUrl": str(self.product_target_url or self.current_item.get("productUrl") or "").strip(),
                },
            )
            return
        self.queue_shop_or_next()

    def queue_shop_or_next(self) -> None:
        actions = dict(self.payload.get("actions") or {})
        if actions.get("viewShop") and not self.shop_started:
            self.shop_started = True
            self.enqueue("VIEW_SHOP", {"actions": actions})
            return
        self.queue_follow_shop_or_next()

    def queue_after_shop_ready(self) -> None:
        actions = dict(self.payload.get("actions") or {})
        if actions.get("followShop") and not self.follow_started:
            self.follow_started = True
            self.enqueue("FOLLOW_SHOP", {"actions": actions})
            return
        self.queue_after_follow_shop()

    def queue_after_follow_shop(self) -> None:
        actions = dict(self.payload.get("actions") or {})
        if actions.get("viewShop") and not self.shop_scroll_started:
            self.shop_scroll_started = True
            self.enqueue("SCROLL_SHOP", {"actions": actions})
            return
        self.queue_next_keyword_or_done()

    def queue_follow_shop_or_next(self) -> None:
        actions = dict(self.payload.get("actions") or {})
        if actions.get("followShop") and not self.follow_started:
            self.follow_started = True
            self.enqueue("FOLLOW_SHOP", {"actions": actions})
            return
        self.queue_next_keyword_or_done()

    def queue_done(self, immediate: bool = False) -> None:
        if not self.done_queued:
            self.done_queued = True
            self._pending.clear()
            self._pending_front_task_id = ""
            self._pending_front_task_type = ""
            self._pending_front_task_at = 0.0
            self._paused = True
            print("AUTOMATION_DONE", flush=True)

    def force_advance_keyword_after_timeout(self) -> None:
        with self._lock:
            if self._stopped or self.done_queued or self.current_item_index < 0:
                return
            elapsed = time.time() - (self.keyword_started_at or time.time())
            if elapsed < KEYWORD_TIME_LIMIT_SEC:
                return
            idx = self.current_item_index + 1
            print(f"AUTOMATION_KEYWORD_TIMEOUT: item={idx} limit={KEYWORD_TIME_LIMIT_SEC}s", flush=True)
            self._pending.clear()
            self.waiting_shop_content = False
            self.waiting_product_content = False
            self.waiting_search_content = False
            self._shop_wait_deadline = 0.0
            self._search_wait_deadline = 0.0
            if self.current_item_index >= 0 and self.current_item:
                total = len(self.keyword_items)
                print(f"AUTOMATION_KEYWORD_DONE: {self.current_item_index + 1}/{total} reason=timeout", flush=True)
            self.current_item_index += 1
            self.keyword_started_at = 0.0
            if self.current_item_index >= len(self.keyword_items):
                self.queue_done()
                return
            self._open_home_for_next_keyword = True
            self.enqueue("OPEN_HOME", {"viaLogo": True})

    def _watchdog_tick(self) -> None:
        if self.waiting_shop_content and self._shop_wait_deadline > 0 and time.time() >= self._shop_wait_deadline:
            self.waiting_shop_content = False
            self._shop_wait_deadline = 0.0
            print("AUTOMATION_SHOP_WAIT_TIMEOUT: proceeding follow/next", flush=True)
            self.queue_after_shop_ready()
            return
        if self.waiting_search_content and getattr(self, "_search_wait_deadline", 0) > 0 and time.time() >= self._search_wait_deadline:
            self.waiting_search_content = False
            self._search_wait_deadline = 0.0
            print("AUTOMATION_SEARCH_WAIT_TIMEOUT: proceeding open product", flush=True)
            self.queue_product_or_done()
            return
        if self.waiting_product_content and getattr(self, "_product_wait_deadline", 0) > 0 and time.time() >= self._product_wait_deadline:
            self.waiting_product_content = False
            self._product_wait_deadline = 0.0
            print("AUTOMATION_PRODUCT_WAIT_TIMEOUT: proceeding interact pre", flush=True)
            self.queue_interact_pre_or_done()
            return
        if (
            self._interact_task_issued_at > 0
            and time.time() - self._interact_task_issued_at > INTERACT_TASK_STALL_SEC
            and self.interact_pre_started
            and not self.scroll_started
        ):
            phase = self._interact_task_phase or "preScroll"
            elapsed = int(time.time() - self._interact_task_issued_at)
            print(f"AUTOMATION_INTERACT_TASK_STALL: phase={phase} elapsed={elapsed}s", flush=True)
            self._interact_task_issued_at = 0.0
            self._interact_task_phase = ""
            if phase == "preScroll":
                self.queue_scroll_or_done()
            else:
                self.queue_shop_or_next()
            return
        if (
            self._leased_general_task_id
            and self._leased_general_task_at > 0
            and not self.session_logged_in
            and not self.done_queued
            and self._leased_general_task_type in {"CHECK_LOGIN", "IMPORT_COOKIES", "POST_LOGIN_FINISH"}
            and time.time() - self._leased_general_task_at > 35.0
        ):
            elapsed = int(time.time() - self._leased_general_task_at)
            task_type = self._leased_general_task_type
            if task_type == "POST_LOGIN_FINISH" and self._post_login_finish_extensions < 2:
                self._post_login_finish_extensions += 1
                self._leased_general_task_at = time.time()
                self._post_login_finish_deadline = time.time() + 45.0
                print(f"AUTOMATION_POST_LOGIN_WATCHDOG_EXTEND: elapsed={elapsed}s attempt={self._post_login_finish_extensions}", flush=True)
                return
            print(f"AUTOMATION_LOGIN_FLOW_TIMEOUT: watchdog reason=leased_task_no_result task={task_type} elapsed={elapsed}s", flush=True)
            self._leased_general_task_id = ""
            self._leased_general_task_type = ""
            self._leased_general_task_at = 0.0
            if task_type == "IMPORT_COOKIES" and self._queue_cookie_import_if_available():
                return
            if not self.login_attempted and task_type in {"CHECK_LOGIN", "IMPORT_COOKIES"}:
                self.queue_login_or_done()
                return
            self.queue_login_failed_done()
            return
        if (
            self._pending_front_task_id
            and self._pending_front_task_at > 0
            and not self.session_logged_in
            and not self.done_queued
            and self._pending_front_task_type in {"CHECK_LOGIN", "IMPORT_COOKIES", "LOGIN_WITH_PASSWORD", "POST_LOGIN_FINISH"}
            and time.time() - self._pending_front_task_at > 35.0
        ):
            elapsed = int(time.time() - self._pending_front_task_at)
            task_type = self._pending_front_task_type
            print(f"AUTOMATION_LOGIN_FLOW_TIMEOUT: watchdog reason=pending_task_not_picked task={task_type} elapsed={elapsed}s", flush=True)
            self._pending.clear()
            self._pending_front_task_id = ""
            self._pending_front_task_type = ""
            self._pending_front_task_at = 0.0
            if task_type == "IMPORT_COOKIES" and self._queue_cookie_import_if_available():
                return
            if not self.login_attempted and task_type in {"CHECK_LOGIN", "IMPORT_COOKIES"}:
                self.queue_login_or_done()
                return
            self.queue_login_failed_done()
            return
        if (
            self._leased_login_task_id
            and self._leased_login_task_at > 0
            and not self.session_logged_in
            and time.time() - self._leased_login_task_at > 10.0
        ):
            elapsed = int(time.time() - self._leased_login_task_at)
            print(f"AUTOMATION_LOGIN_FLOW_TIMEOUT: watchdog reason=leased_task_no_result elapsed={elapsed}s", flush=True)
            self._leased_login_task_id = ""
            self._leased_login_task_at = 0.0
            if not self.post_login_probe_queued:
                self.post_login_probe_queued = True
                self.awaiting_post_login = False
                self.post_login_finish_queued = True
                self._post_login_finish_deadline = time.time() + 60.0
                print("AUTOMATION_LOGIN_PROBE_AFTER_LEASE_TIMEOUT", flush=True)
                self.enqueue("POST_LOGIN_FINISH", {})
                return
            if self._leased_login_task_retries < 6:
                self._leased_login_task_retries += 1
                self.post_login_probe_queued = False
                self.awaiting_post_login = False
                self.post_login_finish_queued = False
                self._login_submitted_at = 0.0
                self._login_flow_started_at = time.time()
                print(f"AUTOMATION_LOGIN_RETRY: stage=leased_task attempt={self._leased_login_task_retries}", flush=True)
                self.enqueue("LOGIN_WITH_PASSWORD", self._login_with_password_task())
                return
            self.queue_login_failed_done()
            return
        if self.awaiting_post_login and not self.post_login_finish_queued:
            now = time.time()
            if self._post_login_finish_early_at > 0 and now >= self._post_login_finish_early_at:
                print("AUTOMATION_POST_LOGIN_EARLY_FINISH", flush=True)
                self._queue_post_login_finish_once()
                return
            if self._login_submitted_at > 0 and now - self._login_submitted_at > 24.0:
                print("AUTOMATION_POST_LOGIN_WATCHDOG", flush=True)
                self._queue_post_login_finish_once()
                return
        if (
            self._post_login_finish_deadline > 0
            and time.time() >= self._post_login_finish_deadline
            and not self.session_logged_in
        ):
            if self._post_login_success_seen:
                self.session_logged_in = True
                self._post_login_finish_deadline = 0.0
                self.awaiting_post_login = False
                self.post_login_finish_queued = False
                print("AUTOMATION_POST_LOGIN_ALREADY_LOGGED_IN", flush=True)
                self.queue_after_login()
                return
            if self._leased_general_task_type == "POST_LOGIN_FINISH" and self._post_login_finish_extensions < 2:
                self._post_login_finish_extensions += 1
                self._post_login_finish_deadline = time.time() + 35.0
                print(f"AUTOMATION_POST_LOGIN_WATCHDOG_EXTEND: deadline attempt={self._post_login_finish_extensions}", flush=True)
                return
            self._post_login_finish_deadline = 0.0
            self.awaiting_post_login = False
            self.post_login_finish_queued = False
            if self.post_submit_retries < 2:
                self.post_submit_retries += 1
                print(f"AUTOMATION_POST_LOGIN_FINISH_TIMEOUT: retry login attempt={self.post_submit_retries}", flush=True)
                self._login_submitted_at = 0.0
                self.enqueue("LOGIN_WITH_PASSWORD", self._login_with_password_task())
                return
            print("AUTOMATION_POST_LOGIN_FINISH_TIMEOUT: login failed", flush=True)
            self.queue_login_failed_done()
            return
        if (
            self.login_attempted
            and not self.session_logged_in
            and self._login_flow_started_at > 0
            and time.time() - self._login_flow_started_at > 120.0
            and not self._leased_login_task_id
            and not self.awaiting_post_login
            and not self.post_login_finish_queued
        ):
            self._login_flow_started_at = 0.0
            if self._login_submitted_at <= 0:
                print("AUTOMATION_LOGIN_FLOW_TIMEOUT: watchdog reason=form_or_submit_stuck", flush=True)
            else:
                print("AUTOMATION_LOGIN_FLOW_TIMEOUT: watchdog reason=post_submit_no_session", flush=True)
            self.queue_login_failed_done()
            return
        self.force_advance_keyword_after_timeout()

    def _queue_post_login_finish_once(self) -> None:
        with self._lock:
            if self.post_login_finish_queued or self.session_logged_in:
                return
            self.post_login_finish_queued = True
            self.awaiting_post_login = False
            self._post_login_finish_early_at = 0.0
            self._post_login_finish_deadline = time.time() + 70.0
            self.enqueue("POST_LOGIN_FINISH", {})

    def handle_log(self, payload: Dict[str, Any]) -> None:
        message = str(payload.get("message") or "")
        href = str(payload.get("href") or "")
        if not self.done_queued:
            risk = self._classify_login_risk_from_href(href)
            if not risk and (
                not self.session_logged_in
                or message.startswith("LOGIN_BLOCKED")
                or message.startswith("PRODUCT_CAPTCHA_AFTER_")
            ):
                risk = self._classify_login_risk_from_log(message, href)
            if not risk and message.startswith("PRODUCT_CAPTCHA_AFTER_"):
                risk = "NEED_CAPTCHA"
            if risk:
                action = self._apply_nick_risk(risk, "handle_log")
                if action != "login":
                    return
        if self._leased_login_task_id and message.startswith("BUYER_LOGIN_PAGE_READY"):
            self._leased_login_task_id = ""
            self._leased_login_task_at = 0.0
            if not self.post_login_probe_queued:
                self.post_login_probe_queued = True
                self.post_login_finish_queued = True
                self._post_login_finish_deadline = time.time() + 60.0
                print("AUTOMATION_LOGIN_PROBE_AFTER_FORM_READY", flush=True)
                self.enqueue("POST_LOGIN_FINISH", {})
            return
        if message.startswith("LOGIN_SUCCESS_DETECTED"):
            self._post_login_success_seen = True
            self.session_logged_in = True
            self.awaiting_post_login = False
            self.post_login_finish_queued = False
            self._post_login_finish_deadline = 0.0
            self._leased_general_task_id = ""
            self._leased_general_task_type = ""
            self._leased_general_task_at = 0.0
            self._leased_login_task_id = ""
            self._leased_login_task_at = 0.0
        if self.awaiting_post_login and "is_from_login" in href and message in {"CONTENT_READY", "LOGIN_POST_REDIRECT"}:
            print("AUTOMATION_POST_LOGIN_REDIRECT: " + href, flush=True)
            self._queue_post_login_finish_once()
            return
        href_l = href.lower()
        is_product_detail = (
            "-i." in href_l
            or "/i." in href_l
            or "/product/" in href_l
            or bool(re.search(r"i\.\d+\.\d+", href_l))
        )
        is_search_page = "/search" in href and "keyword=" in href
        if self.waiting_search_content and message == "CONTENT_READY" and is_search_page:
            self.waiting_search_content = False
            self._search_wait_deadline = 0.0
            print("AUTOMATION_SEARCH_CONTENT_READY: " + href, flush=True)
            self.queue_product_or_done()
            return
        if self.waiting_product_content and message == "CONTENT_READY" and is_product_detail:
            self.waiting_product_content = False
            print("AUTOMATION_PRODUCT_CONTENT_READY: " + href, flush=True)
            self.queue_interact_pre_or_done()
            return
        if self.waiting_shop_content and message == "CONTENT_READY" and not is_product_detail:
            self.waiting_shop_content = False
            self._shop_wait_deadline = 0.0
            self.shop_target_url = href
            print("AUTOMATION_SHOP_CONTENT_READY: " + href, flush=True)
            self.queue_after_shop_ready()

    def start(self) -> None:
        bridge = self

        class Handler(BaseHTTPRequestHandler):
            def _send_json(self, value: Any, status: int = 200) -> None:
                data = json.dumps(value, ensure_ascii=False).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json; charset=utf-8")
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Headers", "Content-Type, X-Shopee-Automation-Token, X-Shopee-Automation-Session")
                self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)

            def _authorized(self) -> bool:
                return self.headers.get("X-Shopee-Automation-Token") == bridge.token and self.headers.get("X-Shopee-Automation-Session") == bridge.session_id

            def do_OPTIONS(self) -> None:
                self._send_json({"ok": True})

            def do_GET(self) -> None:
                if not self._authorized():
                    self._send_json({"error": "unauthorized"}, 401)
                    return
                if self.path.startswith("/task"):
                    task = bridge.get_next_task()
                    self._send_json(task or {"id": "", "type": ""})
                    return
                self._send_json({"error": "not_found"}, 404)

            def do_POST(self) -> None:
                if not self._authorized():
                    self._send_json({"error": "unauthorized"}, 401)
                    return
                length = int(self.headers.get("Content-Length") or "0")
                raw = self.rfile.read(length).decode("utf-8", errors="replace") if length else "{}"
                try:
                    payload = json.loads(raw or "{}")
                except Exception:
                    payload = {}
                if self.path.startswith("/result"):
                    bridge.complete_task(payload)
                    self._send_json({"ok": True})
                    return
                if self.path.startswith("/log"):
                    bridge.handle_log(payload)
                    message = str(payload.get("message") or "")
                    if message:
                        # Compact stdout for Form1 txtLog/grid (full payload not needed; handle_log already ran).
                        print(
                            "AUTOMATION_LOG: "
                            + json.dumps(
                                {"level": str(payload.get("level") or "info"), "message": message},
                                ensure_ascii=False,
                            ),
                            flush=True,
                        )
                    self._send_json({"ok": True})
                    return
                if self.path.startswith("/pause-state"):
                    bridge._paused = True
                    self._send_json({"ok": True})
                    return
                self._send_json({"error": "not_found"}, 404)

            def log_message(self, format: str, *args: Any) -> None:
                return

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = int(self.httpd.server_address[1])
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self._product_wait_deadline = 0.0

        def watchdog_loop() -> None:
            while not self._stopped:
                try:
                    self._watchdog_tick()
                except Exception:
                    pass
                time.sleep(0.75 if self.awaiting_post_login else 1.25)

        self.watchdog_thread = threading.Thread(target=watchdog_loop, daemon=True)
        self.watchdog_thread.start()
        print(f"AUTOMATION_BRIDGE: port={self.port} session={self.session_id}", flush=True)
    def stop(self) -> None:
        self._stopped = True
        if self.httpd is not None:
            try:
                self.httpd.shutdown()
                self.httpd.server_close()
            except Exception:
                pass


def prepare_automation_extension(profile_dir: str, extension_source: str, bridge: AutomationBridge) -> str:
    if not os.path.isdir(extension_source):
        raise FileNotFoundError("Shopee automation extension source not found: " + extension_source)
    extensions_dir = os.path.join(profile_dir, "extensions")
    os.makedirs(extensions_dir, exist_ok=True)
    target_dir = os.path.join(extensions_dir, EXTENSION_ID)
    if os.path.exists(target_dir):
        shutil.rmtree(target_dir, ignore_errors=True)
    shutil.copytree(extension_source, target_dir)
    config_path = os.path.join(target_dir, "bridge_config.js")
    try:
        max_search_pages = max(1, int(bridge.payload.get("maxSearchPages") or 2))
    except (TypeError, ValueError):
        max_search_pages = 2
    config = {
        "port": bridge.port,
        "token": bridge.token,
        "sessionId": bridge.session_id,
        "pollIntervalMs": 400,
        "maxSearchPages": max_search_pages,
    }
    with open(config_path, "w", encoding="utf-8") as fp:
        fp.write("window.SHOPEE_AUTOMATION_CONFIG = ")
        fp.write(json.dumps(config, ensure_ascii=False))
        fp.write(";\n")
    print(f"AUTOMATION_EXTENSION: {target_dir}", flush=True)
    return target_dir


def apply_extension_prefs(prefs: Dict[str, Any]) -> None:
    prefs["xpinstall.signatures.required"] = False
    prefs["extensions.autoDisableScopes"] = 0
    prefs["extensions.enabledScopes"] = 15
    prefs["extensions.installDistroAddons"] = True
    prefs["extensions.webextensions.restrictedDomains"] = ""


def run_raw_browser(
    args: argparse.Namespace,
    firefox_path: str,
    seed: int,
    proxy: Optional[Dict[str, str]],
    humanize: Any,
    should_stop_ref: Dict[str, bool],
) -> int:
    print("LAUNCH_MODE: raw-firefox", flush=True)
    app_base_early = resolve_app_base_dir(getattr(args, "app_base_dir", "") or "")
    os.environ["AUTOSEO_APP_BASE_DIR"] = app_base_early
    raw_profile_dir = args.profile_dir
    temp_profile_dir = ""
    if not args.persistent_context:
        temp_profile_dir = tempfile.mkdtemp(prefix="invisible-tmp-", dir=os.path.dirname(args.profile_dir))
        raw_profile_dir = temp_profile_dir
        print(f"TEMP_PROFILE_DIR: {raw_profile_dir}", flush=True)

    automation_payload = build_automation_payload(args)
    automation_bridge: Optional[AutomationBridge] = None
    if automation_payload and args.launch_mode == "raw":
        automation_bridge = AutomationBridge(automation_payload)
        automation_bridge.start()
        prepare_automation_extension(raw_profile_dir, args.automation_extension_dir, automation_bridge)

    start_hidden = str(getattr(args, "start_browser_hidden", "false")).strip().lower() in ("1", "true", "yes", "on")

    basic_raw_mode = args.launch_mode == "raw-basic"
    explicit_seed = bool((args.seed or "").strip())
    no_pref_off_mode = args.font_preset == "off" and not proxy and not explicit_seed and automation_bridge is None
    if basic_raw_mode or no_pref_off_mode:
        delete_user_js_if_present(raw_profile_dir)
    else:
        # Backup_Invisible_v2: package stealth/WebRTC derived from same --seed as Form1 (not split fpp/host).
        prefs = get_default_stealth_prefs(
            seed=seed,
            pin=None,
            locale=(args.locale or "").strip() or "vi-VN",
            timezone=(args.timezone or "").strip(),
            humanize=humanize,
        )
        if args.font_preset == "windows-vn":
            apply_windows_vn_font_prefs(prefs)
        elif args.font_preset == "off" and explicit_seed:
            keep_minimal_seed_prefs(prefs)
            print("SCREEN_PREFS: stripped (seed without zoom.stealth.screen.*)", flush=True)
        elif args.font_preset == "off":
            strip_all_optional_prefs_for_off_mode(prefs)
        apply_proxy_prefs(proxy, prefs)
        if automation_bridge is not None:
            apply_extension_prefs(prefs)
        # Backup_Invisible_v2: host_ip chỉ từ seed/package — không align LAN máy / netsh / egress env.
        if "zoom.stealth.webrtc.host_ip" in prefs:
            apply_webrtc_lan_candidate_prefs(prefs)
        apply_disable_translations_prefs(prefs)
        if start_hidden:
            apply_hidden_automation_launch_prefs(prefs)
            apply_firefox_hidden_automation_prefs(prefs)
            print("USER_JS_HIDDEN_AUTOMATION: browser.window + timer prefs", flush=True)
        if not parse_bool(getattr(args, "load_images", "true")):
            apply_block_images_prefs(prefs)
            print("USER_JS_BLOCK_IMAGES: permissions.default.image=2", flush=True)
        if prefs:
            write_user_js(raw_profile_dir, prefs)
            print("TRANSLATIONS: disabled via user.js", flush=True)

    navigation_url = get_navigation_url(args)
    raw_command_navigation_url = normalize_url_for_raw_command_line(navigation_url) if navigation_url else ""
    existing_profile_processes = get_firefox_processes_for_profile(raw_profile_dir) if args.persistent_context else []
    reuse_existing_profile = bool(existing_profile_processes)
    if reuse_existing_profile:
        print("PROFILE_REUSE: existing Firefox profile process detected " + json.dumps(existing_profile_processes[:5], ensure_ascii=False), flush=True)
    if start_hidden:
        ensure_browser_window_automation_in_xulstore(raw_profile_dir)
    else:
        ensure_browser_window_maximized_in_xulstore(raw_profile_dir)
    launch_args = [str(firefox_path)]
    if not reuse_existing_profile:
        launch_args.append("-no-remote")
    launch_args.extend(["-profile", raw_profile_dir])
    if start_hidden and not args.headless:
        launch_args.extend(["--window-position", "0,0"])
        print("LAUNCH_HIDDEN_POSITION: 0,0", flush=True)
    if args.headless:
        launch_args.append("-headless")
    if raw_command_navigation_url:
        launch_args.append(raw_command_navigation_url)

    env = os.environ.copy()
    timezone = (args.timezone or "").strip()
    if timezone:
        env["TZ"] = timezone

    print("LAUNCH_BEGIN: raw process", flush=True)
    print("BROWSER_ARGS: " + json.dumps(launch_args, ensure_ascii=False), flush=True)
    process = subprocess.Popen(
        launch_args,
        cwd=raw_profile_dir,
        env=env,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
        encoding="utf-8",
        errors="replace",
    )
    print(f"BROWSER_PID: {process.pid}", flush=True)
    if navigation_url:
        print(f"NAVIGATION_DISPATCHED_RAW: {navigation_url}", flush=True)
    else:
        print("NAVIGATION_SKIPPED: manual/no goto", flush=True)
    if start_hidden:
        time.sleep(1.5)
    else:
        time.sleep(3)
        ensure_browser_window_maximized_in_xulstore(raw_profile_dir)
    prefs_js_path = os.path.join(raw_profile_dir, "prefs.js")
    compatibility_ini_path = os.path.join(raw_profile_dir, "compatibility.ini")
    stdout_sample = ""
    stderr_sample = ""
    if process.poll() is not None:
        try:
            stdout_text, stderr_text = process.communicate(timeout=1)
            stdout_sample = (stdout_text or "")[:2000]
            stderr_sample = (stderr_text or "")[:2000]
        except Exception as ex:
            stderr_sample = "COMMUNICATE_FAILED: " + str(ex)
    if args.run_diagnostics:
        print("DIAGNOSTICS_SKIPPED_RAW: raw Firefox launch has no Playwright page handle", flush=True)
    print("READY", flush=True)

    launcher_exit_logged = False
    try:
        while not should_stop_ref["stop"]:
            if process.poll() is not None:
                profile_processes = get_firefox_processes_for_profile(raw_profile_dir)
                profile_lock_exists = raw_profile_has_active_lock(raw_profile_dir)
                if profile_processes or profile_lock_exists:
                    if not launcher_exit_logged:
                        launcher_exit_logged = True
                    time.sleep(0.5)
                    continue
                return int(process.returncode or 0)
            time.sleep(0.5)
        return 0
    finally:
        if automation_bridge is not None:
            automation_bridge.stop()
        terminate_process(process)
        terminate_profile_firefox_processes(raw_profile_dir)
        if temp_profile_dir:
            shutil.rmtree(temp_profile_dir, ignore_errors=True)


def run_wrapper_browser(
    args: argparse.Namespace,
    seed: int,
    proxy: Optional[Dict[str, str]],
    humanize: Any,
    should_stop_ref: Dict[str, bool],
) -> int:
    print("LAUNCH_MODE: invisible-playwright-wrapper", flush=True)
    invisible = InvisiblePlaywright(
        seed=seed,
        pin=None,
        headless=args.headless,
        proxy=proxy,
        extra_args=list(args.extra_arg or []),
        humanize=humanize,
        locale=(args.locale or "").strip() or "vi-VN",
        timezone=(args.timezone or "").strip(),
        profile_dir=args.profile_dir if args.persistent_context else None,
        prep_recaptcha=args.prep_recaptcha,
    )

    page = None
    print("LAUNCH_BEGIN: wrapper context", flush=True)
    with invisible as browser_or_context:
        print("CONTEXT_ENTERED", flush=True)
        page = context_new_page(browser_or_context, args.persistent_context)
        print("PAGE_CREATED", flush=True)

        navigation_url = get_navigation_url(args)
        if navigation_url:
            try:
                response = page.goto(navigation_url, wait_until="domcontentloaded", timeout=60000)
                status = getattr(response, "status", None) if response is not None else None
                print(f"NAVIGATION_DONE: {navigation_url}" + (f" status={status}" if status else ""), flush=True)
            except Exception as ex:
                print(f"NAVIGATION_FAILED: {type(ex).__name__}: {ex}", flush=True)
        else:
            print("NAVIGATION_SKIPPED: manual/no goto", flush=True)

        if args.run_diagnostics and page is not None:
            run_diagnostics(page)

        print("READY", flush=True)
        while not should_stop_ref["stop"]:
            time.sleep(0.5)

    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--target-url", required=True)
    parser.add_argument("--profile-dir", required=True)
    parser.add_argument("--profile-name", default="TestInvisible")
    parser.add_argument("--seed", default="")
    parser.add_argument("--locale", default="vi-VN")
    parser.add_argument("--timezone", default="Asia/Ho_Chi_Minh")
    parser.add_argument("--humanize", default="true")
    parser.add_argument("--humanize-max-seconds", default="1.5")
    parser.add_argument("--headless", default="false")
    parser.add_argument("--proxy-server", default="")
    parser.add_argument("--proxy-username", default="")
    parser.add_argument("--proxy-password", default="")
    parser.add_argument("--persistent-context", default="true")
    parser.add_argument("--prep-recaptcha", default="false")
    parser.add_argument("--navigation-mode", default="target", choices=["target", "manual", "category"])
    parser.add_argument("--category-url", default="")
    parser.add_argument("--run-diagnostics", default="true")
    parser.add_argument("--launch-mode", default="raw", choices=["raw", "wrapper", "raw-basic"])
    parser.add_argument("--font-preset", default="windows-vn", choices=["windows-vn", "package-default", "off"])
    parser.add_argument("--automation-extension-dir", default="")
    parser.add_argument("--automation-account", default="")
    parser.add_argument("--automation-user", default="")
    parser.add_argument("--automation-password", default="")
    parser.add_argument("--automation-cookie", default="")
    parser.add_argument("--automation-keyword", default="")
    parser.add_argument("--automation-product-url", default="")
    parser.add_argument("--automation-keywords-json", default="")
    parser.add_argument("--automation-payload-file", default="")
    parser.add_argument("--automation-actions", default="")
    parser.add_argument("--automation-add-to-cart-percent", type=int, default=0)
    parser.add_argument("--automation-max-search-pages", type=int, default=2)
    parser.add_argument("--automation-product-view-min", type=int, default=15)
    parser.add_argument("--automation-product-view-max", type=int, default=25)
    parser.add_argument("--start-browser-hidden", default="false")
    parser.add_argument("--load-images", default="true")
    parser.add_argument("--app-base-dir", default="", help="App install dir (Data/firefox-invisible); default cwd")
    parser.add_argument("--extra-arg", action="append", default=[])
    args = parser.parse_args()

    args.humanize = parse_bool(args.humanize)
    args.headless = parse_bool(args.headless)
    args.persistent_context = parse_bool(args.persistent_context)
    args.prep_recaptcha = parse_bool(args.prep_recaptcha)
    args.run_diagnostics = parse_bool(args.run_diagnostics)
    args.load_images = parse_bool(args.load_images)
    if not (args.automation_extension_dir or "").strip():
        args.automation_extension_dir = os.path.join(os.getcwd(), "Extensions", "ShopeeAutomation")

    os.makedirs(args.profile_dir, exist_ok=True)
    app_base_dir = resolve_app_base_dir(getattr(args, "app_base_dir", "") or "")
    try:
        seed = resolve_seed(args.seed, args.profile_name, args.profile_dir)
        proxy = build_proxy(args.proxy_server, args.proxy_username, args.proxy_password)
        humanize = resolve_humanize(args.humanize, args.humanize_max_seconds)
        firefox_path = resolve_firefox_executable(app_base_dir)
    except Exception as ex:
        print(f"ERROR: {type(ex).__name__}: {ex}", file=sys.stderr, flush=True)
        return 1
    should_stop_ref = {"stop": False}

    def handle_stop(signum, frame):
        should_stop_ref["stop"] = True

    signal.signal(signal.SIGTERM, handle_stop)
    signal.signal(signal.SIGINT, handle_stop)

    print(f"APP_BASE_DIR: {app_base_dir}", flush=True)
    print(f"INVISIBLE_VERSION: {getattr(invisible_playwright, '__version__', 'unknown')}", flush=True)
    print(f"BINARY_VERSION: {BINARY_VERSION}", flush=True)
    print(f"FIREFOX_UPSTREAM_VERSION: {FIREFOX_UPSTREAM_VERSION}", flush=True)
    print(f"FIREFOX_PATH: {firefox_path}", flush=True)
    print(f"PROFILE_NAME: {args.profile_name}", flush=True)
    print(f"PROFILE_DIR: {args.profile_dir}", flush=True)
    print(f"TARGET_URL: {args.target_url}", flush=True)
    print(f"SEED: {seed}", flush=True)
    print(f"LOCALE: {(args.locale or '').strip() or 'default'}", flush=True)
    print(f"TIMEZONE: {(args.timezone or '').strip() or 'auto'}", flush=True)
    print(f"HUMANIZE: {humanize}", flush=True)
    print(f"HEADLESS: {args.headless}", flush=True)
    print(f"PERSISTENT_CONTEXT: {args.persistent_context}", flush=True)
    print(f"PREP_RECAPTCHA: {args.prep_recaptcha}", flush=True)
    print(f"PROXY: {proxy['server'] if proxy else 'disabled'}", flush=True)
    print(f"FONT_PRESET: {args.font_preset}", flush=True)
    print(f"NAVIGATION_MODE: {args.navigation_mode}", flush=True)
    print(f"REQUESTED_LAUNCH_MODE: {args.launch_mode}", flush=True)
    print(f"AUTOMATION_ACCOUNT: {(args.automation_account or '').strip() or 'disabled'}", flush=True)
    print(f"AUTOMATION_EXTENSION_DIR: {args.automation_extension_dir}", flush=True)
    print(f"EXTRA_ARGS: {args.extra_arg if args.extra_arg else 'disabled'}", flush=True)

    try:
        if args.launch_mode == "wrapper":
            return run_wrapper_browser(args, seed, proxy, humanize, should_stop_ref)
        return run_raw_browser(args, firefox_path, seed, proxy, humanize, should_stop_ref)
    except Exception as ex:
        print(f"ERROR: {type(ex).__name__}: {ex}", file=sys.stderr, flush=True)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())

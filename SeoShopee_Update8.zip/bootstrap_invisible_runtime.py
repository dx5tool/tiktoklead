#!/usr/bin/env python3
"""Check / bootstrap Invisible runtime: venv repair, offline pip, Firefox seed. No Git."""
from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
from pathlib import Path


VENV_DIR_NAME = ".invisible-test-venv"
BUNDLED_RUNTIME_DIR = ".python-runtime"
MARKER_NAME = ".invisible-bootstrap-ok.json"
REQUIREMENTS_OFFLINE = "requirements-invisible-offline.txt"
FIREFOX_BUNDLE_REL = Path("Data") / "firefox-invisible"


def log(msg: str) -> None:
    print(msg, flush=True)


def run_cmd(
    exe: str,
    args: list[str],
    *,
    cwd: str | None = None,
    timeout: int = 600,
) -> tuple[int, str, str]:
    env = os.environ.copy()
    env["PYTHONUTF8"] = "1"
    env["PYTHONIOENCODING"] = "utf-8"
    try:
        proc = subprocess.run(
            [exe, *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=timeout,
            env=env,
        )
        return proc.returncode, proc.stdout or "", proc.stderr or ""
    except subprocess.TimeoutExpired:
        return -1, "", "timeout"
    except Exception as ex:
        return -1, "", str(ex)


def inspect_runtime(python_exe: str) -> dict | None:
    code = (
        "import json,sys;"
        "print(json.dumps({"
        "'major':sys.version_info.major,'minor':sys.version_info.minor,"
        "'version':sys.version.split()[0],"
        "'is_gil_enabled':getattr(sys,'_is_gil_enabled',lambda:True)()"
        "}))"
    )
    rc, out, err = run_cmd(python_exe, ["-c", code], timeout=30)
    if rc != 0:
        return None
    try:
        data = json.loads(out.strip().splitlines()[-1])
        major, minor = int(data["major"]), int(data["minor"])
        gil = bool(data.get("is_gil_enabled", True))
        if major != 3 or minor not in (11, 12, 13) or not gil:
            return None
        return data
    except Exception:
        return None


def deps_ok(python_exe: str) -> bool:
    code = "import invisible_playwright as ip; import psutil; print(getattr(ip,'__version__',''))"
    rc, out, _ = run_cmd(python_exe, ["-c", code], timeout=90)
    if rc != 0:
        return False
    ver = (out or "").strip().splitlines()[-1] if out else ""
    return bool(ver) and ver.lower() != "unknown"


def repair_pyvenv_cfg(venv_dir: Path, bundled_python: Path) -> None:
    cfg = venv_dir / "pyvenv.cfg"
    if not cfg.is_file():
        return
    bundled_dir = bundled_python.parent
    home = str(bundled_dir).replace("/", "\\")
    if not home.endswith("\\"):
        home += "\\"
    executable = str(bundled_python).replace("/", "\\")
    lines: list[str] = []
    for raw in cfg.read_text(encoding="utf-8", errors="replace").splitlines():
        if raw.startswith("home = "):
            lines.append(f"home = {home}")
        elif raw.startswith("executable = "):
            lines.append(f"executable = {executable}")
        elif raw.startswith("command = "):
            lines.append(f'command = "{executable}" -m venv {str(venv_dir)}')
        else:
            lines.append(raw)
    cfg.write_text("\n".join(lines) + "\n", encoding="utf-8")


def remove_tree(path: Path) -> None:
    if path.exists():
        shutil.rmtree(path, ignore_errors=True)


def create_venv(bundled_python: Path, venv_dir: Path) -> bool:
    remove_tree(venv_dir)
    rc, _, err = run_cmd(str(bundled_python), ["-m", "venv", str(venv_dir)], timeout=180)
    venv_py = venv_dir / "Scripts" / "python.exe"
    return rc == 0 and venv_py.is_file()


def pip_offline(python_exe: str, base_dir: Path) -> tuple[bool, str]:
    wheelhouse = base_dir / "wheelhouse"
    req = base_dir / REQUIREMENTS_OFFLINE
    if not req.is_file():
        return False, f"Missing {REQUIREMENTS_OFFLINE}"
    if not wheelhouse.is_dir() or not any(wheelhouse.glob("*.whl")):
        return False, "wheelhouse empty or missing — add wheels (scripts/build-invisible-wheelhouse.ps1 on dev)"
    run_cmd(python_exe, ["-m", "pip", "install", "--upgrade", "pip"], timeout=300)
    args = [
        "-m",
        "pip",
        "install",
        "--no-index",
        f"--find-links={wheelhouse}",
        "-r",
        str(req),
    ]
    rc, out, err = run_cmd(python_exe, args, timeout=1200)
    if rc != 0:
        return False, (err or out or "pip install failed").strip()
    return True, ""


def get_binary_version(python_exe: str) -> str:
    code = "import invisible_playwright.constants as c; print(c.BINARY_VERSION)"
    rc, out, _ = run_cmd(python_exe, ["-c", code], timeout=60)
    if rc != 0:
        return "firefox-8"
    line = (out or "").strip().splitlines()[-1] if out else ""
    return line or "firefox-8"


def bundled_firefox_exe(base_dir: Path) -> Path:
    return base_dir / FIREFOX_BUNDLE_REL / "firefox.exe"


def firefox_cache_target(python_exe: str, binary_version: str) -> Path:
    code = (
        "import platformdirs; from pathlib import Path; "
        f"p = Path(platformdirs.user_cache_dir('invisible-playwright')) / {repr(binary_version)} / 'firefox.exe'; "
        "print(p)"
    )
    rc, out, _ = run_cmd(python_exe, ["-c", code], timeout=30)
    if rc == 0 and out.strip():
        return Path(out.strip().splitlines()[-1])
    return Path(os.path.expandvars("%LOCALAPPDATA%")) / "invisible-playwright" / "Cache" / binary_version / "firefox.exe"


def seed_firefox(python_exe: str, base_dir: Path, offline_only: bool) -> tuple[bool, str]:
    bundle_exe = bundled_firefox_exe(base_dir)
    if bundle_exe.is_file() and bundle_exe.stat().st_size > 0:
        log(f"Firefox bundle OK (runtime uses Data/firefox-invisible): {bundle_exe}")
        return True, ""

    bundle = base_dir / FIREFOX_BUNDLE_REL
    binary_version = get_binary_version(python_exe)
    target_exe = firefox_cache_target(python_exe, binary_version)
    target_dir = target_exe.parent

    if target_exe.is_file() and target_exe.stat().st_size > 0:
        log(f"Firefox cache OK: {target_exe}")
        return True, ""

    source_exe = bundle / "firefox.exe"
    if source_exe.is_file():
        log(f"Seeding Firefox from {bundle} -> {target_dir}")
        target_dir.mkdir(parents=True, exist_ok=True)
        for item in bundle.iterdir():
            dest = target_dir / item.name
            if item.is_dir():
                if dest.exists():
                    shutil.rmtree(dest, ignore_errors=True)
                shutil.copytree(item, dest)
            else:
                shutil.copy2(item, dest)
        if target_exe.is_file():
            return True, ""
        return False, f"Seed copy done but missing {target_exe}"

    if offline_only:
        return False, f"Missing Firefox: no cache at {target_exe} and no {source_exe}"

    log("Fetching Firefox (online)...")
    rc, out, err = run_cmd(python_exe, ["-m", "invisible_playwright", "fetch"], timeout=1800)
    if rc != 0:
        return False, (err or out or "fetch failed").strip()
    return True, ""


def verify_firefox_path(python_exe: str, base_dir: Path) -> tuple[bool, str]:
    bundle_exe = bundled_firefox_exe(base_dir)
    if bundle_exe.is_file() and bundle_exe.stat().st_size > 0:
        return True, str(bundle_exe.resolve())
    rc, out, err = run_cmd(python_exe, ["-m", "invisible_playwright", "path"], timeout=120)
    if rc != 0:
        return False, err or out or "path command failed"
    p = Path((out or "").strip().splitlines()[-1])
    if p.is_file():
        return True, str(p)
    return False, f"Binary not found: {p}"


def write_marker(base_dir: Path, python_exe: str, firefox_path: str) -> None:
    data_dir = base_dir / "Data"
    data_dir.mkdir(parents=True, exist_ok=True)
    (base_dir / "Data" / "InvisibleProfiles").mkdir(parents=True, exist_ok=True)
    marker = data_dir / MARKER_NAME
    payload = {
        "ok": True,
        "timestampUtc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "baseDir": str(base_dir),
        "venvPython": str(python_exe),
        "firefoxPath": firefox_path,
    }
    marker.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def read_marker(base_dir: Path) -> dict | None:
    marker = base_dir / "Data" / MARKER_NAME
    if not marker.is_file():
        return None
    try:
        return json.loads(marker.read_text(encoding="utf-8"))
    except Exception:
        return None


def fast_path_ok(base_dir: Path, skip_if_marker: bool) -> bool:
    if not skip_if_marker:
        return False
    marker = read_marker(base_dir)
    if not marker or not marker.get("ok"):
        return False
    venv_py = base_dir / VENV_DIR_NAME / "Scripts" / "python.exe"
    if not venv_py.is_file():
        return False
    if not deps_ok(str(venv_py)):
        return False
    ok, _ = verify_firefox_path(str(venv_py), base_dir)
    return ok


def bootstrap(base_dir: Path, *, offline_only: bool = True, skip_if_marker: bool = True) -> int:
    base_dir = base_dir.resolve()
    bundled = base_dir / BUNDLED_RUNTIME_DIR / "python.exe"
    if not bundled.is_file():
        log(f"ERROR: Missing bundled Python: {bundled}")
        return 2

    if not inspect_runtime(str(bundled)):
        log("ERROR: .python-runtime is not CPython 3.11/3.12/3.13 (standard GIL).")
        return 3

    venv_dir = base_dir / VENV_DIR_NAME
    venv_py = venv_dir / "Scripts" / "python.exe"

    if fast_path_ok(base_dir, skip_if_marker):
        log("Bootstrap: marker + venv + deps + Firefox OK (skip).")
        return 0

    if venv_py.is_file():
        log("Bootstrap: repairing pyvenv.cfg...")
        repair_pyvenv_cfg(venv_dir, bundled)
        if inspect_runtime(str(venv_py)) and deps_ok(str(venv_py)):
            log("Bootstrap: venv repaired and deps OK.")
        else:
            log("Bootstrap: venv repair insufficient — recreating...")
            if not create_venv(bundled, venv_dir):
                log("ERROR: Cannot create venv")
                return 4
            venv_py = venv_dir / "Scripts" / "python.exe"
    else:
        log("Bootstrap: creating venv...")
        if not create_venv(bundled, venv_dir):
            log("ERROR: Cannot create venv")
            return 4

    if not deps_ok(str(venv_py)):
        log("Bootstrap: pip offline install...")
        ok, detail = pip_offline(str(venv_py), base_dir)
        if not ok:
            log(f"ERROR: {detail}")
            return 5
        if not deps_ok(str(venv_py)):
            log("ERROR: invisible_playwright still not importable after pip")
            return 5

    ok, detail = seed_firefox(str(venv_py), base_dir, offline_only)
    if not ok:
        log(f"ERROR: Firefox: {detail}")
        return 6

    ok, fpath = verify_firefox_path(str(venv_py), base_dir)
    if not ok:
        log(f"ERROR: {fpath}")
        return 6

    write_marker(base_dir, str(venv_py), fpath)
    log("Bootstrap: OK")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(description="Bootstrap Invisible runtime (no Git)")
    parser.add_argument("--base-dir", default="", help="App directory (default: script dir)")
    parser.add_argument("--offline-only", action="store_true", default=True)
    parser.add_argument("--allow-online-fetch", action="store_true", help="Allow invisible_playwright fetch if bundle missing")
    parser.add_argument("--no-skip-marker", action="store_true", help="Always run full checks")
    parser.add_argument("--json", action="store_true", help="Print JSON result to stdout")
    args = parser.parse_args()

    base = Path(args.base_dir).resolve() if args.base_dir else Path(__file__).resolve().parent
    offline = not args.allow_online_fetch
    rc = bootstrap(base, offline_only=offline, skip_if_marker=not args.no_skip_marker)

    if args.json:
        print(json.dumps({"exitCode": rc, "baseDir": str(base)}))
    return rc


if __name__ == "__main__":
    sys.exit(main())
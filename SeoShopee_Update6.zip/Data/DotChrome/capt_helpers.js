/*
 * Captcha Helpers for Native App Controller (v1.2)
 * Chuyên gia: Gemini Pro
 * Ngày: 2025-09-18
 *
 * Vai trò: Cung cấp các hàm "cảm biến" để đọc dữ liệu từ DOM cho ứng dụng C#.
 * KHÔNG chứa logic điều khiển, vòng lặp hay mô phỏng sự kiện.
 * v1.1: Sửa đổi các hàm trả về đối tượng để sử dụng JSON.stringify(), tương thích với C#.
 * v1.2: Thêm hàm isErrorStateVisible để phát hiện thông báo lỗi của trang.
 */
// ... (toàn bộ code cũ của phiên bản 1.1) ...
(function() {
    // Đánh dấu là script đã được nạp để tránh nạp lại
    window.captchaHelpersLoaded = true;

    // Hàm tiện ích nội bộ
    function getBase64FromDataUrl(dataUrl) {
        if (!dataUrl || !dataUrl.includes(',')) return null;
        return dataUrl.split(',')[1];
    }

    // === CÁC HÀM CẢM BIẾN ĐỂ C# GỌI ===

    /**
     * Kiểm tra xem captcha có đang hiển thị hay không (dựa vào selector và việc nó có đang được hiển thị).
     * @returns {boolean} True nếu captcha đang hiển thị.
     */
    window.isCaptchaVisible = function() {
        const selectors = ['#NEW_CAPTCHA', '#captchaMask'];
        const element = selectors.map(s => document.querySelector(s)).find(e => e);
        return !!(element && element.offsetHeight > 0 && element.offsetWidth > 0);
    }

    /**
     * Lấy dữ liệu Base64 của ảnh puzzle và mảnh ghép, cùng với src gốc.
     * @returns {string | null} Dữ liệu ảnh dưới dạng chuỗi JSON hoặc null nếu không tìm thấy.
     */
    window.getCaptchaData = function() {
        const puzzleElement = document.querySelector('.DfwepB');
        const pieceElement = document.querySelector('#puzzleImgComponent');

        if (puzzleElement && pieceElement && puzzleElement.src && pieceElement.src) {
            // Đảm bảo ảnh đã được tải xong trước khi lấy base64
            if (!puzzleElement.complete || !pieceElement.complete) {
                console.log("Image not fully loaded yet.");
                return null;
            }
            const data = {
                puzzleB64: getBase64FromDataUrl(puzzleElement.src),
                pieceB64: getBase64FromDataUrl(pieceElement.src),
                initialPuzzleSrc: puzzleElement.src
            };
            return JSON.stringify(data);
        }
        return null; // Sẽ được chuyển thành "null" khi trả về C#
    }

    /**
     * Kiểm tra xem ảnh captcha có bị thay đổi so với ảnh gốc không.
     * @param {string} initialSrc - src của ảnh puzzle lúc ban đầu.
     * @returns {boolean} True nếu ảnh đã bị thay đổi.
     */
    window.checkCaptchaChanged = function(initialSrc) {
        const currentPuzzle = document.querySelector('.DfwepB');
        return !currentPuzzle || currentPuzzle.src !== initialSrc;
    }

    /**
     * Lấy toạ độ của một element so với khung nhìn của trình duyệt (viewport).
     * @param {string} selector - CSS selector của element.
     * @returns {string | null} Toạ độ dưới dạng chuỗi JSON hoặc null.
     */
    window.getElementViewportRect = function(selector) {
        const element = document.querySelector(selector);
        if (!element) return null;
        const rect = element.getBoundingClientRect();
        const data = {
            x: rect.x,
            y: rect.y,
            width: rect.width,
            height: rect.height,
            right: rect.right,
            bottom: rect.bottom
        };
        return JSON.stringify(data);
    }

    /**
     * Thu thập một điểm dữ liệu của quỹ đạo.
     * @param {number} sliderPixelOffset - Khoảng cách đã kéo slider (pixel).
     * @returns {string | null} Dữ liệu quỹ đạo dưới dạng chuỗi JSON hoặc null.
     */
    window.getTrajectoryPoint = function(sliderPixelOffset) {
        const puzzleRect = document.querySelector('.DfwepB')?.getBoundingClientRect();
        const piece = document.querySelector('#puzzleImgComponent');
        if (!puzzleRect || !piece) return null;

        const pieceRect = piece.getBoundingClientRect();
        const style = piece.getAttribute("style") || "";
        const rotateMatch = style.match(/rotate\(([^)]+)deg\)/);
        const angle = rotateMatch ? parseFloat(rotateMatch[1]) : 0;

        const data = {
            piece_center: {
                proportionX: (pieceRect.left + pieceRect.width / 2 - puzzleRect.left) / puzzleRect.width,
                proportionY: (pieceRect.top + pieceRect.height / 2 - puzzleRect.top) / puzzleRect.height,
            },
            piece_rotation_angle: angle,
            pixels_from_slider_origin: Math.round(sliderPixelOffset)
        };
        return JSON.stringify(data);
    }

    /**
     * [MỚI] Kiểm tra xem trang có đang hiển thị thông báo lỗi chung không.
     * @returns {boolean} True nếu phát hiện thông báo lỗi.
     */
    window.isErrorStateVisible = function() {
        const errorText = "chúng tôi đang gặp sự cố tải";
        // Tìm trong toàn bộ body của trang để đảm bảo không bỏ sót
        return document.body.innerText.toLowerCase().includes(errorText);
    }

    window.getElementNaturalSize = function (selector) {
        const el = document.querySelector(selector);
        if (!el || el.tagName.toLowerCase() !== 'img') {
            return null;
        }
        return JSON.stringify({
            width: el.naturalWidth,
            height: el.naturalHeight
        });
    }

})();

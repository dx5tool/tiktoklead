// background.js

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Chỉ xử lý các tin nhắn có action là 'makeApiCall'
    if (request.action === 'makeApiCall') {
        
        const { endpoint, body, headers } = request;

        // Tạo URL đầy đủ để gọi API
        const url = `https://capv5.fshop4u.com${endpoint}`;

        // Chuẩn bị các tùy chọn cho hàm fetch()
        const options = {
            method: body ? 'POST' : 'GET', // Nếu có body thì là POST, không thì là GET


            headers: {
                "Content-Type": "application/json",
                ...headers
            }
        };

        // Nếu có body, chuyển nó thành chuỗi JSON và thêm vào options
        if (body) {
            options.body = JSON.stringify(body);
        }

        // Thực hiện cuộc gọi mạng
        fetch(url, options)
            .then(response => {
                // Nếu response không thành công (status code không phải 2xx), ném ra lỗi
                if (!response.ok) {
                    // Cố gắng đọc nội dung lỗi từ server nếu có
                    return response.text().then(text => {
                        throw new Error(`API call failed: ${response.status} ${response.statusText}. Server response: ${text}`);
                    });
                }
                // Nếu thành công, parse kết quả dưới dạng JSON
                return response.json();
            })
            .then(data => {
                // Gửi phản hồi thành công cùng với dữ liệu nhận được về cho content script
                sendResponse({ success: true, data });
            })
            .catch(error => {
                // Nếu có bất kỳ lỗi nào trong quá trình fetch, gửi phản hồi thất bại về
                console.error("Background script fetch error:", error);
                sendResponse({ success: false, error: error.message });
            });

        return true;
    }
});

chrome.runtime.onInstalled.addListener(() => {
    console.log("TSCaptcha Solver Background Script Initialized.");
});

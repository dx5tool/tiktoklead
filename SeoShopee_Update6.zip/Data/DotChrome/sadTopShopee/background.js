// background.js
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'makeApiCall') {
        const { endpoint, body } = request;
        const url = `https://capv5.fshop4u.com${endpoint}`;
        const options = {
            method: body ? 'POST' : 'GET',
            headers: { "Content-Type": "application/json" }
        };
        if (body) {
            options.body = JSON.stringify(body);
        }

        fetch(url, options)
            .then(response => {
                if (!response.ok) {
                    throw new Error(`API call failed: ${response.status} ${response.statusText}`);
                }
                return response.json();  // Parse JSON ở đây
            })
            .then(data => sendResponse({ success: true, data }))  // Gửi data JSON về
            .catch(error => sendResponse({ success: false, error: error.message }));

        return true;  // Giữ channel mở cho async
    }
});
